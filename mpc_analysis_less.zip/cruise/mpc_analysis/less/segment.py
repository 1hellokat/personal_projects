"""Library for dealing with road log segments."""

# System imports
import logging
from dataclasses import dataclass
from math import ceil, floor
from typing import Final, Optional, Union

# Third-party imports
import pandas as pd

logger = logging.getLogger(__name__)

_S_TO_MS: Final[int] = 1000
_VIN_LENGTH: Final[int] = 17
# These are just sanity checks for gross errors.
_EARLIEST_VALID_TIMESTAMP: Final[int] = 1357016400  # January 1, 2013
_LATEST_VALID_TIMESTAMP: Final[int] = 1893474000  # January 1, 2030


def _is_between(*, val: float, start: float, end: float, inclusive: bool = True) -> bool:
    """Helper to determine if a value is between two other values, inclusive."""
    return (val >= start and val <= end) if inclusive else (val > start and val < end)


def _is_col_present(series_or_df: Union[pd.Series, pd.DataFrame], column: str) -> bool:
    """Helper to determine if a column is present in a pandas series or dataframe."""
    if isinstance(series_or_df, pd.Series):
        return column in series_or_df.index
    elif isinstance(series_or_df, pd.DataFrame):
        return column in series_or_df.columns
    raise TypeError(f"Expected type Series/DataFrame, got {type(series_or_df)}")


def _is_col_float_convertible(series_or_df: Union[pd.Series, pd.DataFrame], column: str) -> bool:
    """Helper to verify field can be converted to a float."""
    if isinstance(series_or_df, pd.DataFrame):
        return pd.api.types.is_numeric_dtype(series_or_df[column])
    if isinstance(series_or_df, pd.Series):
        # A series can only have one dtype, so just try the conversion to support mixed type rows.
        try:
            float(series_or_df[column])  # type: ignore[reportGeneralTypeIssues]
            return True
        except (ValueError, TypeError):
            return False


@dataclass
class Segment:
    """Dataclass for representing a log segment."""

    vin: str
    start_t_s: float
    end_t_s: float

    @staticmethod
    def from_str(segment_id: str) -> "Segment":
        """Create a segment from a segment id '<vin>:<start>:<end>'"""
        segment_split = segment_id.split(":")
        if len(segment_split) != 3:
            error_msg = f"Segment ID doesn't contain exactly 2 colons {segment_id}"
            raise ValueError(error_msg)
        return Segment(
            vin=segment_split[0],
            start_t_s=float(segment_split[1]),
            end_t_s=float(segment_split[2]),
        )

    @staticmethod
    def from_pandas_row(row: pd.Series) -> "Segment":
        """Create a segment from a DataFrame row, assuming common column names."""
        vin_columns_to_check = ["vin", "_vin"]
        vin: Optional[str] = None
        for column in vin_columns_to_check:
            if _is_col_present(row, column=column):
                vin = str(row[column])
                break
        if vin is None:
            raise ValueError("Could not find vin column, tried 'vin' and '_vin'")

        start_end_columns_to_check = [("start_time", "end_time"), ("start_time_s", "end_time_s")]
        start_t_s: Optional[float] = None
        end_t_s: Optional[float] = None
        for start_col, end_col in start_end_columns_to_check:
            if (
                _is_col_present(row, start_col)
                and _is_col_present(row, end_col)
                and _is_col_float_convertible(row, start_col)
                and _is_col_float_convertible(row, end_col)
            ):
                start_t_s = float(row[start_col])  # type: ignore[reportGeneralTypeIssues]
                end_t_s = float(row[end_col])  # type: ignore[reportGeneralTypeIssues]
                break

        if start_t_s is None or end_t_s is None:
            raise ValueError(
                "Could not find start/end time columns, tried 'start_time'/'end_time'"
            )

        return Segment(vin=vin, start_t_s=start_t_s, end_t_s=end_t_s)

    def __str__(self) -> str:
        """Export segment to a string."""
        return f"{self.vin}:{floor(self.start_t_s)}:{ceil(self.end_t_s)}"

    @property
    def duration(self) -> float:
        """Returns the duration of the segment."""
        return self.end_t_s - self.start_t_s

    def is_valid(self) -> bool:
        """Checks various conditions to ensure the segment is valid."""
        is_valid_vin = len(self.vin) == _VIN_LENGTH
        is_valid_duration = self.duration > 0
        is_valid_start_time = self.start_t_s > _EARLIEST_VALID_TIMESTAMP
        is_valid_end_time = self.end_t_s < _LATEST_VALID_TIMESTAMP
        return all([is_valid_vin, is_valid_duration, is_valid_start_time, is_valid_end_time])

    def has_overlap(self, other: "Segment") -> bool:
        """Returns true if this segment overlaps with another matching segment."""
        if self.vin != other.vin:
            return False

        if _is_between(val=self.start_t_s, start=other.start_t_s, end=other.end_t_s):
            return True

        if _is_between(val=self.end_t_s, start=other.start_t_s, end=other.end_t_s):
            return True

        if _is_between(val=other.start_t_s, start=self.start_t_s, end=self.end_t_s):
            return True

        return bool(_is_between(val=other.end_t_s, start=self.start_t_s, end=self.end_t_s))

    def combine_segments(self, other: "Segment") -> "Segment":
        """Combines two segments into a single, larger segment."""
        if self.vin != other.vin:
            error_msg = f"Cannot combine segments from different vehicles: {self.vin} {other.vin}"
            raise ValueError(error_msg)
        return Segment(
            vin=self.vin,
            start_t_s=min([self.start_t_s, other.start_t_s]),
            end_t_s=max([self.end_t_s, other.end_t_s]),
        )

    def webviz_link(self) -> str:
        """Create a webviz link for this segment."""
        start_t_ms = floor(self.start_t_s * _S_TO_MS)
        end_t_ms = ceil(self.end_t_s * _S_TO_MS)
        return f"https://webviz.robot.car/?vin={self.vin}&start={start_t_ms:d}&end={end_t_ms:d}"


def filter_invalid_segments(segment_ids: list[str]) -> list[str]:
    """Checks for valid segments, returns a mapping from input to output segments."""

    def filter_segment_func(segment_id: str) -> bool:
        if Segment.from_str(segment_id=segment_id).is_valid():
            return True
        logger.warning(f"Ignoring invalid segment: {segment_id}")
        return False

    return list(filter(filter_segment_func, segment_ids))


def filter_overlapping_segments(segment_ids: list[str]) -> list[str]:
    """Checks if segments in a list are overlapping, discarding the latter overlapping segments."""
    if not segment_ids:
        return []
    segments: list[Segment] = list(map(Segment.from_str, segment_ids))
    segments_to_keep: list[Segment] = [segments[0]]
    for i in range(1, len(segments)):
        cur_segment = segments[i]
        has_overlap = False
        # This is inefficient (e.g. O(n^2)) but sorting isn't performed here (as an optimization)
        # to preserve any ordering that may place more valuable segments first (e.g. like COLA
        # results sorted by similarity threshold).
        for segment in segments_to_keep:
            if cur_segment.has_overlap(segment):
                has_overlap = True
                break
        if not has_overlap:
            segments_to_keep.append(cur_segment)
    return list(map(str, segments_to_keep))
