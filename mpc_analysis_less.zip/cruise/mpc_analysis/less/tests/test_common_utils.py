"""Unit tests for the LESS Labels common utilities library"""

# System imports
from typing import Final
from unittest import mock

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.labels.common_utils import (
    Interval,
    get_sim_scenario_bounds_from_less,
    publish_sim_scenario_bounds_to_less,
)
from cruise.mpc_analysis.less.tests.fixtures import FakeBigQueryClient

_SAMPLE_HYDRA_RUN_ID: Final[str] = "30402914-e047-40ac-9805-bb1cdf2478cc:1"
_SAMPLE_SCENARIO_START_S: Final[float] = 0.0
_SAMPLE_SCENARIO_END_S: Final[float] = 10.0


@pytest.fixture
def sample_sim_scenario_bounds() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "hydra_run_id": _SAMPLE_HYDRA_RUN_ID,
                "scenario_start_time": _SAMPLE_SCENARIO_START_S,
                "scenario_end_time": _SAMPLE_SCENARIO_END_S,
            }
        ]
    )


@mock.patch("cruise.mpc_analysis.less.labels.common_utils.LessBigQueryClient.init_from_vault")
def test_get_sim_scenario_bounds_from_less(
    less_bq_client_mock: mock.Mock, sample_sim_scenario_bounds: pd.DataFrame
) -> None:
    fake_client = FakeBigQueryClient()
    fake_client.output = sample_sim_scenario_bounds
    less_bq_client_mock.return_value = fake_client
    result = get_sim_scenario_bounds_from_less(hydra_run_ids=[_SAMPLE_HYDRA_RUN_ID])
    assert _SAMPLE_HYDRA_RUN_ID in result
    result_scenario_bounds = result[_SAMPLE_HYDRA_RUN_ID]
    assert result_scenario_bounds is not None
    assert result_scenario_bounds.start_time_s == _SAMPLE_SCENARIO_START_S
    assert result_scenario_bounds.end_time_s == _SAMPLE_SCENARIO_END_S


@mock.patch("cruise.mpc_analysis.less.labels.common_utils.LessBigQueryClient.init_from_vault")
def test_publish_sim_scenario_bounds_to_less(
    less_bq_client_mock: mock.Mock, sample_sim_scenario_bounds: pd.DataFrame
) -> None:
    sim_scenario_bounds = {
        _SAMPLE_HYDRA_RUN_ID: Interval(
            start_time_s=_SAMPLE_SCENARIO_START_S, end_time_s=_SAMPLE_SCENARIO_END_S
        )
    }
    publish_sim_scenario_bounds_to_less(sim_scenario_bounds=sim_scenario_bounds)
    less_bq_client_mock.assert_called_once()
