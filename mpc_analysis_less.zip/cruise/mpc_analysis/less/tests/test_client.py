"""Unit tests for the LESS label client library."""

# System imports
import json
from typing import Final
from unittest import mock

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.labels.client import LabelLoader, LabelSetManager, LessLabelClient
from cruise.mpc_analysis.less.labels.label_schema import LabelSource, SceneSlicerLabel
from cruise.mpc_analysis.less.labels.tpo import LabelsetPurpose

_SAMPLE_SEGMENT_ID: Final[str] = "5G21A6P05P0111111:1730730000:1730730010"
_LABEL_GUID_1: Final[str] = "18c0e379-3991-4775-a11c-f5868159111c"
_LABEL_GUID_2: Final[str] = "f97786cd-28b3-49d7-a5fe-d96d37e1c0ae"
_TASK_QUEUE_ID: Final[int] = 1234
_TPO_REQUEST_ID: Final[str] = "5d3cc1cd-7ee9-4d92-919e-3b4d0f8045c7"
_SLICER_NAME: Final[str] = "av_in_unit_test_scene"
_LABELSET_PURPOSE: Final[LabelsetPurpose] = LabelsetPurpose.PRECISION


@pytest.fixture
def sample_tpo_labelset_info() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "labelset_name": "tpo_labelset",
                "num_segments": 100,
                "tpo_request_id": _TPO_REQUEST_ID,
                "slicer_name": _SLICER_NAME,
                "labelset_purpose": _LABELSET_PURPOSE,
            }
        ]
    )


@pytest.fixture
def sample_dailyflow_labelset_info() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "labelset_name": "df_labelset",
                "task_queue_id": _TASK_QUEUE_ID,
                "slicer_name": _SLICER_NAME,
                "labelset_purpose": _LABELSET_PURPOSE,
            }
        ]
    )


@pytest.fixture
def sample_dailyflow_labels() -> pd.DataFrame:
    metadata = {
        "task_queue_id": _TASK_QUEUE_ID,
    }
    return pd.DataFrame(
        [
            {
                "uuid": _LABEL_GUID_1,
                "metadata": json.dumps(metadata),
                "segment_id": _SAMPLE_SEGMENT_ID,
                "source": LabelSource.DAILYFLOW,
                "is_event_in_segment": False,
            }
        ]
    )


@pytest.fixture
def sample_tpo_labels() -> pd.DataFrame:
    metadata = {
        "tpo_request_id": _TPO_REQUEST_ID,
    }
    return pd.DataFrame(
        [
            {
                "uuid": _LABEL_GUID_2,
                "metadata": json.dumps(metadata),
                "segment_id": _SAMPLE_SEGMENT_ID,
                "source": LabelSource.DAILYFLOW,
                "is_event_in_segment": False,
            }
        ]
    )


@pytest.fixture
def fake_label_loaders(
    sample_dailyflow_labels: pd.DataFrame, sample_tpo_labels: pd.DataFrame
) -> list[LabelLoader]:
    return [
        LabelLoader(
            schema_type=SceneSlicerLabel,
            source=LabelSource.DAILYFLOW,
            loader_func=lambda: sample_dailyflow_labels,
        ),
        LabelLoader(
            schema_type=SceneSlicerLabel,
            source=LabelSource.TPO,
            loader_func=lambda: sample_tpo_labels,
        ),
    ]


def test_labelset_manager_init_empty_cache() -> None:
    """Tests the labelset manager can be instantiated."""
    manager = LabelSetManager()
    assert manager._labelset_registry_info.empty


@mock.patch(
    "cruise.mpc_analysis.less.labels.client.get_dailyflow_labelset_registry_info",
    return_value=pd.DataFrame(),
)
@mock.patch(
    "cruise.mpc_analysis.less.labels.client.get_tpo_labelset_registry_info",
    return_value=pd.DataFrame(),
)
def test_labelset_manager_no_data(get_tpo_mock: mock.Mock, get_dailyflow_mock: mock.Mock) -> None:
    """Tests that the labelset manager will raise an exception without any registry data."""
    with pytest.raises(ValueError):
        LabelSetManager().get_labelset_info()
    assert get_tpo_mock.call_count == 1
    assert get_dailyflow_mock.call_count == 1


@mock.patch("cruise.mpc_analysis.less.labels.client.get_dailyflow_labelset_registry_info")
@mock.patch("cruise.mpc_analysis.less.labels.client.get_tpo_labelset_registry_info")
def test_labelset_manager_get_info(
    get_tpo_mock: mock.Mock,
    get_dailyflow_mock: mock.Mock,
    sample_tpo_labelset_info: pd.DataFrame,
    sample_dailyflow_labelset_info: pd.DataFrame,
) -> None:
    """Tests that main functionality of the labelset manager class with mocked registry info."""
    get_tpo_mock.return_value = sample_tpo_labelset_info
    get_dailyflow_mock.return_value = sample_dailyflow_labelset_info

    manager = LabelSetManager()
    assert manager._labelset_registry_info.empty
    assert get_tpo_mock.call_count == 0
    assert get_dailyflow_mock.call_count == 0

    labelset_info = manager.get_labelset_info()
    assert len(labelset_info) == 2
    assert get_tpo_mock.call_count == 1
    assert get_dailyflow_mock.call_count == 1

    labelset_info = manager.get_labelset_info(task_queue_id=1234)
    assert len(labelset_info) == 1
    assert labelset_info.iloc[0]["labelset_name"] == "df_labelset"


def test_less_label_client_is_singleton() -> None:
    client_a = LessLabelClient(schema_type=SceneSlicerLabel)
    client_b = LessLabelClient(schema_type=SceneSlicerLabel)
    assert client_a is client_b


def test_less_label_client_invalid_schema_raises() -> None:
    """Tests that the label client raises if it doesn't get a BaseSchema descendant."""
    with pytest.raises(TypeError):
        LessLabelClient(schema_type=int)


def test_label_client_get_labels(
    sample_dailyflow_labels: pd.DataFrame,
    sample_tpo_labels: pd.DataFrame,
    fake_label_loaders: list[LabelLoader],
) -> None:
    """Tests the main functionality of the label client (get_labels)."""
    with mock.patch(
        "cruise.mpc_analysis.less.labels.client._LABEL_LOADERS", new=[]
    ) as label_loaders_mock:
        label_loaders_mock.extend(fake_label_loaders)
        client = LessLabelClient(schema_type=SceneSlicerLabel)
        result_labels_df = client.get_labels()
        assert len(result_labels_df) == len(sample_dailyflow_labels) + len(sample_tpo_labels)

        tpo_label = result_labels_df[result_labels_df["source"] == LabelSource.TPO.name]
        assert len(tpo_label) == 1
        assert sample_tpo_labels.iloc[0]["uuid"] == tpo_label.iloc[0]["uuid"]
        assert sample_tpo_labels.iloc[0]["metadata"] == tpo_label.iloc[0]["metadata"]

        dailyflow_label = result_labels_df[
            result_labels_df["source"] == LabelSource.DAILYFLOW.name
        ]
        assert len(dailyflow_label) == 1
        assert sample_dailyflow_labels.iloc[0]["uuid"] == dailyflow_label.iloc[0]["uuid"]
        assert sample_dailyflow_labels.iloc[0]["metadata"] == dailyflow_label.iloc[0]["metadata"]


def test_label_client_get_labels_with_unpacked_metadata(
    sample_dailyflow_labels: pd.DataFrame,
    sample_tpo_labels: pd.DataFrame,
    fake_label_loaders: list[LabelLoader],
) -> None:
    """Tests that the label metadata can be unpacked and provided with multiple label sources."""
    with mock.patch(
        "cruise.mpc_analysis.less.labels.client._LABEL_LOADERS", new=[]
    ) as label_loaders_mock:
        label_loaders_mock.extend(fake_label_loaders)
        client = LessLabelClient(schema_type=SceneSlicerLabel)

        tpo_label = client.get_labels(unpack_metadata=True, source=LabelSource.TPO.name)
        assert len(tpo_label) == 1
        assert tpo_label.iloc[0]["uuid"] == sample_tpo_labels.iloc[0]["uuid"]
        assert tpo_label.iloc[0]["source"] == LabelSource.TPO.name
        assert tpo_label.iloc[0]["tpo_request_id"] == _TPO_REQUEST_ID

        dailyflow_label = client.get_labels(
            unpack_metadata=True, source=LabelSource.DAILYFLOW.name
        )
        assert len(dailyflow_label) == 1
        assert dailyflow_label.iloc[0]["uuid"] == sample_dailyflow_labels.iloc[0]["uuid"]
        assert dailyflow_label.iloc[0]["source"] == LabelSource.DAILYFLOW.name
        assert dailyflow_label.iloc[0]["task_queue_id"] == _TASK_QUEUE_ID
