"""Unit tests for the labels TPO library."""

# System imports
import datetime
import uuid
from math import isnan
from typing import Final
from unittest import mock

# Third-party imports
import numpy as np
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.constants import DEFAULT_TRACK_ID
from cruise.mpc_analysis.less.labels.common_utils import Interval
from cruise.mpc_analysis.less.labels.label_schema import SceneSlicerLabel
from cruise.mpc_analysis.less.labels.tpo import (
    _LESS_TPO_REGISTRY_TABLE,
    _TPO_LABELING_REQUEST_TABLE,
    EventSource,
    LabelsetPurpose,
    TPOLabelingRequest,
    TPOLabelingSegmentInfo,
    TPOLabelsetRegistry,
    _get_tpo_raw_labels,
    _is_valid_raw_tpo_label,
    _unpack_tpo_scene_quality_labels,
    create_tpo_labelset,
    get_tpo_labels,
    get_tpo_labelset_registry_info,
    submit_tpo_labeling_request,
)
from cruise.mpc_analysis.less.tests.fixtures import FakeBigQueryClient

_SEGMENT_START_TIME: Final[int] = 1730730000
_SEGMENT_END_TIME: Final[int] = 1730730010
_SAMPLE_FREE_FORM_QUESTION: Final[str] = "What is the traffic light state in the scene?"
_SAMPLE_FREE_FORM_RESPONSE: Final[str] = "red"
_SAMPLE_SEGMENT_ID: Final[str] = f"5G21A6P05P0111111:{_SEGMENT_START_TIME}:{_SEGMENT_END_TIME}"


@pytest.fixture
def sample_labeling_request() -> TPOLabelingRequest:
    segment_info = TPOLabelingSegmentInfo(
        segment_id=_SAMPLE_SEGMENT_ID,
        critical_ros_time=_SEGMENT_START_TIME,
        track_id=DEFAULT_TRACK_ID,
    )
    return TPOLabelingRequest(
        prompt_text="animal in road",
        labeling_instructions="is there an animal in the road?",
        segment_infos=[segment_info],
    )


@pytest.fixture
def sample_tpo_raw_labels() -> pd.DataFrame:
    labeling_request_id = str(uuid.uuid4())
    return pd.DataFrame(
        [
            {
                # Positive label.
                "link_id": _SAMPLE_SEGMENT_ID,
                "a_scene_validation": "Yes",
                "md_result_id": str(uuid.uuid4()),
                "md_request_id": labeling_request_id,
                "md_free_form_question": _SAMPLE_FREE_FORM_QUESTION,
                "a_free_form_question": "red",
            },
            {
                # Negative label.
                "link_id": _SAMPLE_SEGMENT_ID,
                "a_scene_validation": "No",
                "md_result_id": str(uuid.uuid4()),
                "md_request_id": labeling_request_id,
                "md_free_form_question": _SAMPLE_FREE_FORM_QUESTION,
                "a_free_form_question": "",
            },
        ]
    )


@pytest.fixture
def sample_tpo_raw_label_no_ff_question() -> pd.DataFrame:
    labeling_request_id = str(uuid.uuid4())
    return pd.DataFrame(
        [
            {
                # Positive label.
                "link_id": _SAMPLE_SEGMENT_ID,
                "a_scene_validation": "Yes",
                "md_result_id": str(uuid.uuid4()),
                "md_request_id": labeling_request_id,
                "md_free_form_question": None,
                "a_free_form_question": None,
            },
        ]
    )


def test_tpo_labelset_registry_structure() -> None:
    registry_entry = TPOLabelsetRegistry(
        labelset_name="some labelset",
        slicer_name="av_in_imaginary_scene",
        tpo_request_id=str(uuid.uuid4()),
        segment_ids=[_SAMPLE_SEGMENT_ID],
        labeling_instructions="some instructions",
        event_source=EventSource.COLA,
        labelset_purpose=LabelsetPurpose.BOTH,
        created_by_user="jane.doe",
        created_timestamp=datetime.datetime.now(),
        free_form_question=_SAMPLE_FREE_FORM_QUESTION,
    )
    query = registry_entry.get_insert_query(table_name=_LESS_TPO_REGISTRY_TABLE)
    assert len(query) > 0
    assert _LESS_TPO_REGISTRY_TABLE in query


def test_tpo_labeling_request_structure(sample_labeling_request: TPOLabelingRequest) -> None:
    query = sample_labeling_request.get_insert_query(table_name=_TPO_LABELING_REQUEST_TABLE)
    assert len(query) > 0
    assert _TPO_LABELING_REQUEST_TABLE in query


@mock.patch(
    "cruise.mpc_analysis.less.labels.tpo.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_create_tpo_labelset(bq_client_mock: mock.Mock) -> None:
    create_tpo_labelset(
        labelset_name="some labelset",
        slicer_name="av_in_imaginary_scene",
        tpo_request_id=str(uuid.uuid4()),
        segment_ids=[_SAMPLE_SEGMENT_ID],
        labeling_instructions="some instructions",
        event_source=EventSource.COLA,
        labelset_purpose=LabelsetPurpose.BOTH,
        free_form_question=_SAMPLE_FREE_FORM_QUESTION,
    )
    assert bq_client_mock.call_count == 1


@mock.patch(
    "cruise.mpc_analysis.less.labels.tpo.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_submit_tpo_labeling_request(
    bq_client_mock: mock.Mock, sample_labeling_request: TPOLabelingRequest
) -> None:
    submit_tpo_labeling_request(tpo_request=sample_labeling_request)
    assert bq_client_mock.call_count == 1


@mock.patch(
    "cruise.mpc_analysis.less.labels.common_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_get_tpo_labelset_registry_info(bq_client_mock: mock.Mock) -> None:
    get_tpo_labelset_registry_info()
    assert bq_client_mock.call_count == 1


def test_is_valid_raw_tpo_label_valid(sample_tpo_raw_labels: pd.DataFrame) -> None:
    for _, row in sample_tpo_raw_labels.iterrows():
        assert _is_valid_raw_tpo_label(row) is True


def test_is_valid_raw_tpo_label_missing_fields(sample_tpo_raw_labels: pd.DataFrame) -> None:
    """Remove columns and verify the labels are marked invalid."""
    for field in ["link_id", "a_scene_validation", "md_result_id", "md_request_id"]:
        labels_df = sample_tpo_raw_labels.drop(columns=[field])
        assert _is_valid_raw_tpo_label(labels_df.iloc[0]) is False


def test_is_valid_raw_tpo_label_non_yes_no_answer(sample_tpo_raw_labels: pd.DataFrame) -> None:
    """Change the scene validation answer from yes or no and ensure it's invalid."""
    labels_df = sample_tpo_raw_labels.assign(a_scene_validation="Data is not available")
    for _, row in labels_df.iterrows():
        assert _is_valid_raw_tpo_label(row) is False


def test_unpack_scene_quality_labels_all_valid(sample_tpo_raw_labels: pd.DataFrame) -> None:
    unpacked_labels = _unpack_tpo_scene_quality_labels(raw_labels_df=sample_tpo_raw_labels)
    assert len(unpacked_labels) == len(sample_tpo_raw_labels)

    first_entry = unpacked_labels[0]
    assert first_entry.is_event_in_segment is True
    assert not isnan(first_entry.event_start_s)
    assert not isnan(first_entry.event_end_s)
    assert first_entry.free_form_question == _SAMPLE_FREE_FORM_QUESTION
    assert first_entry.free_form_response == _SAMPLE_FREE_FORM_RESPONSE

    second_entry = unpacked_labels[1]
    assert second_entry.is_event_in_segment is False
    assert isnan(second_entry.event_start_s)
    assert isnan(second_entry.event_end_s)


@mock.patch("cruise.mpc_analysis.less.labels.tpo.get_all_sim_scenario_bounds_from_less")
def test_unpack_scene_quality_labels_hydra_run_ids(
    scenario_bounds_mock: mock.Mock, sample_tpo_raw_labels: pd.DataFrame
) -> None:
    hydra_id_1: str = "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:1"
    hydra_id_2: str = "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:2"
    sample_tpo_raw_labels.loc[0, "link_id"] = hydra_id_1
    sample_tpo_raw_labels.loc[1, "link_id"] = hydra_id_2
    scenario_bounds_mock.return_value = {
        hydra_id_1: Interval(0.0, 10.0),
        hydra_id_2: Interval(0.0, 10.0),
    }
    unpacked_labels = _unpack_tpo_scene_quality_labels(raw_labels_df=sample_tpo_raw_labels)
    assert len(unpacked_labels) == len(sample_tpo_raw_labels)

    first_entry = unpacked_labels[0]
    assert first_entry.is_event_in_segment is True
    assert first_entry.event_start_s == 0.0
    assert first_entry.event_end_s == 10.0
    assert first_entry.free_form_question == _SAMPLE_FREE_FORM_QUESTION
    assert first_entry.free_form_response == _SAMPLE_FREE_FORM_RESPONSE

    second_entry = unpacked_labels[1]
    assert second_entry.is_event_in_segment is False
    assert isnan(second_entry.event_start_s)
    assert isnan(second_entry.event_end_s)


def test_unpack_scene_quality_labels_invalid(sample_tpo_raw_labels: pd.DataFrame) -> None:
    """Tests unpacking labels with a missing column so they are invalid."""
    raw_labels_df = sample_tpo_raw_labels.drop(columns=["link_id"])
    unpacked_labels = _unpack_tpo_scene_quality_labels(raw_labels_df=raw_labels_df)
    assert len(unpacked_labels) == 0


@mock.patch(
    "cruise.mpc_analysis.less.labels.tpo.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_get_tpo_raw_labels(
    bq_client_mock: mock.Mock, sample_tpo_raw_labels: TPOLabelingRequest
) -> None:
    bq_client_mock.return_value.output = sample_tpo_raw_labels
    raw_labels_df = _get_tpo_raw_labels(tpo_request_ids=[str(uuid.uuid4())])
    assert bq_client_mock.call_count == 1
    assert len(raw_labels_df) == 2


@mock.patch(
    "cruise.mpc_analysis.less.labels.tpo.get_tpo_labelset_registry_info",
    return_value=pd.DataFrame(),
)
def test_get_tpo_labels_empty(get_tpo_labelset_info_mock: mock.Mock) -> None:
    """Test case with no request IDs provided, early exit for no registered labelsets (mocked)."""
    labels_df = get_tpo_labels(schema_type=SceneSlicerLabel)
    assert labels_df.empty is True
    assert get_tpo_labelset_info_mock.call_count == 1


@mock.patch("cruise.mpc_analysis.less.labels.tpo._get_tpo_raw_labels", return_value=pd.DataFrame())
def test_get_tpo_labels_empty_no_early_exist(get_tpo_raw_labels_mock: mock.Mock) -> None:
    """Test case with request IDs provided, but no raw labels returned (mocked)."""
    labels_df = get_tpo_labels(schema_type=SceneSlicerLabel, tpo_request_ids=["a", "b"])
    assert labels_df.empty is True
    assert get_tpo_raw_labels_mock.call_count == 1


@mock.patch("cruise.mpc_analysis.less.labels.tpo._get_tpo_raw_labels")
def test_get_tpo_labels_populated(
    get_tpo_raw_labels_mock: mock.Mock, sample_tpo_raw_labels: pd.DataFrame
) -> None:
    """Test case with request IDs provided, and valid raw labels mocked."""
    get_tpo_raw_labels_mock.return_value = sample_tpo_raw_labels
    labels_df = get_tpo_labels(schema_type=SceneSlicerLabel, tpo_request_ids=["a", "b"])
    assert get_tpo_raw_labels_mock.call_count == 1
    assert len(labels_df) == 2

    # Check data types
    assert np.issubdtype(labels_df.dtypes["is_event_in_segment"], np.bool_)
    assert np.issubdtype(labels_df.dtypes["event_start_s"], np.floating)
    assert np.issubdtype(labels_df.dtypes["event_end_s"], np.floating)

    # Check values.
    pos_event = labels_df.iloc[0]
    assert bool(pos_event["is_event_in_segment"]) is True
    assert pos_event["uuid"] == sample_tpo_raw_labels.iloc[0]["md_result_id"]
    assert pos_event["segment_id"] == sample_tpo_raw_labels.iloc[0]["link_id"]
    assert pos_event["event_start_s"] == float(_SEGMENT_START_TIME)
    assert pos_event["event_end_s"] == float(_SEGMENT_END_TIME)
    assert pos_event["free_form_question"] == _SAMPLE_FREE_FORM_QUESTION
    assert pos_event["free_form_response"] == _SAMPLE_FREE_FORM_RESPONSE

    neg_event = labels_df.iloc[1]
    assert bool(neg_event["is_event_in_segment"]) is False
    assert neg_event["uuid"] == sample_tpo_raw_labels.iloc[1]["md_result_id"]
    assert neg_event["segment_id"] == sample_tpo_raw_labels.iloc[1]["link_id"]
    assert isnan(neg_event["event_start_s"])
    assert isnan(neg_event["event_end_s"])
    assert neg_event["free_form_question"] == _SAMPLE_FREE_FORM_QUESTION
    assert neg_event["free_form_response"] == ""


@mock.patch("cruise.mpc_analysis.less.labels.tpo._get_tpo_raw_labels")
def test_get_tpo_labels_populated_no_ff_question(
    get_tpo_raw_labels_mock: mock.Mock, sample_tpo_raw_label_no_ff_question: pd.DataFrame
) -> None:
    """Test case with request IDs provided, and valid raw labels mocked."""
    get_tpo_raw_labels_mock.return_value = sample_tpo_raw_label_no_ff_question
    labels_df = get_tpo_labels(schema_type=SceneSlicerLabel, tpo_request_ids=["a", "b"])
    assert get_tpo_raw_labels_mock.call_count == 1
    assert len(labels_df) == 1

    # Check data types
    assert np.issubdtype(labels_df.dtypes["is_event_in_segment"], np.bool_)
    assert np.issubdtype(labels_df.dtypes["event_start_s"], np.floating)
    assert np.issubdtype(labels_df.dtypes["event_end_s"], np.floating)

    # Check values.
    pos_event = labels_df.iloc[0]
    assert bool(pos_event["is_event_in_segment"]) is True
    assert pos_event["uuid"] == sample_tpo_raw_label_no_ff_question.iloc[0]["md_result_id"]
    assert pos_event["segment_id"] == sample_tpo_raw_label_no_ff_question.iloc[0]["link_id"]
    assert pos_event["event_start_s"] == float(_SEGMENT_START_TIME)
    assert pos_event["event_end_s"] == float(_SEGMENT_END_TIME)
    assert pos_event["free_form_question"] == ""
    assert pos_event["free_form_response"] == ""
