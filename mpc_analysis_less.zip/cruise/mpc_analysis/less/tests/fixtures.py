"""Some shared unit test fixtures."""

# System imports
from typing import Union

# Third-party imports
import pandas as pd


class FakeBigQueryClient:
    """Fake class for the LessLabelClient."""

    def __init__(self) -> None:
        self.output: pd.DataFrame = pd.DataFrame()

    def run_query(self, query: str, as_dataframe: bool = False) -> Union[list, pd.DataFrame]:
        if as_dataframe:
            return self.output
        return []

    def run_query_and_get_dataframe(self, query: str) -> pd.DataFrame:
        return self.output


class FakeSimAnalysisRunner:
    """Fake Sim analysis runner for unit tests."""

    def __init__(self) -> None:
        self.slicer_output: dict[str, pd.DataFrame] = {}

    def run(self) -> dict[str, pd.DataFrame]:
        return self.slicer_output
