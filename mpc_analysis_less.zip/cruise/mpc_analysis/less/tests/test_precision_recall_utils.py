# System imports
from math import isnan

# Third-party imports
import numpy as np
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.precision_recall_utils import (
    PrecisionRecallResult,
    PrecisionRecallResultDelta,
    compute_precision_recall,
)
from cruise.mpc_analysis.less.slicer_utils import SlicerInputType


@pytest.fixture
def labels_df() -> pd.DataFrame:
    return pd.DataFrame(
        data={
            "uuid": ["1", "2", "3", "4"],
            "is_event_in_segment": [True, False, True, True],
            "segment_id": [
                "5G21A6P03P4114536:1730729222:1730729232",
                "5G21A6P06P4107936:1722018548:1722018558",
                "5G21A6P08P4119909:1732636754:1732636875",
                "5G21A6P06L4100172:1689159552:1689159558",
            ],
            "event_start_s": [
                1730729228,
                np.NaN,
                1732636754,
                1689159553.8,
            ],
            "event_end_s": [1730729232, np.NaN, 1732636875, 1689159557],
        }
    )


@pytest.fixture
def slicer_output_df() -> pd.DataFrame:
    return pd.DataFrame(
        data={
            "start_time": [
                pd.to_datetime(i, utc=True).timestamp()
                for i in [
                    "2024-11-04 14:07:08.950846",
                    "2024-10-01 18:00:00.00",
                    "2024-11-26 15:59:14",
                    "2023-07-12 10:59:13",
                ]
            ],
            "end_time": [
                pd.to_datetime(i, utc=True).timestamp()
                for i in [
                    "2024-11-04 14:07:11.950874",
                    "2024-10-01 18:00:12.00",
                    "2024-11-26 16:01:15",
                    "2023-07-12 10:59:17",
                ]
            ],
            "_vin": [
                "5G21A6P03P4114536",
                "5G21A6P06P4107936",
                "5G21A6P08P4119909",
                "5G21A6P06L4100172",
            ],
        }
    )


def test_precision_recall_result_add_results() -> None:
    """Test case for adding two sets of precision recall results."""
    result_1 = PrecisionRecallResult(
        true_positives=["a1"],
        true_negatives=["b1"],
        false_positives=["c1"],
        false_negatives=["d1"],
    )
    result_2 = PrecisionRecallResult(
        true_positives=["a2"],
        true_negatives=["b2"],
        false_positives=["c2"],
        false_negatives=["d2"],
    )
    combined_result = result_1 + result_2
    assert set(combined_result.true_positives) == {"a1", "a2"}
    assert set(combined_result.true_negatives) == {"b1", "b2"}
    assert set(combined_result.false_positives) == {"c1", "c2"}
    assert set(combined_result.false_negatives) == {"d1", "d2"}


def test_nominal_case(labels_df: pd.DataFrame, slicer_output_df: pd.DataFrame) -> None:
    pr_result = compute_precision_recall(
        labels_df, slicer_output_df, input_type=SlicerInputType.SEGMENT_ID
    )
    assert pr_result.num_tp == 3
    assert pr_result.num_fp == 0
    assert pr_result.num_tn == 1
    assert pr_result.num_fn == 0
    assert pr_result.precision == 1.0
    assert pr_result.recall == 1.0


def test_no_slicer_output(labels_df: pd.DataFrame) -> None:
    pr_result = compute_precision_recall(
        labels_df, slicer_output_df=pd.DataFrame(), input_type=SlicerInputType.SEGMENT_ID
    )
    assert pr_result.num_tp == 0
    assert pr_result.num_fp == 0
    assert pr_result.num_tn == 1
    assert pr_result.num_fn == 3
    assert pr_result.precision == 0.0
    assert pr_result.recall == 0.0


def test_slicer_event_start_datetimes_raises(
    labels_df: pd.DataFrame, slicer_output_df: pd.DataFrame
) -> None:
    """Tests that compute_precision_recall raises if the slicer time types are incorrect."""
    slicer_output_df["start_time"] = slicer_output_df["start_time"].apply(
        pd.Timestamp.fromtimestamp
    )
    with pytest.raises(TypeError):
        compute_precision_recall(
            labels_df, slicer_output_df, input_type=SlicerInputType.SEGMENT_ID
        )


def test_slicer_event_end_datetimes_raises(
    labels_df: pd.DataFrame, slicer_output_df: pd.DataFrame
) -> None:
    """Tests that compute_precision_recall raises if the slicer time types are incorrect."""
    slicer_output_df["end_time"] = slicer_output_df["end_time"].apply(pd.Timestamp.fromtimestamp)
    with pytest.raises(TypeError):
        compute_precision_recall(
            labels_df, slicer_output_df, input_type=SlicerInputType.SEGMENT_ID
        )


def test_prec_recall_result_as_dict(
    labels_df: pd.DataFrame, slicer_output_df: pd.DataFrame
) -> None:
    """Tests that the as_dict method returns the expected values."""
    pr_result = compute_precision_recall(
        labels_df, slicer_output_df, input_type=SlicerInputType.SEGMENT_ID
    )
    pr_dict = pr_result.as_dict()
    assert pr_dict["precision"] == 1.0
    assert pr_dict["recall"] == 1.0
    assert pr_dict["num_events"] == 4
    assert pr_dict["num_tp"] == 3
    assert pr_dict["num_fp"] == 0
    assert pr_dict["num_tn"] == 1
    assert pr_dict["num_fn"] == 0


def test_prec_recall_result_delta_no_change() -> None:
    """Tests the PrecisionRecallResultDelta structure with identical results."""
    result_entries = {
        "true_positives": ["a"],
        "false_positives": ["b"],
        "true_negatives": ["c"],
        "false_negatives": ["d"],
    }
    result_a = PrecisionRecallResult(**result_entries)
    result_b = PrecisionRecallResult(**result_entries)
    delta_results = PrecisionRecallResultDelta(result_a=result_a, result_b=result_b)
    assert delta_results.precision_delta == 0.0
    assert delta_results.recall_delta == 0.0
    assert delta_results.recall_delta_pct == 0.0
    assert delta_results.precision_delta_pct == 0.0
    assert delta_results.true_positives_delta == []
    assert delta_results.false_positives_delta == []
    assert delta_results.true_negatives_delta == []
    assert delta_results.false_negatives_delta == []


def test_prec_recall_result_delta_a_has_zero_prec_recall() -> None:
    """Tests the PrecisionRecallResultDelta structure with identical results."""
    result_a_entries = {
        "true_positives": [],
        "false_positives": ["b"],
        "true_negatives": ["c"],
        "false_negatives": ["a", "d"],
    }
    result_a = PrecisionRecallResult(**result_a_entries)
    result_b_entries = {
        "true_positives": ["a"],
        "false_positives": ["b"],
        "true_negatives": ["c"],
        "false_negatives": ["d"],
    }
    result_b = PrecisionRecallResult(**result_b_entries)
    delta_results = PrecisionRecallResultDelta(result_a=result_a, result_b=result_b)
    assert isnan(delta_results.recall_delta_pct)
    assert isnan(delta_results.precision_delta_pct)


def test_prec_recall_result_delta_with_change() -> None:
    """Tests the PrecisionRecallResultDelta structure with changed results."""
    result_a_entries = {
        "true_positives": ["a"],
        "false_positives": ["b"],
        "true_negatives": ["c"],
        "false_negatives": ["d", "e"],
    }
    # Check the individual results before proceeding.
    result_a = PrecisionRecallResult(**result_a_entries)
    exp_recall_a = float(1) / (1 + 2)  # 1 TP, 2 FNs
    exp_prec_a = float(1) / (1 + 1)  # 1 TP, 1 FP
    assert result_a.recall == exp_recall_a
    assert result_a.precision == exp_prec_a

    # In B, move the incorrect results to correct.
    result_b_entries = {
        "true_positives": ["a", "d", "e"],
        "false_positives": [],
        "true_negatives": ["c", "b"],
        "false_negatives": [],
    }
    # Check the individual results before proceeding.
    result_b = PrecisionRecallResult(**result_b_entries)
    exp_recall_b = 1.0  # 3 TPs, 0 FNs
    exp_prec_b = 1.0  # 3 TPs, 0 FPs
    assert result_b.recall == exp_recall_b
    assert result_b.precision == exp_prec_b

    # Create and check the delta results.
    delta_results = PrecisionRecallResultDelta(result_a=result_a, result_b=result_b)
    assert delta_results.recall_delta == exp_recall_b - exp_recall_a
    assert delta_results.recall_delta_pct == (exp_recall_b - exp_recall_a) / (exp_recall_a) * 100
    assert delta_results.precision_delta == exp_prec_b - exp_prec_a
    assert delta_results.precision_delta_pct == (exp_prec_b - exp_prec_a) / (exp_prec_a) * 100

    # Check the delta entries - these are: "in B but not in A"
    assert set(delta_results.true_positives_delta) == set(["d", "e"])
    assert delta_results.false_positives_delta == []
    assert delta_results.true_negatives_delta == ["b"]
    assert delta_results.false_negatives_delta == []
