"""Unit tests for the Segment library."""

# System imports
from math import floor
from typing import Final

# Third-party imports
import numpy as np
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.segment import (
    _EARLIEST_VALID_TIMESTAMP,
    _LATEST_VALID_TIMESTAMP,
    Segment,
    _is_between,
    _is_col_float_convertible,
    _is_col_present,
    filter_invalid_segments,
    filter_overlapping_segments,
)

_SAMPLE_VIN: Final[str] = "5G21A6P05P0000000"
_SAMPLE_TIMESTAMP_SECS: Final[int] = floor(pd.to_datetime("2025-01-31").timestamp()) + 1
_SAMPLE_DURATION_SECS: Final[int] = 10


@pytest.fixture
def sample_segment() -> Segment:
    return Segment.from_str(
        f"{_SAMPLE_VIN}:{str(_SAMPLE_TIMESTAMP_SECS)}:{_SAMPLE_TIMESTAMP_SECS + _SAMPLE_DURATION_SECS}"
    )


def test_is_between_true_inclusive() -> None:
    assert _is_between(val=0.0, start=0.0, end=0.0, inclusive=True) is True
    assert _is_between(val=0.0, start=0.0, end=1.0, inclusive=True) is True
    assert _is_between(val=1.0, start=0.0, end=1.0, inclusive=True) is True
    assert _is_between(val=0.5, start=0.0, end=1.0, inclusive=True) is True


def test_is_between_true_not_inclusive() -> None:
    assert _is_between(val=0.0, start=0.0, end=0.0, inclusive=False) is False
    assert _is_between(val=0.0, start=0.0, end=1.0, inclusive=False) is False
    assert _is_between(val=1.0, start=0.0, end=1.0, inclusive=False) is False
    assert _is_between(val=0.5, start=0.0, end=1.0, inclusive=False) is True


def test_is_between_false() -> None:
    inclusivity = [True, False]
    for inclusive in inclusivity:
        assert _is_between(val=1e-6, start=0.0, end=0.0, inclusive=inclusive) is False
        assert _is_between(val=-1e-6, start=0.0, end=1.0, inclusive=inclusive) is False
        assert _is_between(val=1.5, start=0.0, end=1.0, inclusive=inclusive) is False
        assert _is_between(val=-0.5, start=0.0, end=1.0, inclusive=inclusive) is False


def test_segment_init_from_str(sample_segment: Segment) -> None:
    assert sample_segment.vin == _SAMPLE_VIN
    assert np.allclose([_SAMPLE_DURATION_SECS], [sample_segment.duration])


def test_segment_combine_segments(sample_segment: Segment) -> None:
    """Tests combining two nearby segments together."""
    segment_additive_time_s = 9.0
    new_end_time_s = sample_segment.end_t_s + segment_additive_time_s
    other_segment = Segment(
        vin=sample_segment.vin, start_t_s=sample_segment.end_t_s, end_t_s=new_end_time_s
    )
    combined_segment = sample_segment.combine_segments(other=other_segment)
    assert np.allclose(
        [combined_segment.duration], [_SAMPLE_DURATION_SECS + segment_additive_time_s]
    )
    assert np.allclose([combined_segment.start_t_s], [sample_segment.start_t_s])
    assert np.allclose([combined_segment.end_t_s], [other_segment.end_t_s])


def test_segment_is_valid_default(sample_segment: Segment) -> None:
    assert sample_segment.is_valid() is True


def test_segment_is_valid_no_vin(sample_segment: Segment) -> None:
    sample_segment.vin = ""
    assert sample_segment.is_valid() is False


def test_segment_is_valid_incorrect_vin(sample_segment: Segment) -> None:
    sample_segment.vin = sample_segment.vin[:-1]
    assert sample_segment.is_valid() is False


def test_segment_is_valid_zero_duration(sample_segment: Segment) -> None:
    sample_segment.end_t_s = sample_segment.start_t_s
    assert sample_segment.is_valid() is False


def test_segment_is_valid_negative_duration(sample_segment: Segment) -> None:
    sample_segment.end_t_s = sample_segment.start_t_s - 1.0
    assert sample_segment.is_valid() is False


def test_segment_is_valid_start_too_old(sample_segment: Segment) -> None:
    sample_segment.start_t_s = _EARLIEST_VALID_TIMESTAMP - 1.0
    assert sample_segment.is_valid() is False


def test_segment_is_valid_start_too_new(sample_segment: Segment) -> None:
    sample_segment.end_t_s = _LATEST_VALID_TIMESTAMP + 1.0
    assert sample_segment.is_valid() is False


def test_filter_invalid_segments_empty() -> None:
    assert filter_invalid_segments(segment_ids=[]) == []


def test_filter_invalid_segments_invalid_single(sample_segment: Segment) -> None:
    # Make the end of the segment before the start, making it invalid.
    sample_segment.end_t_s = sample_segment.start_t_s - 10
    input_segment_id = str(sample_segment)
    filtered_segment_ids = filter_invalid_segments([input_segment_id])
    assert len(filtered_segment_ids) == 0


def test_filter_invalid_segments_valid_single(sample_segment: Segment) -> None:
    input_segment_id = str(sample_segment)
    filtered_segment_ids = filter_invalid_segments([input_segment_id])
    assert len(filtered_segment_ids) == 1
    assert input_segment_id in filtered_segment_ids


def test_is_col_present_series() -> None:
    series = pd.Series({"col_a": 1, "col_b": 2})
    assert _is_col_present(series, "col_a") is True
    assert _is_col_present(series, "col_b") is True
    assert _is_col_present(series, "col_c") is False


def test_is_col_present_dataframe() -> None:
    df = pd.DataFrame([{"col_a": 1, "col_b": 2}])
    assert _is_col_present(df, "col_a") is True
    assert _is_col_present(df, "col_b") is True
    assert _is_col_present(df, "col_c") is False


def test_is_col_float_convertible_series() -> None:
    series = pd.Series({"col_a": 1.0, "col_b": 2.0, "col_c": "1.2", "col_d": "a"})
    assert _is_col_float_convertible(series, "col_a") is True
    assert _is_col_float_convertible(series, "col_b") is True
    assert _is_col_float_convertible(series, "col_c") is True
    assert _is_col_float_convertible(series, "col_d") is False


def test_is_col_float_convertible_dataframe() -> None:
    df = pd.DataFrame([{"col_a": 1.0, "col_b": 2, "col_c": "blah"}])
    assert _is_col_float_convertible(df, "col_a") is True
    assert _is_col_float_convertible(df, "col_b") is True
    assert _is_col_float_convertible(df, "col_c") is False


def test_segment_from_pandas_row_valid(sample_segment: Segment) -> None:
    df = pd.DataFrame(
        [
            {
                "vin": sample_segment.vin,
                "start_time": sample_segment.start_t_s,
                "end_time": sample_segment.end_t_s,
            }
        ]
    )
    segment = Segment.from_pandas_row(df.iloc[0])
    assert segment.vin == sample_segment.vin
    assert segment.start_t_s == sample_segment.start_t_s
    assert segment.end_t_s == sample_segment.end_t_s


def test_segment_from_pandas_row_invalid(sample_segment: Segment) -> None:
    df = pd.DataFrame(
        [
            {
                "vin": sample_segment.vin,
                "start_time": sample_segment.start_t_s,
                "end_time": "blah",  # Invalid time.
            }
        ]
    )
    with pytest.raises(ValueError):
        Segment.from_pandas_row(df.iloc[0])


def test_filter_overlapping_segments_empty() -> None:
    assert filter_overlapping_segments([]) == []


def test_filter_overlapping_segments_singular(sample_segment: Segment) -> None:
    assert filter_overlapping_segments([str(sample_segment)]) == [str(sample_segment)]


def test_filter_overlapping_segments_duplicates(sample_segment: Segment) -> None:
    result = filter_overlapping_segments([str(sample_segment), str(sample_segment)])
    assert result == [str(sample_segment)]


def test_filter_overlapping_segments_multiple_no_overlap(sample_segment: Segment) -> None:
    first_segment = sample_segment
    second_segment = Segment.from_str(str(first_segment))
    # Adjust the second segment to have no overlap with the first.
    second_segment.start_t_s = first_segment.end_t_s + 1.0
    second_segment.end_t_s = second_segment.start_t_s + 1.0
    input = [str(first_segment), str(second_segment)]
    output = filter_overlapping_segments(input)
    # Since there's no overlap, there should be no filtering.
    assert output == input


def test_filter_overlapping_segments_same_time_diff_vin(sample_segment: Segment) -> None:
    first_segment = sample_segment
    second_segment = Segment.from_str(str(first_segment))
    # Adjust the second segment to have a different vin.
    second_segment.vin = second_segment.vin[:-1] + "9"
    input = [str(first_segment), str(second_segment)]
    output = filter_overlapping_segments(input)
    # Since the vins are different, there should be no filtering.
    assert output == input


def test_filter_overlapping_segments_multiple_small_overlap(sample_segment: Segment) -> None:
    first_segment = sample_segment
    second_segment = Segment.from_str(str(first_segment))
    # Adjust the second segment to have a small overlap with the first segment.
    eps = 1e-6
    second_segment.start_t_s = first_segment.end_t_s - eps
    second_segment.end_t_s = second_segment.start_t_s + 1.0
    input = [str(first_segment), str(second_segment)]
    output = filter_overlapping_segments(input)
    # The second segment should be filtered out since there is overlap.
    assert output == [str(first_segment)]


def test_segment_webviz_link() -> None:
    link = Segment(
        vin=_SAMPLE_VIN,
        start_t_s=_SAMPLE_TIMESTAMP_SECS - 5,
        end_t_s=_SAMPLE_TIMESTAMP_SECS + 5,
    ).webviz_link()
    assert isinstance(link, str)
    assert len(link) > 0
    assert "https://webviz.robot.car/" in link
    assert _SAMPLE_VIN in link
