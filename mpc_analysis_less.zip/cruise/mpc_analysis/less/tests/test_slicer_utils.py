"""Unit tests for the slicer_utils library."""

# System imports
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Final
from unittest import TestCase, mock

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.lgtm.attribute_store.jupyter_notebooks.nbutils.bq_utils import (
    LaunchKey,
    MissingGitHashError,
)
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.slicer_utils import (
    LessSlicerExecutionException,
    SlicerFramework,
    SlicerInputType,
    _allocate_road_results_output,
    _create_analyze_template,
    _get_sim_analysis_result_key,
    determine_input_type,
    determine_slicer_framework,
    generate_slicer_output_by_drive,
    is_valid_guid,
    is_valid_hydra_run_id,
    run_slicer_on_road_data,
    run_slicer_on_sim_data,
    trim_scene_slicer_output_to_timerange,
)
from cruise.mpc_analysis.less.tests.fixtures import FakeBigQueryClient, FakeSimAnalysisRunner

_LAUNCH_KEY_1 = LaunchKey(
    vin="5G21A6P05P0111111",
    launch_id="111111AAAAAA",
    start_date="2025-01-01",  # unix secs: 1735689600
    end_date="2025-01-02",  # unix secs: 1735776000
    is_commercial_logging=False,
)

_LAUNCH_KEY_2 = LaunchKey(
    vin="5G21A6P05P0222222",
    launch_id="222222BBBBBB",
    start_date="2025-02-15",  # unix secs: 1739577600
    end_date="2025-02-16",  # unix secs: 1739664000
    is_commercial_logging=False,
)

_SEGMENT_1 = Segment(_LAUNCH_KEY_1.vin, 1735715421, 1735715434)
_SEGMENT_2 = Segment(_LAUNCH_KEY_1.vin, 1735751212, 1735751294)
_SEGMENT_3 = Segment(_LAUNCH_KEY_2.vin, 1739577600, 1739664000)


_SAMPLE_VALID_GUID: Final[str] = "1aad219d-7b78-4ae7-9c18-f2da01c7ce21"
_SAMPLE_HYDRA_RUN_ID: Final[str] = f"{_SAMPLE_VALID_GUID}:0"


_SLICER_RESULTS = pd.DataFrame(
    data=[
        [
            _LAUNCH_KEY_1.launch_id,
            _LAUNCH_KEY_1.vin,
            pd.Timestamp(1735715407, unit="s", tz="utc"),  # Overlap Seg 1
            pd.Timestamp(1735715429, unit="s", tz="utc"),  # Overalp Seg 1
        ],
        [
            _LAUNCH_KEY_1.launch_id,
            _LAUNCH_KEY_1.vin,
            pd.Timestamp(1735751201, unit="s", tz="utc"),  # Overlap Seg 2
            pd.Timestamp(1735751297, unit="s", tz="utc"),  # Overlap Seg 2
        ],
        [
            _LAUNCH_KEY_1.launch_id,
            _LAUNCH_KEY_1.vin,
            pd.Timestamp(1735774217, unit="s", tz="utc"),  # No Match
            pd.Timestamp(1735774432, unit="s", tz="utc"),  # No Match
        ],
        [
            _LAUNCH_KEY_2.launch_id,
            _LAUNCH_KEY_2.vin,
            pd.Timestamp(1739577600, unit="s", tz="utc"),  # Exact match Seg 3
            pd.Timestamp(1739664000, unit="s", tz="utc"),  # Exact match Seg 3
        ],
    ],
    index=[0, 1, 2, 3],
    columns=["_launch_id", "_vin", "start_time", "end_time"],
)

_FAKE_SLICER_NAME = "av_in_unit_test_scene"
_SLICER_NAME = "av_in_driveable_area_scene"


def _make_scene_slicer_df(start_times: list[float], end_times: list[float]) -> pd.DataFrame:
    """Helper to create a fake scene slicer dataframe from event start/end times."""
    event_start_timestamps = map(lambda x: pd.Timestamp(x, unit="s", tz="UTC"), start_times)
    event_end_timestamps = map(lambda x: pd.Timestamp(x, unit="s", tz="UTC"), end_times)
    return pd.DataFrame({"start_time": event_start_timestamps, "end_time": event_end_timestamps})


def test_trim_scene_slicer_to_timerange_none_in_range() -> None:
    """Tests the case when the slicer output is not within the range given."""
    segment_start_s = 170000000.0
    segment_end_s = 170000010.0
    input_scene_start_s = segment_end_s + 10.0
    input_scene_end_s = segment_end_s + 20.0
    slicer_output_df = _make_scene_slicer_df(
        start_times=[input_scene_start_s], end_times=[input_scene_end_s]
    )
    trimmed_df = trim_scene_slicer_output_to_timerange(
        result_df=slicer_output_df,
        start_time_s=segment_start_s,
        end_time_s=segment_end_s,
    )
    assert trimmed_df.empty


def test_trim_scene_slicer_to_timerange_completely_within() -> None:
    """Tests the case when the slicer output is completely within the range given."""
    segment_start_s = 170000000.0
    segment_end_s = 170000010.0
    input_scene_start_s = segment_start_s + 1.0
    input_scene_end_s = segment_end_s - 1.0
    slicer_output_df = _make_scene_slicer_df(
        start_times=[input_scene_start_s], end_times=[input_scene_end_s]
    )
    trimmed_df = trim_scene_slicer_output_to_timerange(
        result_df=slicer_output_df,
        start_time_s=segment_start_s,
        end_time_s=segment_end_s,
    )
    assert len(trimmed_df) == 1
    adjusted_scene_start_s = trimmed_df["start_time"].iloc[0].timestamp()
    adjusted_scene_end_s = trimmed_df["end_time"].iloc[0].timestamp()
    # Input scene is completely within the segment so verify no adjustments to the input timestamps.
    assert adjusted_scene_start_s == input_scene_start_s
    assert adjusted_scene_end_s == input_scene_end_s


def test_trim_scene_slicer_to_timerange_extends_beyond_end() -> None:
    """Tests the case when the slicer output extends beyond the end of the range."""
    segment_start_s = 170000000.0
    segment_end_s = 170000010.0
    input_scene_start_s = segment_start_s + 1.0
    input_scene_end_s = segment_end_s + 1.0
    slicer_output_df = _make_scene_slicer_df(
        start_times=[input_scene_start_s], end_times=[input_scene_end_s]
    )
    trimmed_df = trim_scene_slicer_output_to_timerange(
        result_df=slicer_output_df,
        start_time_s=segment_start_s,
        end_time_s=segment_end_s,
    )
    assert len(trimmed_df) == 1
    adjusted_scene_start_s = trimmed_df["start_time"].iloc[0].timestamp()
    adjusted_scene_end_s = trimmed_df["end_time"].iloc[0].timestamp()
    # Input scene start falls within the segment so adjusted should match the input.
    assert adjusted_scene_start_s == input_scene_start_s
    # Input scene end falls outside the segment, adjusted should be capped at the segment end.
    assert adjusted_scene_end_s != input_scene_end_s
    assert adjusted_scene_end_s == segment_end_s


def test_trim_scene_slicer_to_timerange_extends_before_start() -> None:
    """Tests the case when the slicer output extends before the start of the range."""
    segment_start_s = 170000000.0
    segment_end_s = 170000010.0
    input_scene_start_s = segment_start_s - 1.0
    input_scene_end_s = segment_end_s - 1.0
    slicer_output_df = _make_scene_slicer_df(
        start_times=[input_scene_start_s], end_times=[input_scene_end_s]
    )
    trimmed_df = trim_scene_slicer_output_to_timerange(
        result_df=slicer_output_df,
        start_time_s=segment_start_s,
        end_time_s=segment_end_s,
    )
    assert len(trimmed_df) == 1
    adjusted_scene_start_s = trimmed_df["start_time"].iloc[0].timestamp()
    # Input scene start falls outside the segment so adjusted should be capped to the segment start.
    assert adjusted_scene_start_s != input_scene_start_s
    assert adjusted_scene_start_s == segment_start_s

    adjusted_scene_end_s = trimmed_df["end_time"].iloc[0].timestamp()
    # Input scene start falls within the segment so adjusted should match the input.
    assert adjusted_scene_end_s == input_scene_end_s


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_launch_key_from_segment_ids",
    return_value={str(_SEGMENT_1): _LAUNCH_KEY_1},
)
def test_run_slicer_on_road_data_single_segment_no_rerun(
    mock_get_launch_key_from_segment_ids: mock.Mock,
    mock_big_query_client: mock.Mock,
) -> None:
    mock_big_query_client.return_value.output = _SLICER_RESULTS.iloc[:3]
    results = run_slicer_on_road_data(
        input_ids=[str(_SEGMENT_1)],
        slicer_name=_SLICER_NAME,
        rerun_slicer=False,
        convert_datetimes=False,
    )
    assert mock_get_launch_key_from_segment_ids.call_count == 1
    assert mock_big_query_client.call_count == 1

    assert len(results) == 1
    assert results[0].input_id == str(_SEGMENT_1)
    assert results[0].slicer_output["_launch_id"].iloc[0] == _LAUNCH_KEY_1.launch_id
    # Slicer output event start time is before the segment start so it should be capped by the segment bounds.
    assert results[0].slicer_output["start_time"].iloc[0].timestamp() == _SEGMENT_1.start_t_s
    assert results[0].slicer_output["end_time"].iloc[0].timestamp() == 1735715429  # From slicer


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_launch_key_from_segment_ids",
    return_value={str(_SEGMENT_1): _LAUNCH_KEY_1},
)
@mock.patch("cruise.mpc_analysis.less.slicer_utils.get_road_bigquery_sql")
def test_run_slicer_on_road_data_single_segment_with_rerun(
    mock_get_road_bigquery_sql: mock.Mock,
    mock_get_launch_key_from_segment_ids: mock.Mock,
    mock_bq_client: mock.Mock,
) -> None:
    # We don't actually need a return value for mock_get_road_bigquery_sql, since it's just
    # building the SQL query that's passed to get_road_bigquery_sql (which is itself mocked).
    # However, it makes some SQL calls itself, so if we don't mock it, we run into issues
    # with attempting the query to an external resource.
    # Since it's part of an upstream library, we leave the unit testing to them.
    mock_bq_client.return_value.output = _SLICER_RESULTS

    results = run_slicer_on_road_data(
        input_ids=[str(_SEGMENT_1)],
        slicer_name=_SLICER_NAME,
        rerun_slicer=True,
        convert_datetimes=False,
    )

    assert mock_get_road_bigquery_sql.call_count == 1
    assert mock_get_launch_key_from_segment_ids.call_count == 1
    assert mock_bq_client.call_count == 1

    assert len(results) == 1
    assert results[0].input_id == str(_SEGMENT_1)
    assert results[0].slicer_output["_launch_id"].iloc[0] == _LAUNCH_KEY_1.launch_id
    # Slicer output event start time is before the segment start so it should be capped by the segment bounds.
    assert results[0].slicer_output["start_time"].iloc[0].timestamp() == _SEGMENT_1.start_t_s
    assert results[0].slicer_output["end_time"].iloc[0].timestamp() == 1735715429  # From slicer


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_launch_key_from_segment_ids",
    return_value={
        str(_SEGMENT_1): _LAUNCH_KEY_1,
        str(_SEGMENT_2): _LAUNCH_KEY_1,
        str(_SEGMENT_3): _LAUNCH_KEY_2,
    },
)
def test_run_slicers_on_road_data_multiple_segments_no_rerun(
    mock_get_launch_key_from_segment_ids: mock.Mock,
    mock_bq_client: mock.Mock,
) -> None:
    mock_bq_client.return_value.output = _SLICER_RESULTS
    results = run_slicer_on_road_data(
        input_ids=[str(_SEGMENT_1), str(_SEGMENT_2), str(_SEGMENT_3)],
        slicer_name=_SLICER_NAME,
        rerun_slicer=False,
        convert_datetimes=False,
    )

    assert mock_get_launch_key_from_segment_ids.call_count == 1
    assert mock_bq_client.call_count == 1

    assert len(results) == 3
    results.sort(key=lambda x: str(x.input_id))

    assert results[0].input_id == str(_SEGMENT_1)
    assert results[0].slicer_output["_launch_id"].iloc[0] == _LAUNCH_KEY_1.launch_id
    assert results[0].slicer_output["start_time"].iloc[0].timestamp() == _SEGMENT_1.start_t_s
    assert results[0].slicer_output["end_time"].iloc[0].timestamp() == 1735715429  # From slicer

    assert results[1].input_id == str(_SEGMENT_2)
    assert results[1].slicer_output["_launch_id"].iloc[0] == _LAUNCH_KEY_1.launch_id
    assert results[1].slicer_output["start_time"].iloc[0].timestamp() == _SEGMENT_2.start_t_s
    assert results[1].slicer_output["end_time"].iloc[0].timestamp() == _SEGMENT_2.end_t_s

    assert results[2].input_id == str(_SEGMENT_3)
    assert results[2].slicer_output["_launch_id"].iloc[0] == _LAUNCH_KEY_2.launch_id
    assert results[2].slicer_output["start_time"].iloc[0].timestamp() == _SEGMENT_3.start_t_s
    assert results[2].slicer_output["end_time"].iloc[0].timestamp() == _SEGMENT_3.end_t_s


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_launch_key_from_launch_ids",
    return_value={_LAUNCH_KEY_1.launch_id: _LAUNCH_KEY_1},
)
def test_run_slicers_on_road_data_single_drive_no_rerun(
    mock_get_launch_key_from_launch_ids: mock.Mock,
    mock_bq_client: mock.Mock,
) -> None:
    mock_bq_client.return_value.output = _SLICER_RESULTS
    input_launch_id = _LAUNCH_KEY_1.launch_id
    results = run_slicer_on_road_data(
        input_ids=[input_launch_id],
        slicer_name=_SLICER_NAME,
        rerun_slicer=False,
        convert_datetimes=False,
    )
    assert mock_get_launch_key_from_launch_ids.call_count == 1
    assert mock_bq_client.call_count == 1

    assert len(results) == 1
    assert input_launch_id == results[0].input_id
    exp_slicer_output = _SLICER_RESULTS[_SLICER_RESULTS["_launch_id"] == input_launch_id]
    assert exp_slicer_output.equals(results[0].slicer_output)


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_road_bigquery_sql",
    return_value="",  # This doesn't matter since we mock execution anyhow
)
@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_generate_slicer_output_by_drive_unknown_exception_in_executing_query(
    mock_bq_client: mock.Mock,
    mock_get_road_bigquery_sql: mock.Mock,
) -> None:
    # Override the mocked big query client to raise an exception.
    def run_query_raise_func(query: str) -> None:
        raise Exception

    mock_bq_client.return_value.run_query_and_get_dataframe = run_query_raise_func
    output_results = _allocate_road_results_output(
        input_ids=[_LAUNCH_KEY_1.launch_id],
        launch_key_map={_LAUNCH_KEY_1.launch_id: _LAUNCH_KEY_1},
    )
    with TestCase().assertRaises(LessSlicerExecutionException):
        generate_slicer_output_by_drive(
            slicer_name=_SLICER_NAME,
            input_to_launch_key_map={_LAUNCH_KEY_1.launch_id: _LAUNCH_KEY_1},
            slicer_exec_results=output_results,
            rerun_slicer=True,
        )

    assert mock_get_road_bigquery_sql.call_count == 1
    assert mock_bq_client.call_count == 1


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_road_bigquery_sql",
    side_effect=MissingGitHashError,
)
@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.LessBigQueryClient",
    return_value=FakeBigQueryClient(),
)
def test_generate_slicer_output_by_drive_known_exception_in_generating_query(
    mock_bq_client: mock.Mock,
    mock_get_road_bigquery_sql: mock.Mock,
) -> None:
    output_results = _allocate_road_results_output(
        input_ids=[_LAUNCH_KEY_1.launch_id],
        launch_key_map={_LAUNCH_KEY_1.launch_id: _LAUNCH_KEY_1},
    )
    generate_slicer_output_by_drive(
        slicer_name=_SLICER_NAME,
        input_to_launch_key_map={_LAUNCH_KEY_1.launch_id: _LAUNCH_KEY_1},
        slicer_exec_results=output_results,
        rerun_slicer=True,
    )

    assert mock_get_road_bigquery_sql.call_count == 1
    # The query generation failed, so there's nothing to execute
    assert mock_bq_client.call_count == 0


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_road_bigquery_sql",
    side_effect=Exception,
)
@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.LessBigQueryClient",
    return_value=FakeBigQueryClient(),
)
def test_generate_slicer_output_by_drive_unknown_exception_in_generating_query(
    mock_execute_query_and_get_dataframe: mock.Mock,
    mock_get_road_bigquery_sql: mock.Mock,
) -> None:
    output_results = _allocate_road_results_output(
        input_ids=[_LAUNCH_KEY_1.launch_id],
        launch_key_map={_LAUNCH_KEY_1.launch_id: _LAUNCH_KEY_1},
    )
    with TestCase().assertRaises(LessSlicerExecutionException):
        generate_slicer_output_by_drive(
            slicer_name=_SLICER_NAME,
            input_to_launch_key_map={_LAUNCH_KEY_1.launch_id: _LAUNCH_KEY_1},
            slicer_exec_results=output_results,
            rerun_slicer=True,
        )

    assert mock_get_road_bigquery_sql.call_count == 1
    # The query generation failed, so there's nothing to execute
    assert mock_execute_query_and_get_dataframe.call_count == 0


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.SimAnalysisRunner", return_value=FakeSimAnalysisRunner()
)
def test_run_slicer_on_sim_data_no_result(mock_sim_analysis_runner: mock.Mock) -> None:
    slicer_execution_results = run_slicer_on_sim_data(
        input_ids=[_SAMPLE_HYDRA_RUN_ID],
        slicer_name=_SLICER_NAME,
        rerun_slicer=True,
        convert_datetimes=True,
    )
    assert len(slicer_execution_results) == 1
    assert slicer_execution_results[0].was_successfully_executed is False
    assert slicer_execution_results[0].error_msg is not None
    assert "Slicer result not found" in slicer_execution_results[0].error_msg
    assert slicer_execution_results[0].slicer_output.empty is True


@mock.patch("cruise.mpc_analysis.less.slicer_utils.SimAnalysisRunner")
def test_run_slicer_on_sim_data_no_output(mock_sim_analysis_runner: mock.Mock) -> None:
    fake_runner = FakeSimAnalysisRunner()
    result_key = _get_sim_analysis_result_key(
        slicer_name=_SLICER_NAME, slicer_framework=SlicerFramework.LGTM1
    )
    fake_runner.slicer_output = {result_key: pd.DataFrame()}
    mock_sim_analysis_runner.return_value = fake_runner
    slicer_execution_results = run_slicer_on_sim_data(
        input_ids=[_SAMPLE_HYDRA_RUN_ID],
        slicer_name=_SLICER_NAME,
        rerun_slicer=True,
        convert_datetimes=True,
    )
    assert len(slicer_execution_results) == 1
    assert slicer_execution_results[0].was_successfully_executed is True
    assert slicer_execution_results[0].error_msg is None
    assert slicer_execution_results[0].slicer_output.empty is True


@mock.patch("cruise.mpc_analysis.less.slicer_utils.SimAnalysisRunner")
def test_run_slicer_on_sim_data_with_output(mock_sim_analysis_runner: mock.Mock) -> None:
    fake_runner = FakeSimAnalysisRunner()
    slicer_key = _get_sim_analysis_result_key(
        slicer_name=_SLICER_NAME, slicer_framework=SlicerFramework.LGTM1
    )
    fake_runner.slicer_output[slicer_key] = pd.DataFrame(
        [
            {
                "input_id": _SAMPLE_HYDRA_RUN_ID,
                "start_time": 0.0,
                "end_time": 15.0,
            }
        ]
    )
    mock_sim_analysis_runner.return_value = fake_runner

    slicer_execution_results = run_slicer_on_sim_data(
        input_ids=[_SAMPLE_HYDRA_RUN_ID],
        slicer_name=_SLICER_NAME,
        rerun_slicer=True,
        convert_datetimes=True,
    )
    assert len(slicer_execution_results) == 1
    assert slicer_execution_results[0].was_successfully_executed is True
    assert slicer_execution_results[0].slicer_output.empty is False
    assert slicer_execution_results[0].slicer_output.equals(fake_runner.slicer_output[slicer_key])


def test_is_valid_guid() -> None:
    # Valid values
    assert is_valid_guid(_SAMPLE_VALID_GUID) is True
    assert is_valid_guid(_SAMPLE_VALID_GUID.upper()) is True
    assert is_valid_guid("{" + _SAMPLE_VALID_GUID + "}") is True

    # Invalid values

    # Remove dashes.
    invalid_guid = _SAMPLE_VALID_GUID.replace("-", "")
    assert is_valid_guid(invalid_guid) is False

    # Add extra value
    assert is_valid_guid(_SAMPLE_VALID_GUID + "a") is False


def test_is_valid_hydra_run_id() -> None:
    valid_suffixes = [":1", ":100", ":100001"]

    ## Valid values
    assert is_valid_hydra_run_id(_SAMPLE_HYDRA_RUN_ID) is True
    for suffix in valid_suffixes:
        assert is_valid_hydra_run_id(_SAMPLE_VALID_GUID + suffix) is True

    ## Invalid values

    # Just a guid by itself.
    assert is_valid_hydra_run_id(_SAMPLE_VALID_GUID) is False

    # Add subtask without colon
    assert is_valid_guid(_SAMPLE_VALID_GUID + "1") is False

    # Add lettered subtask
    assert is_valid_guid(_SAMPLE_VALID_GUID + ":a") is False


def test_determine_input_type() -> None:
    assert determine_input_type(_SAMPLE_HYDRA_RUN_ID) == SlicerInputType.HYDRA_RUN_ID
    assert determine_input_type(_SAMPLE_VALID_GUID) == SlicerInputType.LAUNCH_ID
    assert determine_input_type(str(_SEGMENT_1)) == SlicerInputType.SEGMENT_ID

    invalid_guid = _SAMPLE_VALID_GUID.replace("-", "")
    with pytest.raises(ValueError):
        determine_input_type(invalid_guid)


def test_create_analyze_template_lgtm1() -> None:
    """Test that we can create a analyze template for an LGTM1 slicer without crashing"""
    with TemporaryDirectory() as tmp_dir:
        analyze_template_path = Path(tmp_dir) / "template.yaml"
        _create_analyze_template(
            slicer_name=_SLICER_NAME,
            slicer_framework=SlicerFramework.LGTM1,
            template_path=analyze_template_path,
        )


def test_create_analyze_template_lgtm2() -> None:
    """Test that we can create a analyze template for an LGTM2 slicer without crashing"""
    with TemporaryDirectory() as tmp_dir:
        analyze_template_path = Path(tmp_dir) / "template.yaml"
        _create_analyze_template(
            slicer_name=_SLICER_NAME,
            slicer_framework=SlicerFramework.LGTM2,
            template_path=analyze_template_path,
        )


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_valid_slicer_def_names",
    return_value=[_FAKE_SLICER_NAME],
)
def test_determine_slicer_framework_prefer_lgtm2(lgtm1_slicer_names_mock: mock.Mock) -> None:
    """Test that if a slicer exists in both LGTM1 & LGTM2, LGTM2 slicer is preferred."""

    class FakeSlicer:
        def __init__(self) -> None:
            self.name = _FAKE_SLICER_NAME

    class FakeSlicerRegistry:
        def __init__(self) -> None:
            self.slicers = [FakeSlicer()]

    with mock.patch(
        "cruise.mpc_analysis.less.slicer_utils.SIM_REGISTRY",
        FakeSlicerRegistry(),
    ):
        result = determine_slicer_framework(slicer_name=_FAKE_SLICER_NAME)
    assert result == SlicerFramework.LGTM2


@mock.patch(
    "cruise.mpc_analysis.less.slicer_utils.get_valid_slicer_def_names",
    return_value=[_FAKE_SLICER_NAME],
)
def test_determine_slicer_framework_lgtm1(lgtm1_slicer_names_mock: mock.Mock) -> None:
    """Test that if a slicer exists only in LGTM1, LGTM1 framework is returned."""
    assert determine_slicer_framework(slicer_name=_FAKE_SLICER_NAME) == SlicerFramework.LGTM1
    assert lgtm1_slicer_names_mock.call_count == 1


def test_determine_slicer_framework_invalid_slicer_raises() -> None:
    """Test that an exception is raised if the slicer can't be found."""

    with pytest.raises(ValueError):
        determine_slicer_framework(slicer_name=_FAKE_SLICER_NAME)
