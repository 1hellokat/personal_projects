"""Unit test for the LESS visualization library.

Most of this library involves printing to the terminal so the unit test will mostly consist of
excercising the functions.
"""

# System imports
from math import nan
from typing import Final

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.precision_recall_utils import PrecisionRecallResult
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.visualization import (
    print_dataframe_in_terminal,
    print_prec_recall_confusion_matrix,
    print_prec_recall_detailed_results,
    print_prec_recall_false_results_webviz_links,
    print_prec_recall_results,
    webviz_link_from_row,
)

_SAMPLE_VIN: Final[str] = "5G21A6P05P0000000"
_SAMPLE_SLICER_NAME: Final[str] = "av_in_imaginary_scene"
_SEGMENT_START_TIME: Final[int] = 1730730000
_SEGMENT_END_TIME: Final[int] = 1730730010
_SEGMENT_ID_1: Final[str] = f"5G21A6P05P0111111:{_SEGMENT_START_TIME + 1}:{_SEGMENT_END_TIME + 1}"
_SEGMENT_ID_2: Final[str] = f"5G21A6P05P0111111:{_SEGMENT_START_TIME + 2}:{_SEGMENT_END_TIME + 2}"
_SEGMENT_ID_3: Final[str] = f"5G21A6P05P0111111:{_SEGMENT_START_TIME + 3}:{_SEGMENT_END_TIME + 3}"
_SEGMENT_ID_4: Final[str] = f"5G21A6P05P0111111:{_SEGMENT_START_TIME + 4}:{_SEGMENT_END_TIME + 4}"


@pytest.fixture
def sample_dataframe() -> pd.DataFrame:
    frame_entries = [
        {
            "col_1": "string_val",
            "col_2": 100,
            "col_3": float(100),
        },
        {
            # Missing col_1
            "col_2": -1,
            "col_3": nan,
        },
    ]
    return pd.DataFrame(frame_entries)


@pytest.fixture
def empty_prec_recall_result() -> PrecisionRecallResult:
    return PrecisionRecallResult(
        true_positives=[],
        false_positives=[],
        true_negatives=[],
        false_negatives=[],
    )


@pytest.fixture
def sample_prec_recall_result() -> PrecisionRecallResult:
    return PrecisionRecallResult(
        true_positives=[_SEGMENT_ID_1],
        false_positives=[_SEGMENT_ID_2],
        true_negatives=[_SEGMENT_ID_3],
        false_negatives=[_SEGMENT_ID_4],
    )


def test_print_dataframe_in_terminal_empty() -> None:
    print_dataframe_in_terminal(pd.DataFrame())


def test_print_dataframe_in_terminal_populated(sample_dataframe: pd.DataFrame) -> None:
    print_dataframe_in_terminal(sample_dataframe)


def test_print_prec_recall_confusion_matrix_empty(
    empty_prec_recall_result: PrecisionRecallResult,
) -> None:
    print_prec_recall_confusion_matrix(
        pr_result=empty_prec_recall_result, slicer_name=_SAMPLE_SLICER_NAME
    )


def test_print_prec_recall_confusion_matrix(
    sample_prec_recall_result: PrecisionRecallResult,
) -> None:
    print_prec_recall_confusion_matrix(
        pr_result=sample_prec_recall_result, slicer_name=_SAMPLE_SLICER_NAME
    )


def test_print_prec_recall_detailed_results_empty(
    empty_prec_recall_result: PrecisionRecallResult,
) -> None:
    print_prec_recall_detailed_results(
        pr_result=empty_prec_recall_result, slicer_name=_SAMPLE_SLICER_NAME
    )


def test_print_prec_recall_detailed_results(
    sample_prec_recall_result: PrecisionRecallResult,
) -> None:
    print_prec_recall_detailed_results(
        pr_result=sample_prec_recall_result, slicer_name=_SAMPLE_SLICER_NAME
    )


def test_print_prec_recall_false_results_webviz_links_empty(
    empty_prec_recall_result: PrecisionRecallResult,
) -> None:
    print_prec_recall_false_results_webviz_links(pr_result=empty_prec_recall_result)


def test_print_prec_recall_false_results_webviz_links(
    sample_prec_recall_result: PrecisionRecallResult,
) -> None:
    print_prec_recall_false_results_webviz_links(pr_result=sample_prec_recall_result)


def test_print_prec_recall_results_empty(empty_prec_recall_result: PrecisionRecallResult) -> None:
    print_prec_recall_results(pr_result=empty_prec_recall_result, slicer_name=_SAMPLE_SLICER_NAME)


def test_print_prec_recall_results(sample_prec_recall_result: PrecisionRecallResult) -> None:
    print_prec_recall_results(pr_result=sample_prec_recall_result, slicer_name=_SAMPLE_SLICER_NAME)


def test_webviz_link_from_row() -> None:
    segment = Segment(vin=_SAMPLE_VIN, start_t_s=_SEGMENT_START_TIME, end_t_s=_SEGMENT_END_TIME)
    df = pd.DataFrame(
        [
            {
                "vin": segment.vin,
                "start_time": segment.start_t_s,
                "end_time": segment.end_t_s,
            }
        ]
    )
    link = webviz_link_from_row(row=df.iloc[0])
    assert isinstance(link, str)
    assert len(link) > 0
    assert "https://webviz.robot.car/" in link
    assert _SAMPLE_VIN in link
