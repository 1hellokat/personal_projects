"""Unit tests for the labels dailyflow library."""

# System imports
import datetime
import json
import uuid
from typing import Final
from unittest import mock

# Third-party imports
import numpy as np
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.labels.dailyflow import (
    DFLabelsetRegistry,
    _is_valid_raw_dailyflow_label,
    _unpack_dailyflow_scene_quality_labels,
    create_dailyflow_labelset,
    get_dailyflow_labels,
    get_dailyflow_labelset_registry_info,
)
from cruise.mpc_analysis.less.labels.label_schema import SceneSlicerLabel
from cruise.mpc_analysis.less.tests.fixtures import FakeBigQueryClient

_LABELSET_NAME: Final[str] = "some_labelset"
_SLICER_NAME: Final[str] = "av_in_unit_test_scene"
_TASK_QUEUE_ID: Final[int] = 1234
_SEGMENT_START_TIME: Final[int] = 1730730000
_SEGMENT_END_TIME: Final[int] = 1730730010
_SAMPLE_SEGMENT_ID: Final[str] = f"5G21A6P05P0111111:{_SEGMENT_START_TIME}:{_SEGMENT_END_TIME}"


@pytest.fixture
def raw_dailyflow_labels() -> pd.DataFrame:
    entry = {
        "segment_id": _SAMPLE_SEGMENT_ID,
        "task_queue_id": _TASK_QUEUE_ID,
        "road_event_id": _SAMPLE_SEGMENT_ID,
        "task_id": 123456,
        "metadata": json.dumps({"uuid": str(uuid.uuid4())}),
        "labeled_data": json.dumps(
            {
                "eventInSegment": "Yes",
                "startTime": float(_SEGMENT_START_TIME),
                "endTime": float(_SEGMENT_END_TIME),
                "additionalEvents": "No",
            }
        ),
    }
    return pd.DataFrame([entry])


class FakeDailyFlow:
    """Fake class for the scenariokit-dailyflow connector"""

    def create_task_queue(self, **kwargs) -> int:
        return 100


def test_labelset_registry_struct() -> None:
    user = "john.doe"
    timestamp = datetime.datetime.now()

    registry_obj = DFLabelsetRegistry(
        labelset_name=_LABELSET_NAME,
        slicer_name=_SLICER_NAME,
        task_queue_id=_TASK_QUEUE_ID,
        created_by_user=user,
        created_timestamp=timestamp,
    )
    insert_query = registry_obj.get_insert_query(table_name="some_fake_table")
    assert _LABELSET_NAME in insert_query
    assert _SLICER_NAME in insert_query
    assert str(_TASK_QUEUE_ID) in insert_query
    assert user in insert_query


@mock.patch(
    "cruise.mpc_analysis.less.labels.common_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_get_dailyflow_labelset_registry_info_no_labelset(execute_query_mock: mock.Mock) -> None:
    result_df = get_dailyflow_labelset_registry_info()
    assert execute_query_mock.call_count == 1
    assert result_df.empty is True


@mock.patch(
    "cruise.mpc_analysis.less.labels.common_utils.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_get_dailyflow_labelset_registry_info_with_labelset(execute_query_mock: mock.Mock) -> None:
    result_df = get_dailyflow_labelset_registry_info(labelset_name=_LABELSET_NAME)
    assert execute_query_mock.call_count == 1
    assert result_df.empty is True


@mock.patch(
    "cruise.mpc_analysis.less.labels.dailyflow.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
@mock.patch("cruise.mpc_analysis.less.labels.dailyflow.DailyFlow", return_value=FakeDailyFlow())
def test_create_dailyflow_labelset_no_task_queue(
    dailyflow_connector_mock: mock.Mock, execute_query_mock: mock.Mock
) -> None:
    create_dailyflow_labelset(labelset_name=_LABELSET_NAME, slicer_name=_SLICER_NAME)
    assert execute_query_mock.call_count == 1
    assert dailyflow_connector_mock.call_count == 1


@mock.patch(
    "cruise.mpc_analysis.less.labels.dailyflow.LessBigQueryClient.init_from_vault",
    return_value=FakeBigQueryClient(),
)
def test_create_dailyflow_labelset_with_task_queue(execute_query_mock: mock.Mock) -> None:
    result = create_dailyflow_labelset(
        labelset_name=_LABELSET_NAME,
        slicer_name=_SLICER_NAME,
        existing_task_queue_id=_TASK_QUEUE_ID,
    )
    assert execute_query_mock.call_count == 1
    assert result is None


def test_is_valid_raw_dailyflow_label_valid(raw_dailyflow_labels: pd.DataFrame) -> None:
    assert _is_valid_raw_dailyflow_label(row=raw_dailyflow_labels.iloc[0]) is True


def test_is_valid_raw_dailyflow_label_missing_fields(raw_dailyflow_labels: pd.DataFrame) -> None:
    # Remove each of these fields and ensure they are marked invalid.
    for col in ["metadata", "task_id", "segment_id", "task_queue_id", "road_event_id"]:
        raw_label_df = raw_dailyflow_labels.drop(columns=[col])
        assert _is_valid_raw_dailyflow_label(row=raw_label_df.iloc[0]) is False


def test_is_valid_raw_dailyflow_label_missing_label_data(
    raw_dailyflow_labels: pd.DataFrame,
) -> None:
    row = raw_dailyflow_labels.iloc[0]
    row["labeled_data"] = "{}"
    assert _is_valid_raw_dailyflow_label(row=row) is False


def test_is_valid_raw_dailyflow_label_empty_meta(raw_dailyflow_labels: pd.DataFrame) -> None:
    row = raw_dailyflow_labels.iloc[0]
    row["metadata"] = "{}"
    assert _is_valid_raw_dailyflow_label(row=row) is False


def test_is_valid_raw_dailyflow_label_missing_label_fields(
    raw_dailyflow_labels: pd.DataFrame,
) -> None:
    row = raw_dailyflow_labels.iloc[0]
    assert _is_valid_raw_dailyflow_label(row=row) is True
    # Remove each of these fields and ensure they are marked invalid.
    for field in ["eventInSegment", "startTime", "endTime", "additionalEvents"]:
        labeled_data = json.loads(str(row["labeled_data"]))
        labeled_data.pop(field)
        row["labeled_data"] = json.dumps(labeled_data)
    assert _is_valid_raw_dailyflow_label(row=row) is False


def test_unpack_dailyflow_scene_quality_labels_valid(raw_dailyflow_labels: pd.DataFrame) -> None:
    labels = _unpack_dailyflow_scene_quality_labels(raw_labels_df=raw_dailyflow_labels)
    assert len(labels) == 1
    assert labels[0].is_event_in_segment is True
    assert labels[0].event_start_s == _SEGMENT_START_TIME
    assert labels[0].event_end_s == _SEGMENT_END_TIME


def test_unpack_dailyflow_scene_quality_labels_invalid(raw_dailyflow_labels: pd.DataFrame) -> None:
    labeled_data = json.loads(str(raw_dailyflow_labels.iloc[0]["labeled_data"]))
    # Move the start time to before the segment bounds to invalidate it.
    labeled_data["startTime"] = _SEGMENT_START_TIME - 1.0
    raw_dailyflow_labels.at[0, "labeled_data"] = json.dumps(labeled_data)
    labels = _unpack_dailyflow_scene_quality_labels(raw_labels_df=raw_dailyflow_labels)
    # Label should have been discarded as invalid.
    assert len(labels) == 0


@mock.patch(
    "cruise.mpc_analysis.less.labels.dailyflow.get_dailyflow_labelset_registry_info",
    return_value=pd.DataFrame(),
)
def test_get_tpo_labels_empty(get_tpo_labelset_info_mock: mock.Mock) -> None:
    """Test case with no task queue IDs provided, early exit for no registered labelsets (mocked)."""
    labels_df = get_dailyflow_labels(schema_type=SceneSlicerLabel)
    assert labels_df.empty is True
    assert get_tpo_labelset_info_mock.call_count == 1


@mock.patch(
    "cruise.mpc_analysis.less.labels.dailyflow._get_dailyflow_raw_labels",
    return_value=pd.DataFrame(),
)
def test_get_dailyflow_labels_empty_no_early_exist(
    get_dailyflow_raw_labels_mock: mock.Mock,
) -> None:
    """Test case with task queue IDs provided, but no raw labels returned (mocked)."""
    labels_df = get_dailyflow_labels(schema_type=SceneSlicerLabel, task_queue_ids=[1, 2])
    assert labels_df.empty is True
    assert get_dailyflow_raw_labels_mock.call_count == 1


@mock.patch("cruise.mpc_analysis.less.labels.dailyflow._get_dailyflow_raw_labels")
def test_get_dailflow_labels_populated(
    get_dailyflow_raw_labels_mock: mock.Mock, raw_dailyflow_labels: pd.DataFrame
) -> None:
    """Test case with task queue IDs provided, and valid raw labels mocked."""
    get_dailyflow_raw_labels_mock.return_value = raw_dailyflow_labels
    labels_df = get_dailyflow_labels(schema_type=SceneSlicerLabel, task_queue_ids=[1, 2])
    assert get_dailyflow_raw_labels_mock.call_count == 1
    assert len(labels_df) == 1

    # Check data types
    assert np.issubdtype(labels_df.dtypes["is_event_in_segment"], np.bool_)
    assert np.issubdtype(labels_df.dtypes["event_start_s"], np.floating)
    assert np.issubdtype(labels_df.dtypes["event_end_s"], np.floating)

    # Check values.
    pos_event = labels_df.iloc[0]
    assert bool(pos_event["is_event_in_segment"]) is True
    assert pos_event["uuid"] == json.loads(raw_dailyflow_labels.iloc[0]["metadata"])["uuid"]
    assert pos_event["segment_id"] == raw_dailyflow_labels.iloc[0]["segment_id"]
    assert pos_event["event_start_s"] == float(_SEGMENT_START_TIME)
    assert pos_event["event_end_s"] == float(_SEGMENT_END_TIME)
