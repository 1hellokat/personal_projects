"""Unit tests for the sourcing_utils library."""

# System imports
from math import floor
from typing import Final

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.constants import DEFAULT_TRACK_ID
from cruise.mpc_analysis.less.sourcing_utils import format_cola_results

_SAMPLE_VIN: Final[str] = "5G21A6P05P0000000"
_SAMPLE_TIMESTAMP_SECS: Final[int] = floor(pd.to_datetime("2025-01-31").timestamp()) + 1


@pytest.fixture
def sample_cola_results() -> pd.DataFrame:
    """Fixture for some sample COLA search results."""
    return pd.DataFrame(
        [
            {
                "vin": _SAMPLE_VIN,
                "timestamp_secs": _SAMPLE_TIMESTAMP_SECS,
                "track_id": DEFAULT_TRACK_ID,
                "camera_bbox": ["camera_front_left_0:1,2,3,4"],
            },
            {
                "vin": _SAMPLE_VIN,
                "timestamp_secs": _SAMPLE_TIMESTAMP_SECS,
                "track_id": DEFAULT_TRACK_ID,
                "camera_bbox": ["camera_front_right_0:1,2,3,4"],
            },
        ],
    )


def test_format_cola_results(sample_cola_results: pd.DataFrame) -> None:
    results = format_cola_results(results_df=sample_cola_results, segment_duration_s=20.0)
    assert len(results) == len(sample_cola_results)
    assert "webviz_link" in results.columns
