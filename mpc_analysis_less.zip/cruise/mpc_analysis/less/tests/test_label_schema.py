"""Unit tests for the label_schema library."""

# System imports
import json
from typing import Any, Final, Union

# Third-party imports
import pytest

# Cruise imports
from cruise.mpc_analysis.less.labels.label_schema import LabelSchema, LabelSource, SceneSlicerLabel
from cruise.mpc_analysis.less.segment import Segment

_SAMPLE_SEGMENT_ID: Final[str] = "5G21A6P05P0111111:1730730000:1730730010"


@pytest.fixture
def sample_label_data() -> dict[str, Union[bool, str, LabelSource]]:
    return {
        "uuid": "0ac2967b-af44-45d3-b0c9-b988f824417a",
        "metadata": "{}",
        "segment_id": _SAMPLE_SEGMENT_ID,
        "source": LabelSource.DAILYFLOW,
        "is_event_in_segment": False,
    }


def test_base_schema_init_valid(sample_label_data: dict[str, Any]) -> None:
    schema = LabelSchema(uuid=sample_label_data["uuid"], metadata=sample_label_data["metadata"])
    assert schema.is_valid() is True


def test_base_schema_init_invalid_uuid() -> None:
    schema = LabelSchema(uuid="invalid_guid", metadata="{}")
    assert schema.is_valid() is False


def test_base_schema_init_invalid_metadata(sample_label_data: dict[str, Any]) -> None:
    schema = LabelSchema(uuid=sample_label_data["uuid"], metadata="")  # Invalid json metadata
    assert schema.is_valid() is False


def test_scene_slicer_label_init_direct(sample_label_data: dict[str, Any]) -> None:
    schema = SceneSlicerLabel(
        uuid=sample_label_data["uuid"],
        metadata=sample_label_data["metadata"],
        segment_id=sample_label_data["segment_id"],
        source=sample_label_data["source"],
        is_event_in_segment=sample_label_data["is_event_in_segment"],
    )
    assert schema.is_valid() is True


def test_scene_slicer_label_is_valid_invalid_segment(sample_label_data: dict[str, Any]) -> None:
    segment = Segment.from_str(sample_label_data["segment_id"])
    # Adjust segment bounds to be invalid
    segment.end_t_s = segment.start_t_s - 1
    sample_label_data["segment_id"] = str(segment)
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    assert schema.is_valid() is False


def test_scene_slicer_label_is_valid_invalid_label_times(
    sample_label_data: dict[str, Any],
) -> None:
    sample_label_data["is_event_in_segment"] = True
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    assert schema.is_valid() is False


def test_scene_slicer_label_is_valid_label_times_at_segment(
    sample_label_data: dict[str, Any],
) -> None:
    segment = Segment.from_str(sample_label_data["segment_id"])
    sample_label_data["is_event_in_segment"] = True
    sample_label_data["event_start_s"] = segment.start_t_s
    sample_label_data["event_end_s"] = segment.end_t_s
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    assert schema.is_valid() is True


def test_scene_slicer_label_is_valid_label_times_inside_segment(
    sample_label_data: dict[str, Any],
) -> None:
    segment = Segment.from_str(sample_label_data["segment_id"])
    sample_label_data["is_event_in_segment"] = True
    eps = 1e-6
    sample_label_data["event_start_s"] = segment.start_t_s + eps
    sample_label_data["event_end_s"] = segment.end_t_s - eps
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    assert schema.is_valid() is True


def test_scene_slicer_label_is_valid_label_times_start_outside_segment(
    sample_label_data: dict[str, Any],
) -> None:
    segment = Segment.from_str(sample_label_data["segment_id"])
    sample_label_data["is_event_in_segment"] = True
    eps = 1e-6
    sample_label_data["event_start_s"] = segment.start_t_s
    sample_label_data["event_end_s"] = segment.end_t_s + eps
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    assert schema.is_valid() is False


def test_scene_slicer_label_is_valid_label_times_end_outside_segment(
    sample_label_data: dict[str, Any],
) -> None:
    segment = Segment.from_str(sample_label_data["segment_id"])
    sample_label_data["is_event_in_segment"] = True
    eps = 1e-6
    sample_label_data["event_start_s"] = segment.start_t_s - eps
    sample_label_data["event_end_s"] = segment.end_t_s
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    assert schema.is_valid() is False


def test_scene_slicer_label_init_from_dict_missing_fields(
    sample_label_data: dict[str, Any],
) -> None:
    """Initialize SceneSlicerLabel via from_dict(...) with missing required fields."""
    for field in sample_label_data:
        # Metadata has special handling (always added) so it won't raise an exception.
        if field == "metadata":
            continue
        label_input = sample_label_data.copy()
        label_input.pop(field)
        with pytest.raises(ValueError):
            SceneSlicerLabel.from_dict(input=label_input)


def test_scene_slicer_label_init_from_dict_incorrect_types(
    sample_label_data: dict[str, Any],
) -> None:
    """Initialize SceneSlicerLabel via from_dict(...) with the wrong types."""
    label_input = sample_label_data.copy()
    label_input["is_event_in_segment"] = int(label_input["is_event_in_segment"])
    with pytest.raises(TypeError):
        SceneSlicerLabel.from_dict(input=label_input)


def test_scene_slicer_label_init_from_dict_extra_fields(sample_label_data: dict[str, Any]) -> None:
    extra_data = {"key1": "val1", "key2": "val2"}
    sample_label_data.update(extra_data)
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    assert schema.is_valid() is True
    metadata = json.loads(schema.metadata)
    for k, v in extra_data.items():
        assert k in metadata
        assert metadata[k] == v


def test_scene_slicer_label_init_from_dict_no_extra(sample_label_data: dict[str, Any]) -> None:
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    for field_name, value in sample_label_data.items():
        assert getattr(schema, field_name) == value
    assert schema.is_valid() is True


def test_scene_slicer_label_to_dataframe(sample_label_data: dict[str, Any]) -> None:
    schema = SceneSlicerLabel.from_dict(input=sample_label_data)
    output_df = schema.to_dataframe()
    assert len(output_df) == 1
    for key, val in sample_label_data.items():
        if key == "source":
            assert output_df["source"].iloc[0] == schema.source.name
        else:
            assert output_df[key].iloc[0] == val
