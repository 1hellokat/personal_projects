"""Unit tests for the LESS Big Query Client"""

# System imports
from typing import Final
from unittest import mock

# Third-party imports
import pytest

# Cruise imports
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient

_FAKE_PROJECT_ID: Final[str] = "some_project"


class FakeVaultStore:
    """Mock for the Vault Store."""

    def read_secret_from_path(self, path: str) -> str:
        return "{}"


@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.service_account.Credentials.from_service_account_info"
)
@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
def test_client_init(bq_client_mock: mock.Mock, service_account_mock: mock.Mock) -> None:
    LessBigQueryClient._reset_singleton()
    client = LessBigQueryClient(project_id=_FAKE_PROJECT_ID, credentials_json_str="{}")
    assert client is not None
    assert bq_client_mock.call_count == 1
    assert service_account_mock.call_count == 1


@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.service_account.Credentials.from_service_account_info"
)
@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
def test_client_is_singleton(bq_client_mock: mock.Mock, service_account_mock: mock.Mock) -> None:
    LessBigQueryClient._reset_singleton()
    client_a = LessBigQueryClient(project_id=_FAKE_PROJECT_ID, credentials_json_str="{}")
    client_b = LessBigQueryClient(project_id=_FAKE_PROJECT_ID, credentials_json_str="{}")
    assert client_a is not None
    assert client_a is client_b
    assert bq_client_mock.call_count == 1
    assert service_account_mock.call_count == 1


@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.service_account.Credentials.from_service_account_info"
)
@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.VaultSecretStore", return_value=FakeVaultStore()
)
def test_client_init_from_vault(
    vault_mock: mock.Mock, bq_client_mock: mock.Mock, service_account_mock: mock.Mock
) -> None:
    LessBigQueryClient._reset_singleton()
    client = LessBigQueryClient.init_from_vault()
    assert client is not None
    assert vault_mock.call_count == 1
    assert bq_client_mock.call_count == 1
    assert service_account_mock.call_count == 1
    assert LessBigQueryClient._is_initialized is True


@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
def test_client_init_from_default_creds(bq_client_mock: mock.Mock) -> None:
    LessBigQueryClient._reset_singleton()
    client = LessBigQueryClient.init_from_default_creds()
    assert client is not None
    assert bq_client_mock.call_count == 1
    assert LessBigQueryClient._is_initialized is True


@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
def test_client_init_from_default_creds_multiple(bq_client_mock: mock.Mock) -> None:
    LessBigQueryClient._reset_singleton()
    client_a = LessBigQueryClient.init_from_default_creds()
    client_b = LessBigQueryClient.init_from_default_creds()
    assert client_a is not None
    assert client_a is client_b
    assert bq_client_mock.call_count == 1
    assert LessBigQueryClient._is_initialized is True


@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.service_account.Credentials.from_service_account_info"
)
@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.VaultSecretStore", return_value=FakeVaultStore()
)
def test_client_init_from_vault_multiple(
    vault_mock: mock.Mock, bq_client_mock: mock.Mock, service_account_mock: mock.Mock
) -> None:
    """Call init_from_vault twice but ensures the intialization functions are only called once."""
    LessBigQueryClient._reset_singleton()
    client_a = LessBigQueryClient.init_from_vault()
    client_b = LessBigQueryClient.init_from_vault()
    assert client_a is not None
    assert client_a is client_b
    assert vault_mock.call_count == 1
    assert bq_client_mock.call_count == 1
    assert service_account_mock.call_count == 1
    assert LessBigQueryClient._is_initialized is True


@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.service_account.Credentials.from_service_account_info"
)
@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
def test_client_run_query(bq_client_mock: mock.Mock, service_account_mock: mock.Mock) -> None:
    LessBigQueryClient._reset_singleton()
    client = LessBigQueryClient(project_id=_FAKE_PROJECT_ID, credentials_json_str="{}")
    assert bq_client_mock.call_count == 1
    assert service_account_mock.call_count == 1
    client.run_query(query="blah")


@mock.patch(
    "cruise.mpc_analysis.less.bigquery_client.service_account.Credentials.from_service_account_info"
)
@mock.patch("cruise.mpc_analysis.less.bigquery_client.bigquery.Client")
def test_client_run_query_and_get_dataframe_raises(
    bq_client_mock: mock.Mock, service_account_mock: mock.Mock
) -> None:
    """Test that not returning a dataframe from run_query throws."""
    LessBigQueryClient._reset_singleton()
    client = LessBigQueryClient(project_id=_FAKE_PROJECT_ID, credentials_json_str="{}")
    assert bq_client_mock.call_count == 1
    assert service_account_mock.call_count == 1
    with pytest.raises(TypeError):
        client.run_query_and_get_dataframe(query="blah")
