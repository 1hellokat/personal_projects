"""Module for constant values for the LESS project."""

# System imports
from typing import Final

# Track ID value when none exists.
DEFAULT_TRACK_ID: Final[int] = -2000

### TPO related constants.

# Minimum segment length (used when submitting a TPO labeling request so it containt some context).
DEFAULT_MIN_SEGMENT_LENGTH: Final[float] = 10.0

# Maximum allowable segments to submit to TPO. DO NOT change this.
ABSOLUTE_MAX_NUM_TPO_SEGMENTS: Final[int] = 500

# Default maximum number of segments to submit for TPO labeling.
DEFAULT_MAX_NUM_TPO_SEGMENTS: Final[int] = 100

# Max segment length for labeling. This originates from the labeler's ability to load webviz.
MAX_TPO_SEGMENT_LENGTH_S: Final[float] = 60.0

### Cloud/GCP related constants.

LESS_GCP_PROJECT_ID: Final[str] = "ca-eval-less-dev-mua9"
LESS_SVC_ACCT_VAULT_PATH: Final[str] = (
    "secret-paas/project/eval-less/dev/gcp/service-accounts/juno-eval-less.identity.json"
)

SCENE_PR_PIPELINE_RESULTS_TABLE: Final[str] = (
    "ca-eval-less-dev-mua9.scene_prec_recall.evaluations_prod"
)

HYDRA_RETENTION_TAG: Final[str] = "metrics-validation"

### Roboflow pipeline constants

# Alerting threshold for a regression in precision or recall.
SCENE_PR_DELTA_ALERT_THRESH_PCT: Final[float] = 10.0

# Slack channel to send pipeline alerts to.
LESS_ALERT_SLACK_CHANNEL: Final[str] = "evaluation-less-alerts"

# SC3 Analyze template filename.
SC3_ANALYZE_TEMPLATE: Final[str] = "sc3.yaml"

### LESS Bigquery tables

LESS_BQ_PROJECT_ID: Final[str] = "ca-eval-less-dev-mua9"
LESS_BQ_SIM_RESULT_METADATA_TABLE: Final[str] = f"{LESS_BQ_PROJECT_ID}.less.sim_result_metadata"
