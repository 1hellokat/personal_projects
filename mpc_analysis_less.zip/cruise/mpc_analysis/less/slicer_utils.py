"""Library for interacting with Slicers for the LESS Project."""

# System imports
import logging
import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from queue import Queue
from tempfile import TemporaryDirectory
from threading import Thread
from typing import Any, Final, List, Optional

# Third-party imports
import pandas as pd
import yaml
from pandas.api.types import is_datetime64_any_dtype
from rich.progress import MofNCompleteColumn, Progress, TimeElapsedColumn
from sim_analysis.sim_analysis_runner import SimAnalysisRunner

# Cruise imports
from cruise.lgtm2.core.references import InputType as LgtmInputType
from cruise.lgtm2.core.registry import Registry
from cruise.lgtm2.environments.sim_prod import create_executor
from cruise.lgtm2.production_metrics import SIM_REGISTRY
from cruise.lgtm.attribute_store.attribute_slicer import AttributeLogicalSQLSlicer
from cruise.lgtm.attribute_store.common_attribute_slicer import SceneSlicer
from cruise.lgtm.attribute_store.jupyter_notebooks.nbutils.bq_utils import (
    LaunchKey,
    MissingGitHashError,
    get_launch_key_from_launch_ids,
    get_launch_key_from_segment_ids,
    get_road_bigquery_sql,
)
from cruise.lgtm.attribute_store.production_metrics import (
    get_valid_slicer_def_names,
    instantiate_slicer,
)
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.segment import Segment, filter_invalid_segments
from cruise.simulation.scenariokit.scenariokit.connectors import hydra as hydra_conn

# TODO: Further optimize this once we have some larger sets to test against.
_N_THREADS = 16

_PROGRESS_BAR_COLUMNS = (
    *Progress.get_default_columns(),
    TimeElapsedColumn(),
    MofNCompleteColumn(),
)

logger = logging.getLogger(__name__)


_VALID_GUID_REGEX = (
    r"^[{(]?[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}[)}]?$"
)
VALID_HYDRA_RUN_ID_REGEX = _VALID_GUID_REGEX[:-1] + r":\d+$"
_VALID_HYDRA_RUN_ID_WITH_TIMES_REGEX = _VALID_GUID_REGEX[:-1] + r":\d+:\d+:\d+$"

_SIM_ANALYZE_TEMPLATE_FILENAME: Final[str] = "less_temp_template.yaml"
_SIM_ANALYZE_TEMPLATE_DIR: Final[str] = (
    "ros/src/sim_analysis/src/sim_analysis/template/templates/analyze/"
)


class SlicerExecutionMode(Enum):
    """Structure for the different slicer execution modes."""

    # Query the existing slicer output from the __latest_full_drive__ view.
    QUERY_EXISTING = "QUERY_EXISTING"
    # Rerun the slicer query (but uses existing attributes and upstream slicer output).
    RERUN_SLICER = "RERUN_SLICER"
    # Rerun the upstream slicer(s) and the slicer under test but use existing attributes.
    RERUN_UPSTREAM = "RERUN_UPSTREAM"
    # Regenerate the attributes and rerun the upstream slicer(s) and slicer under test.
    REGENERATE_ATTRIBUTES = "REGENERATE_ATTRIBUTES"


class LessSlicerExecutionException(Exception):
    pass


class SlicerFramework(Enum):
    LGTM1 = "LGTM1"
    LGTM2 = "LGTM2"


class SlicerInputType(Enum):
    SEGMENT_ID = "SEGMENT_ID"
    LAUNCH_ID = "LAUNCH_ID"
    HYDRA_RUN_ID = "HYDRA_RUN_ID"
    HYDRA_RUN_ID_WITH_TIMES = "HYDRA_RUN_ID_WITH_TIMES"


class SlicerInputModality(Enum):
    ROAD = "ROAD"
    SIM = "SIM"


def is_valid_guid(maybe_guid: str) -> bool:
    """Returns whether the input is a valid guid."""
    guid_pattern = re.compile(_VALID_GUID_REGEX)
    return bool(guid_pattern.match(maybe_guid))


def is_valid_hydra_run_id(maybe_hydra_run_id: str) -> bool:
    """Returns whether the input is a valid hydra run id (<valid guid>:<subtask>)"""
    hydra_run_id_pattern = re.compile(VALID_HYDRA_RUN_ID_REGEX)
    return bool(hydra_run_id_pattern.match(maybe_hydra_run_id))


def is_valid_hydra_run_id_with_times(maybe_hydra_run_id_w_times: str) -> bool:
    """Returns whether the input is a valid hydra run id + times (<valid guid>:<subtask>:t1:t2)"""
    hydra_run_id_with_times_pattern = re.compile(_VALID_HYDRA_RUN_ID_WITH_TIMES_REGEX)
    return bool(hydra_run_id_with_times_pattern.match(maybe_hydra_run_id_w_times))


def determine_input_type(input_id: str) -> SlicerInputType:
    """Categorize the type of slicer input."""
    if is_valid_guid(maybe_guid=input_id):
        return SlicerInputType.LAUNCH_ID
    if is_valid_hydra_run_id(maybe_hydra_run_id=input_id):
        return SlicerInputType.HYDRA_RUN_ID
    if is_valid_hydra_run_id_with_times(maybe_hydra_run_id_w_times=input_id):
        return SlicerInputType.HYDRA_RUN_ID_WITH_TIMES
    try:
        segment = Segment.from_str(segment_id=input_id)
        return SlicerInputType.SEGMENT_ID
    except ValueError:
        pass
    logger.exception("Unable to determine input_id type for: %s", input_id)
    raise ValueError


def split_input_ids_by_modality(input_ids: list[str]) -> dict[SlicerInputModality, list[str]]:
    """Splits up the input IDs by modality (road, sim)."""
    output: dict[SlicerInputModality, list[str]] = {
        SlicerInputModality.ROAD: [],
        SlicerInputModality.SIM: [],
    }
    for input_id in input_ids:
        input_type = determine_input_type(input_id=input_id)
        if input_type in (SlicerInputType.SEGMENT_ID, SlicerInputType.LAUNCH_ID):
            output[SlicerInputModality.ROAD].append(input_id)
        elif input_type == SlicerInputType.HYDRA_RUN_ID:
            output[SlicerInputModality.SIM].append(input_id)
        else:
            logger.exception("Unsupported input type: %s", input_type)
            raise NotImplementedError
    return output


@dataclass
class SlicerExecutionResult:
    """Stores the result for a requested slicer execution."""

    # The requested segment ID (road), launch ID (road) or hydra run ID (sim) to run the slicer on.
    input_id: str
    # Was the slicer executed successfully.
    was_successfully_executed: bool
    slicer_output: pd.DataFrame
    # The launch key passed to execute the query (for road data only).
    launch_key: Optional[LaunchKey] = None
    # Error message if encountered during slicer execution.
    error_msg: Optional[str] = None
    # Was the encountered error due to a known failure mode?
    error_was_due_to_known_cause: Optional[bool] = None

    @property
    def input_type(self) -> SlicerInputType:
        """Returns the input type for this execution result."""
        return determine_input_type(input_id=self.input_id)


def trim_scene_slicer_output_to_timerange(
    result_df: pd.DataFrame, start_time_s: float, end_time_s: float
) -> pd.DataFrame:
    """Temporary workaround to limit a scene slicer output to a segment time range."""
    output_rows: list[dict[str, Any]] = []
    start_timestamp = pd.Timestamp(start_time_s, unit="s", tz="UTC")
    end_timestamp = pd.Timestamp(end_time_s, unit="s", tz="UTC")
    for _, df_row in result_df.iterrows():
        row = df_row.to_dict()
        if row["end_time"] < start_timestamp or row["start_time"] > end_timestamp:
            # Dismiss all entries that lie entirely outside of the start & end time.
            continue
        # Bound the slicer result to be within the segment.
        row["start_time"] = max([start_timestamp, row["start_time"]])
        row["end_time"] = min([end_timestamp, row["end_time"]])
        output_rows.append(row)
    return pd.DataFrame(output_rows)


def check_and_instantiate_slicer(slicer_name: str) -> SceneSlicer:
    """Instantiate the slicer."""
    valid_slicer_names = get_valid_slicer_def_names(slicer_def_names=None)
    if slicer_name not in valid_slicer_names:
        slicer_names_separated = "\n".join(valid_slicer_names)
        error_msg = f"Slicer:{slicer_name} not found. valid slicers:\n{slicer_names_separated}"
        raise ValueError(error_msg)
    slicer = instantiate_slicer(slicer_def_name=slicer_name)

    if not isinstance(slicer, AttributeLogicalSQLSlicer):
        error_msg = (
            f"{slicer_name} type {type(slicer)} does not match expected: AttributeLogicalSQLSlicer"
        )
        raise TypeError(error_msg)

    if not isinstance(slicer, SceneSlicer):
        error_msg = f"Only scene slicers are supported currently, got type: {type(slicer)}"
        raise NotImplementedError(error_msg)
    return slicer


def _instrument_error_message(
    slicer_exec_results: list[SlicerExecutionResult],
    input_id: str,
    error_msg: str,
    error_cause_known: bool,
) -> list[SlicerExecutionResult]:
    """Helper to add the error message to the appropriate slicer execution results."""
    logger.error(error_msg)
    was_instrumented: bool = False
    for slicer_exec_result in slicer_exec_results:
        if (
            slicer_exec_result.launch_key is not None
            and input_id == slicer_exec_result.launch_key.launch_id
        ) or (slicer_exec_result.input_id == input_id):
            slicer_exec_result.error_msg = error_msg
            slicer_exec_result.error_was_due_to_known_cause = error_cause_known
            was_instrumented = True
    if not was_instrumented:
        error_msg = f"Input/launch ID: {input_id} not found in slicer execution results!"
        raise ValueError(error_msg)
    return slicer_exec_results


def _allocate_road_results_output(
    input_ids: list[str],
    launch_key_map: dict[str, LaunchKey],
) -> list[SlicerExecutionResult]:
    """Helper to create the allocate the results output of slicer execution for segments.

    Parameters
    ----------
    input_ids
        the sequence of segment or launch ids to run the slicer logic on.
    launch_key_map
        map from input_id --> launch key

    Returns
    -------
    list[SlicerExecutionResult]
        A sequence of allocated execution results the same length as the input_ids

    """
    return [
        SlicerExecutionResult(
            input_id=input_id,
            was_successfully_executed=False,
            slicer_output=pd.DataFrame(),
            launch_key=launch_key_map[input_id],
            error_msg=None,
        )
        for input_id in input_ids
    ]


def _allocate_sim_results_output(input_ids: list[str]) -> list[SlicerExecutionResult]:
    """Helper to create the allocate the results output of slicer execution for segments.

    Parameters
    ----------
    input_ids
        the sequence of hydra_run_ids ids to run the slicer logic on.

    Returns
    -------
    list[SlicerExecutionResult]
        A sequence of allocated execution results the same length as the input_ids

    """
    return [
        SlicerExecutionResult(
            input_id=input_id,
            was_successfully_executed=False,
            slicer_output=pd.DataFrame(),
            launch_key=None,
            error_msg=None,
        )
        for input_id in input_ids
    ]


def get_existing_slicer_output_sql(*, slicer_name: str, launch_ids: List[str]) -> str:
    """Generate a query for the existing slicer output for a drive."""
    if len(launch_ids) == 0:
        raise ValueError("List of launch_ids cannot be empty.")
    joined_ids = ", ".join([f"'{id}'" for id in launch_ids])

    return f"""
        SELECT 
        * 
        FROM 
        `cruise-mlp-prod-13d0.attribute_store_slices.scene-{slicer_name}__latest_full_drive__`
        WHERE _launch_id IN ({joined_ids})
    """


def generate_slicer_output_by_drive(
    slicer_name: str,
    input_to_launch_key_map: dict[str, LaunchKey],
    slicer_exec_results: list[SlicerExecutionResult],
    rerun_slicer: bool,
) -> dict[str, pd.DataFrame]:
    """
    Generates the slicer output for each drive.

    Parameters
    ----------
    slicer_name
        the name of the slicer to run
    input_to_launch_key_map
        mapping from input id (segment/launch ID) --> launch key
    slicer_exec_results:
        list of prepopulated slicer results (will be instrumented with errors if encountered)
    rerun_slicer:
        whether to rerun the slicer query or pull from existing slicer output tables

    Returns
    -------
    dict[str, pd.DataFrame]
        mapping from launch_id --> slicer output
    """
    slicer = check_and_instantiate_slicer(slicer_name=slicer_name)

    # Slicers are processed at the drive level for now so cache the drive output to avoid collecting
    # the drive output for multiple segments on the same drive.
    slicer_by_drive_cache: dict[str, pd.DataFrame] = {}

    # If we're not rerunning the slicer, we can grab the existing results as part of a single query.
    # This is more efficient than repeatedly querying the table.
    if not rerun_slicer:
        with Progress(*_PROGRESS_BAR_COLUMNS) as querying_previous_slicer_run:
            task_retrieve_extant = querying_previous_slicer_run.add_task(
                "Retrieving existing slicer results: ", total=1
            )
            unique_launch_ids = list(set([e.launch_id for e in input_to_launch_key_map.values()]))
            query = get_existing_slicer_output_sql(
                slicer_name=slicer_name,
                launch_ids=unique_launch_ids,
            )
            bq_client = LessBigQueryClient.init_from_vault()
            results = bq_client.run_query_and_get_dataframe(query=query)
            slicer_by_drive_cache = {str(key): df for key, df in results.groupby("_launch_id")}
            # Fill in empty dataframes for launches that had no slicer results.
            for launch_id in unique_launch_ids:
                if launch_id not in slicer_by_drive_cache:
                    slicer_by_drive_cache[launch_id] = pd.DataFrame()
            querying_previous_slicer_run.update(task_id=task_retrieve_extant, advance=1)

    else:
        slicer_query_cache: dict[str, str] = {}  # launch_id -> sql_query
        slicer_launch_cache: dict[str, LaunchKey] = {
            value.launch_id: value for _, value in input_to_launch_key_map.items()
        }

        # Build the queries for each launch
        with Progress(*_PROGRESS_BAR_COLUMNS) as build_queries:
            task_queries = build_queries.add_task(
                "Generating on-road queries: ", total=len(slicer_launch_cache)
            )
            build_query_queue = Queue()
            for launch_key in slicer_launch_cache.values():
                build_query_queue.put(launch_key)

            def build_query(q: Queue) -> None:
                while not q.empty():
                    launch_key: LaunchKey = q.get()
                    try:
                        query = get_road_bigquery_sql(slicer=slicer, launch_key=launch_key)
                        slicer_query_cache[launch_key.launch_id] = query
                    except MissingGitHashError as e:
                        _instrument_error_message(
                            slicer_exec_results=slicer_exec_results,
                            input_id=launch_key.launch_id,
                            error_msg=f"Missing git hash for launch: {launch_key.launch_id}\n {e}",
                            error_cause_known=True,
                        )
                    except Exception as e:
                        _instrument_error_message(
                            slicer_exec_results=slicer_exec_results,
                            input_id=launch_key.launch_id,
                            error_msg=f"Unexpected error generating SQL for launch: {launch_key.launch_id}\n {e}",
                            error_cause_known=False,
                        )
                    finally:
                        build_queries.update(task_id=task_queries, advance=1)
                        q.task_done()

            for _ in range(_N_THREADS):
                Thread(target=build_query, args=(build_query_queue,)).start()
            build_query_queue.join()

        # Now that the queries have been built, we can actually execute them
        with Progress(*_PROGRESS_BAR_COLUMNS) as run_queries:
            task_run = run_queries.add_task(
                "Rerunning slicer on road: ", total=len(slicer_query_cache)
            )
            run_query_queue = Queue()
            for launch_id, query in slicer_query_cache.items():
                run_query_queue.put((launch_id, query))

            bq_client = LessBigQueryClient.init_from_vault()

            def execute_query(q: Queue, bq_client: LessBigQueryClient = bq_client) -> None:
                while not q.empty():
                    launch_id, query = q.get()

                    try:
                        slicer_by_drive_cache[launch_id] = bq_client.run_query_and_get_dataframe(
                            query=query,
                        )
                    except Exception as e:
                        _instrument_error_message(
                            slicer_exec_results=slicer_exec_results,
                            input_id=launch_id,
                            error_msg=f"Unexpected error executing SQL for launch: {launch_id}\n {e}",
                            error_cause_known=False,
                        )
                    finally:
                        run_queries.update(task_id=task_run, advance=1)
                        q.task_done()

            for _ in range(_N_THREADS):
                Thread(target=execute_query, args=(run_query_queue,)).start()
            run_query_queue.join()

        # If we encountered any unexpected error, throw a custom exception
        for result in slicer_exec_results:
            # Can't use `not` below because of possibility of `None`
            if result.error_was_due_to_known_cause == False:
                launch_id = "unknown" if result.launch_key is None else result.launch_key.launch_id
                raise LessSlicerExecutionException(
                    f"There was an unexpected error executing the slicer SQL for launch_id {launch_id}.\n{result.error_msg}"
                )
    return slicer_by_drive_cache


def convert_slicer_results_datetimes(results_df: pd.DataFrame) -> pd.DataFrame:
    """Convert scene slicer result datetimes into timestamps."""
    if (
        "start_time" in results_df.columns
        and "end_time" in results_df.columns
        and is_datetime64_any_dtype(results_df.dtypes["start_time"])
        and is_datetime64_any_dtype(results_df.dtypes["end_time"])
    ):
        results_df["start_time"] = results_df["start_time"].view("int64") // 10**9
        results_df["end_time"] = results_df["end_time"].view("int64") // 10**9
    return results_df


def run_slicer_on_road_data(
    input_ids: list[str],
    slicer_name: str,
    rerun_slicer: bool = True,
    convert_datetimes: bool = True,
) -> list[SlicerExecutionResult]:
    """Runs a slicer on a collection of road segments or launches.

    Parameters
    ----------
    input_ids
        the sequence of segment or launch ids to run the slicer logic on.
    slicer_name
        the name of the slicer ("av_in_driveable_area_scene")
    rerun_slicer
        whether to rerun the slicer logic on the current code (vs query)
    convert_datetimes
        whether to convert the scene slicer datetimes into timestamps

    Returns
    -------
    list[SlicerExecutionResult]
        A sequence of execution results the same length as the input_ids
    """
    segment_ids = [e for e in input_ids if ":" in e]
    launch_ids = [e for e in input_ids if ":" not in e]

    launch_key_map: dict[str, LaunchKey] = {}  # (segment_id or launch_id) --> launch key

    segment_ids_to_run = filter_invalid_segments(segment_ids)
    valid_input_ids = [*segment_ids_to_run, *launch_ids]
    if segment_ids_to_run:
        with Progress(*_PROGRESS_BAR_COLUMNS) as progress_launch_keys:
            task_launch_keys = progress_launch_keys.add_task(
                "Querying launch keys for segments: ", total=len(segment_ids_to_run)
            )
            launch_key_map.update(get_launch_key_from_segment_ids(segment_ids_to_run))
            progress_launch_keys.update(task_id=task_launch_keys, advance=len(segment_ids_to_run))
        missing_segment_ids = set(segment_ids_to_run).difference(set(launch_key_map.keys()))
        if missing_segment_ids:
            raise ValueError(
                f"Could not query launch keys for segment ID(s): {', '.join(missing_segment_ids)}"
            )
    if launch_ids:
        with Progress(*_PROGRESS_BAR_COLUMNS) as progress_launch_keys:
            task_launch_keys = progress_launch_keys.add_task(
                "Querying launch keys for launches: ", total=len(launch_ids)
            )
            launch_key_map.update(get_launch_key_from_launch_ids(launch_ids=launch_ids))
            progress_launch_keys.update(task_id=task_launch_keys, advance=len(launch_ids))
        missing_launch_ids = set(launch_ids).difference(set(launch_key_map.keys()))
        if missing_launch_ids:
            raise ValueError(
                f"Could not query launch keys for launch ID(s): {', '.join(missing_launch_ids)}"
            )

    # Pre-allocate the output results for all the input IDs.
    slicer_exec_results = _allocate_road_results_output(
        input_ids=input_ids, launch_key_map=launch_key_map
    )

    # launch id --> slicer output
    slicer_by_drive_cache: dict[str, pd.DataFrame] = generate_slicer_output_by_drive(
        slicer_name=slicer_name,
        input_to_launch_key_map=launch_key_map,
        slicer_exec_results=slicer_exec_results,
        rerun_slicer=rerun_slicer,
    )

    for input_id in valid_input_ids:
        launch_id = launch_key_map[input_id].launch_id
        if ":" in input_id:
            # Input is a segment, so trim the slicer output for the drive to the segment bounds.
            segment = Segment.from_str(input_id)
            # TODO (ENG-126960): Remove this trimming if/when slicers are executed on segments (vs drives).
            slicer_result_df = trim_scene_slicer_output_to_timerange(
                result_df=(
                    slicer_by_drive_cache[launch_id]
                    if launch_id in slicer_by_drive_cache
                    else pd.DataFrame()
                ),
                start_time_s=segment.start_t_s,
                end_time_s=segment.end_t_s,
            )
        else:
            # Input in a drive so grab the slicer output for the entire drive.
            slicer_result_df = slicer_by_drive_cache[launch_id]
        if convert_datetimes:
            slicer_result_df = convert_slicer_results_datetimes(slicer_result_df)
        # Update the slicer execution success status.
        for slicer_exec_result in slicer_exec_results:
            if input_id == slicer_exec_result.input_id:
                if slicer_exec_result.error_msg is None:
                    slicer_exec_result.was_successfully_executed = True
                    slicer_exec_result.slicer_output = slicer_result_df
                else:
                    slicer_exec_result.was_successfully_executed = False

    return slicer_exec_results


def determine_slicer_framework(slicer_name: str) -> SlicerFramework:
    """Helper to determine the framework for a slicer (prefer LGTM2 if both)."""
    if slicer_name in [e.name for e in SIM_REGISTRY.slicers]:
        return SlicerFramework.LGTM2
    if slicer_name in get_valid_slicer_def_names(slicer_def_names=None):
        return SlicerFramework.LGTM1
    error_msg = "Unable to find slicer %s in the registry (note: SIM_REGISTRY FOR LGTM2)"
    raise ValueError(error_msg)


def _create_analyze_template(
    *, slicer_name: str, slicer_framework: SlicerFramework, template_path: Path
) -> None:
    """Helper to create an analyze template to run a specific slicer."""
    if slicer_framework == SlicerFramework.LGTM2:
        logger.warning("Running LGTM2 slicer %s", slicer_name)
        analyze_template_data = {
            "use": "base.yaml",
            "tester": {
                "analyze": [
                    {
                        "RoboFlowAnalyzer": {
                            "sim_pipeline_functions": [
                                {
                                    "lgtm2.lgtm2_metrics_pipeline.lgtm2_metrics_pipeline": {
                                        "slicers": [slicer_name],
                                    }
                                },
                                {
                                    # This is only to apply the minimal launch graph (LGTM2 doesn't support this yet)
                                    "lgtm.lgtm_metrics_pipeline.lgtm_metrics_pipeline": {
                                        "use_minimal_ag_launch_graph": True,
                                        "slicer_def_names": ["metadata_slicer"],
                                    }
                                },
                            ]
                        }
                    }
                ],
                "report": [],
            },
        }
    elif slicer_framework == SlicerFramework.LGTM1:
        logger.warning("Running LGTM1 slicer %s", slicer_name)
        analyze_template_data = {
            "use": "base.yaml",
            "tester": {
                "analyze": [
                    {
                        "RoboFlowAnalyzer": {
                            "sim_pipeline_functions": [
                                {
                                    "lgtm.lgtm_metrics_pipeline.lgtm_metrics_pipeline": {
                                        "use_minimal_ag_launch_graph": True,
                                        "slicer_def_names": [slicer_name],
                                    }
                                }
                            ]
                        }
                    }
                ],
                "report": [],
            },
        }
    else:
        error_msg = f"Unexpected slicer framework {slicer_framework.value} for {slicer_name}"
        raise ValueError(error_msg)
    with template_path.open("w") as f:
        yaml.dump(analyze_template_data, f)


def _get_sim_analysis_result_key(slicer_name: str, slicer_framework: SlicerFramework) -> str:
    """Helper to construct the sim analysis slicer result key."""
    if slicer_framework == SlicerFramework.LGTM1:
        slicer_name_camelcase = slicer_name.title().replace("_", "")
        return f"lgtm_{slicer_name_camelcase}/per-bag"
    elif slicer_framework == SlicerFramework.LGTM2:
        return f"lgtm2_{slicer_name}/per-bag"
    else:
        error_msg = f"Unsupported slicer framework {slicer_framework}"
        raise ValueError(error_msg)


def _registry_has_passthrough_topics(registry: Registry) -> bool:
    """Determines whether a slicer has passthrough inputs."""
    return any(topic.type == LgtmInputType.PASS_THROUGH_ATTRIBUTE for topic in registry.topics)


def run_slicer_on_sim_data(
    input_ids: list[str],
    slicer_name: str,
    rerun_slicer: bool,
    convert_datetimes: bool = True,
) -> list[SlicerExecutionResult]:
    """Runs a slicer on a collection of sim results.

    Parameters
    ----------
    input_ids
        the hydra run IDs to run slicer logic on.
    slicer_name
        the name of the slicer ("av_in_driveable_area_scene")
    rerun_slicer
        whether to rerun the slicer
    convert_datetimes
        whether to convert the scene slicer datetimes into timestamps

    Returns
    -------
    list[SlicerExecutionResult]
        A sequence of execution results the same length as the input_ids
    """
    slicer_exec_results = _allocate_sim_results_output(input_ids=input_ids)

    slicer_exec_results_map = {e.input_id: e for e in slicer_exec_results}

    if not rerun_slicer:
        error_msg = "Slicer must be rerun for sim result."
        logger.error(error_msg)
        for result in slicer_exec_results:
            result.error_msg = error_msg
        return slicer_exec_results

    slicer_framework = determine_slicer_framework(slicer_name=slicer_name)
    logger.info("Running %s slicer %s", slicer_framework.value, slicer_name)

    if slicer_framework == SlicerFramework.LGTM1:
        analyze_template_path = Path(_SIM_ANALYZE_TEMPLATE_DIR) / _SIM_ANALYZE_TEMPLATE_FILENAME
        _create_analyze_template(
            slicer_name=slicer_name,
            slicer_framework=slicer_framework,
            template_path=analyze_template_path,
        )

    # Build the queries for each sim result.
    with Progress(*_PROGRESS_BAR_COLUMNS) as run_analysis_phases:
        task_queries = run_analysis_phases.add_task("Running slicers: ", total=len(input_ids))
        for input_id in input_ids:
            try:
                if slicer_framework == SlicerFramework.LGTM2:
                    hydra_run_id, subtask_id = input_id.split(":")
                    artifact_name = f"{subtask_id}/analyze/attributes.bag"
                    binary = hydra_conn.get_artifact(hydra_run_id, artifact_name)
                    with TemporaryDirectory() as tmp_dir:
                        attribute_bag_path = Path(tmp_dir) / "attributes.bag"
                        logger.info("Writing attribute bag to %s", attribute_bag_path)
                        with attribute_bag_path.open("wb") as f:
                            f.write(binary)
                        registry = SIM_REGISTRY.get_registry_for_node_subset(nodes=[slicer_name])
                        if _registry_has_passthrough_topics(registry=registry):
                            topic_names = [topic.name for topic in registry.topics]
                            raise NotImplementedError(
                                "Passthrough attributes not currently supported. Topics: {}".format(
                                    ",".join(topic_names)
                                )
                            )
                        executor = create_executor()
                        # Figure out what topics are needed and only load those.
                        topics = [topic.name for topic in registry.topics]
                        logger.info(
                            "Loading the following attribute bag topics: %s", ", ".join(topics)
                        )
                        executor.load_bag_data(path=str(attribute_bag_path), allowed_topics=topics)
                        result = executor.execute_registry(registry=registry)
                        if all([e.success for e in result]):
                            slicer = [e.name for e in registry.slicers if e.name == slicer_name][0]
                            result_df = executor.get_slicer_data(slicer=slicer).assign(
                                input_id=input_id
                            )
                            if convert_datetimes:
                                result_df = convert_slicer_results_datetimes(result_df)
                            slicer_exec_results_map[input_id].slicer_output = result_df
                            slicer_exec_results_map[input_id].was_successfully_executed = True
                        else:
                            slicer_exec_results_map[input_id].was_successfully_executed = False
                            for entry in result:
                                if not entry.success:
                                    slicer_exec_results_map[
                                        input_id
                                    ].error_msg = f"Error executing slicer: {entry.error}"
                elif slicer_framework == SlicerFramework.LGTM1:
                    runner = SimAnalysisRunner(
                        hydra_run_id=input_id, analyze_template=_SIM_ANALYZE_TEMPLATE_FILENAME
                    )
                    result = runner.run()
                    slicer_result_key = _get_sim_analysis_result_key(
                        slicer_name=slicer_name, slicer_framework=slicer_framework
                    )
                    if slicer_result_key in result:
                        result_df = pd.DataFrame(result[slicer_result_key]).assign(
                            input_id=input_id
                        )
                        if convert_datetimes:
                            result_df = convert_slicer_results_datetimes(result_df)
                        slicer_exec_results_map[input_id].slicer_output = result_df
                        slicer_exec_results_map[input_id].was_successfully_executed = True
                    else:
                        logger.error(
                            "Could not find slicer result key %s in results", slicer_result_key
                        )
                        slicer_exec_results_map[input_id].was_successfully_executed = False
                        slicer_exec_results_map[
                            input_id
                        ].error_msg = "Slicer result not found in SimAnalysisRunner output"
                else:
                    raise ValueError(f"Unexpected framework type: {slicer_framework.value}")
            except Exception as e:
                _instrument_error_message(
                    slicer_exec_results=slicer_exec_results,
                    input_id=input_id,
                    error_msg=f"Unexpected error running sim analysis phase for: {input_id} \n {e}",
                    error_cause_known=False,
                )
            finally:
                run_analysis_phases.update(task_id=task_queries, advance=1)

    return list(slicer_exec_results_map.values())
