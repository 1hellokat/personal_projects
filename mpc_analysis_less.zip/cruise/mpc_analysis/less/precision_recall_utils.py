# System imports
import logging
from dataclasses import dataclass
from math import nan
from typing import Union

# Third-party imports
import pandas as pd

# Cruise imports
from cruise.mpc_analysis.less.labels.common_utils import get_sim_scenario_bounds_from_less
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.slicer_utils import SlicerInputType

logger = logging.getLogger(__name__)


@dataclass
class PrecisionRecallResult:
    """Structure for precision and recall results and a confusion matrix."""

    true_positives: list[str]
    false_positives: list[str]
    true_negatives: list[str]
    false_negatives: list[str]

    @property
    def precision(self) -> float:
        return self.num_tp / (self.num_tp + self.num_fp) if (self.num_tp + self.num_fp) > 0 else 0

    @property
    def recall(self) -> float:
        return self.num_tp / (self.num_tp + self.num_fn) if (self.num_tp + self.num_fn) > 0 else 0

    @property
    def num_tp(self) -> int:
        return len(self.true_positives)

    @property
    def num_fp(self) -> int:
        return len(self.false_positives)

    @property
    def num_tn(self) -> int:
        return len(self.true_negatives)

    @property
    def num_fn(self) -> int:
        return len(self.false_negatives)

    @property
    def num_events(self) -> int:
        return self.num_tp + self.num_fp + self.num_tn + self.num_fn

    def as_dict(self) -> dict[str, Union[int, float]]:
        """Convert the precision/recall result to a dictionary."""
        return {
            "precision": self.precision,
            "recall": self.recall,
            "num_events": self.num_events,
            "num_tp": self.num_tp,
            "num_fp": self.num_fp,
            "num_tn": self.num_tn,
            "num_fn": self.num_fn,
        }

    def __add__(self, other: "PrecisionRecallResult") -> "PrecisionRecallResult":
        """Overload to combine two precision recall results."""
        return PrecisionRecallResult(
            true_positives=self.true_positives + other.true_positives,
            false_positives=self.false_positives + other.false_positives,
            true_negatives=self.true_negatives + other.true_negatives,
            false_negatives=self.false_negatives + other.false_negatives,
        )


@dataclass
class PrecisionRecallResultDelta:
    """Structure for comparing 2 precision/recall evaluations."""

    result_a: PrecisionRecallResult
    result_b: PrecisionRecallResult

    @property
    def precision_delta(self) -> float:
        """Precision B minus precision A."""
        return self.result_b.precision - self.result_a.precision

    @property
    def recall_delta(self) -> float:
        """Recall B minus recall A."""
        return self.result_b.recall - self.result_a.recall

    @property
    def precision_delta_pct(self) -> float:
        """Precision percent change from A to B."""
        result_a_precision = self.result_a.precision
        return self.precision_delta / result_a_precision * 100 if result_a_precision > 0 else nan

    @property
    def recall_delta_pct(self) -> float:
        """Recall percent change from A to B."""
        result_a_recall = self.result_a.recall
        return self.recall_delta / result_a_recall * 100 if result_a_recall > 0 else nan

    def delta_entries(self, attr_name: str) -> list[str]:
        """Helper for computing set differences (values in B but not A for a specified field)."""
        if attr_name not in (
            "true_positives",
            "false_positives",
            "true_negatives",
            "false_negatives",
        ) or not hasattr(self.result_a, attr_name):
            logger.exception("Incompatible attribute for this method: %s", attr_name)
            raise ValueError
        b_entries = set(getattr(self.result_b, attr_name))
        a_entries = set(getattr(self.result_a, attr_name))
        return list(b_entries.difference(a_entries))

    @property
    def true_positives_delta(self) -> list[str]:
        """True Positive entries in B but not in A."""
        return self.delta_entries("true_positives")

    @property
    def false_positives_delta(self) -> list[str]:
        """False Positive entries in B but not in A."""
        return self.delta_entries("false_positives")

    @property
    def true_negatives_delta(self) -> list[str]:
        """True Negative entries in B but not in A."""
        return self.delta_entries("true_negatives")

    @property
    def false_negatives_delta(self) -> list[str]:
        """False Negative entries in B but not in A."""
        return self.delta_entries("false_negatives")


def compute_precision_recall(
    labels_df: pd.DataFrame,
    slicer_output_df: pd.DataFrame,
    input_type: SlicerInputType,
) -> PrecisionRecallResult:
    """
    Function to generate the confusion matrix and compute the precision and recall values.

    Inputs:
    labels_df: Dataframe of the labeled road segments or sim results
    slicer_output_df: Slicer output that was run on the same set of segments from the label sets

    Assumption about inputs:
    The labels and slicer output are from a single version with no duplicates
    labels_df: uuid is the unique identifier and segment_id is non-empty.
    slicer_output_df: start_time and end_time are from UTC timestamp format with fractional seconds up to nanoseconds accuracy.

    Approach:
    We find the potentially overlapped segments between the two datasets by FULL JOIN them with each other.
    From labels_df,
    if we have a positive label, we use the startTime, endTime that's already processed from its labels_data field
    if we have a negative label, startTime and endTime will be empty, we extract start_time and end_time from segment_id

    We use the label segment boundaries to check with the slicer_output_df segments' start_time and end_time
    to find if there is an overlap between the two segments.

    Definition:
    TP: There IS an overlap and labeled: eventInSegment='Yes'
    FP: There IS an overlap but labeled: eventInSegment='No'
    FN: There is NO overlap but labeled: eventInSegment='Yes'
    TN: There is NO overlap and labeled: eventInSegment='No'

    Calculation:
    precision = TP / (TP + FP)
    recall = TP / (TP + FN)

    """
    if input_type == SlicerInputType.SEGMENT_ID:
        segments = labels_df["segment_id"].apply(Segment.from_str)
        labels_df = labels_df.assign(vin=segments.apply(lambda x: x.vin))
        labels_df = labels_df.assign(segment_start_time=segments.apply(lambda x: int(x.start_t_s)))
        labels_df = labels_df.assign(segment_end_time=segments.apply(lambda x: int(x.end_t_s)))
        join_column = "vin"
    elif input_type == SlicerInputType.HYDRA_RUN_ID:
        join_column = "input_id"
        labels_df = labels_df.assign(input_id=labels_df["segment_id"])
        hydra_run_ids: list[str] = labels_df["segment_id"].tolist()
        slicer_output_df = slicer_output_df.rename(columns={"input_id": "_input_id"})
        scenario_bounds = get_sim_scenario_bounds_from_less(hydra_run_ids=hydra_run_ids)
        start_times: list[float] = []
        end_times: list[float] = []
        for hydra_run_id in hydra_run_ids:
            if hydra_run_id not in scenario_bounds or scenario_bounds[hydra_run_id] is None:
                logger.exception("Could not find scenario bounds for hydra run %s", hydra_run_id)
                raise ValueError
            start_times.append(scenario_bounds[hydra_run_id].start_time_s)  # type: ignore[reportGeneralTypeIssues]
            end_times.append(scenario_bounds[hydra_run_id].end_time_s)  # type: ignore[reportGeneralTypeIssues]
        labels_df = labels_df.assign(segment_start_time=start_times)
        labels_df = labels_df.assign(segment_end_time=end_times)
    else:
        logger.exception("Unsupported SlicerInputType %s", input_type)
        raise NotImplementedError

    # If we have a positive label, use the event start/end times from the label.
    # If we have a negative label, use start_time and end_time extracted from segment_id.
    def get_labeled_event_boundaries(row: pd.Series) -> tuple[int, int]:
        if row["is_event_in_segment"] is True:
            return (int(row["event_start_s"]), int(row["event_end_s"]))
        else:
            return (row["segment_start_time"], row["segment_end_time"])

    labels_df[["labeled_event_start_time", "labeled_event_end_time"]] = labels_df.apply(
        get_labeled_event_boundaries,
        axis=1,
        result_type="expand",
    )

    # Early return if no slicer output.
    if slicer_output_df.empty:
        logger.warning("No slicer output present when computing precision recall.")
        tn_ids = labels_df[~labels_df["is_event_in_segment"]]["segment_id"].tolist()
        fn_ids = labels_df[labels_df["is_event_in_segment"]]["segment_id"].tolist()
        return PrecisionRecallResult(
            true_positives=[],
            false_positives=[],
            true_negatives=tn_ids,
            false_negatives=fn_ids,
        )

    # Ensure slicer event times are not datetimes.
    if pd.api.types.is_datetime64_any_dtype(
        slicer_output_df["start_time"]
    ) or pd.api.types.is_datetime64_any_dtype(slicer_output_df["end_time"]):
        raise TypeError("Expected slicer 'start_time'/'end_time' to be float/int, got datetime")

    # Rename slicer event start/end time columns for clarify before joining with labels.
    slicer_output_df = slicer_output_df.rename(
        columns={
            "start_time": "slicer_event_start_time",
            "end_time": "slicer_event_end_time",
            # Rename uuid if it is present in the slicer output as it will mess up the join.
            "uuid": "slicer_uuid",
        }
    )

    # full join the two dataframe by using how='cross'
    cartesian_df = labels_df.merge(slicer_output_df, how="cross")  # pyright: ignore[reportGeneralTypeIssues]

    # find the overlap between the two dataframes
    df_joined = cartesian_df[
        (cartesian_df[join_column] == cartesian_df[f"_{join_column}"])
        & (cartesian_df["labeled_event_start_time"] <= cartesian_df["slicer_event_end_time"])
        & (cartesian_df["slicer_event_start_time"] <= cartesian_df["labeled_event_end_time"])
    ]

    # find the rows in the labels_df where there is no overlap between the two dataframes
    unmatched_labels_df = labels_df[~labels_df["uuid"].isin(df_joined["uuid"])]

    tp_df = df_joined[df_joined["is_event_in_segment"]]
    fp_df = df_joined[~df_joined["is_event_in_segment"]]
    tn_df = unmatched_labels_df[~unmatched_labels_df["is_event_in_segment"]]
    fn_df = unmatched_labels_df[unmatched_labels_df["is_event_in_segment"]]

    def get_labeled_segment_id(row: pd.Series, input_type: SlicerInputType = input_type) -> str:
        """Helper to get a labeled segment ID from a row."""
        if input_type == SlicerInputType.SEGMENT_ID:
            return str(
                Segment(
                    vin=row["vin"],  # type: ignore[reportGeneralTypeIssues]
                    start_t_s=row["slicer_event_start_time"],  # type: ignore[reportGeneralTypeIssues]
                    end_t_s=row["slicer_event_end_time"],  # type: ignore[reportGeneralTypeIssues]
                )
            )
        if input_type == SlicerInputType.HYDRA_RUN_ID:
            return f"{row['segment_id']}:{row['slicer_event_start_time']}:{row['slicer_event_end_time']}"
        logger.exception("Unsupported input type: %s", input_type)
        raise NotImplementedError

    # Extract the label event IDs for the positive results and input segment IDs for the negatives.
    tp_event_ids = tp_df.apply(get_labeled_segment_id, axis=1).to_list() if not tp_df.empty else []
    fp_event_ids = fp_df.apply(get_labeled_segment_id, axis=1).to_list() if not fp_df.empty else []
    return PrecisionRecallResult(
        true_positives=tp_event_ids,
        false_positives=fp_event_ids,
        true_negatives=tn_df["segment_id"].to_list(),
        false_negatives=fn_df["segment_id"].to_list(),
    )
