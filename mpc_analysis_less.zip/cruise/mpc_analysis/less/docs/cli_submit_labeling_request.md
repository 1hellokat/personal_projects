# LESS CLI Submit Labeling Request Command

The submit_labeling_request command is used to submit a set of events (road segment IDs or hydra run IDs) to TPO for labeling

This command accepts a slicer name and a path to a list of input IDs (road segment IDs or hydra run IDs, one per line).

You can run `bazel run //cruise/mpc_analysis/less/cli -- submit_labeling_request scene_labels --help` to see the full list of options.

For example:

```
bazel run //cruise/mpc_analysis/less/cli -- submit_labeling_request scene_labels -s sc_3_av_lane_boundary_violation_scene -i ~/path_to_ids.txt
```

This command is typically used when events (hydra run IDs or segment IDs) are sourced manually vs sourcing from running a slicer.

When running this command, the user will be asked to provide input relevant to this dataset. One of the questions is whether this set of labels is to be used for precision, recall or both. See the [Onboarding Slicers](onboarding_slicers.md#sourcing-segments) page for more information on this.

NOTE: if you are developing a new slicer, you will need to run this command on the branch with the new slicer.