# LESS CLI Run Command

The run command is used to run slicers on launches or segments. This will run the slicer on the provided launch/segment and print the result to the terminal.

You can run `bazel run //cruise/mpc_analysis/less/cli -- run slicer --help` to see the full list of options.

## How to run a slicer on a road segment and/or launch

`bazel run //cruise/mpc_analysis/less/cli -- run slicer <slicer name> -i <segment id> -i <launch/drive id> -o /tmp/slicer_output.csv`

`-o <path>` is optional and will write the results to a CSV or parquet file.

`--debug` just drops into a python terminal so users can debug or look into the results.

`--rerun_slicer` regenerates the slicer output using the local branch code (though currently only the slicer query is updated - upstream slicers and attributes are not regenerated). If this argument is omitted, it will query the existing slicer generated output in the slicer's `__latest_full_drive__` table.

`-w` or `--webviz` will print out a set of webviz links

## How to run a slicer from a list of launches/segments from a file

`bazel run //cruise/mpc_analysis/less/cli -- run slicer <slicer name> --input_path <path to input file>`

The input file in this case needs to have one launch ID or segment ID per line.

## Example

`bazel run //cruise/mpc_analysis/less/cli -- run slicer av_in_driveable_area_scene -i 0e8ac12a-ae23-4d47-a209-d978f780a0bb`

```
Querying launch keys for launches:  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00 0:00:05 1/1
Retrieving existing slicer results:  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00 0:00:03 1/1
[2025-05-29 12:18:12][INFO][run.py:193] Slicer results generated for 1/1 input IDs.
  Slicer: av_in_driveable_area_scene results for Launch ID:  
            0e8ac12a-ae23-4d47-a209-d978f780a0bb             
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┓
┃ _vin              ┃ start_time        ┃ end_time          ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━┩
│ 5G21A6P09N4121679 │ 1716127911.151309 │ 1716127973.950377 │
│ 5G21A6P09N4121679 │ 1716128282.450099 │ 1716140594.949632 │
└───────────────────┴───────────────────┴───────────────────┘
```