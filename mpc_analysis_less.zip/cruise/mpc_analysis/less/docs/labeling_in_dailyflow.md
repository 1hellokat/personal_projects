# Labeling in DailyFlow

Labeling events in DailyFlow for LESS requires two things:
1) A webviz link for a segment to label
2) The task queue name that was used to register the slicer (typically the slicer name).

Finding webviz links for segments can be generated using the [LESS CLI Run Command](cli_run.md) or the [LESS CLI Source Command](cli_source.md)

## How to label events
1. Events can be sourced however makes sense but really all you need is a webviz link for a segment.
2. Once in webviz, if the dailyflow panel is not present, click the `+` in the top right for `Add Panel` and select `DailyFlow`
3. If the dailyflow panel doesn't load (white screen), navigate to `go/dailyflow` and authenticate and return back to webviz and retry
4. In the DailyFlow panel, select the appropriate task queue at the top (usually slicer name) --> SEE FIGURE BELOW
5. Answer the questions related to the segment (`Is there a relevant event in the segment?`)
6. If the answer is Yes, populate the timestamps (rounded to the nearest second)
7. Click `Save` to save the ground truth information (there should be a dialog message that indicates the segment was saved)

How to select the task queue:

![DailyFlow Task Queue Selection](assets/dailyflow_labeling_task_queue_selection.png "DailyFlow Task Queue Selection")
