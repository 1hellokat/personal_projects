# LESS CLI Source Command

The source command is used to find events of interest - currently this only supports a COLA search. 

This command accepts a text prompt along with some optional filtering parameters and returns the highest similarity matches.

Note that this is really the same functionality as the COLA UI ([go/cola](https://go.robot.car/cola)) - the reason it is replicated in LESS is so that you can submit the results for TPO labeling so that they can be labeled and used for a slicer precision/recall evaluation.

You can run `bazel run //cruise/mpc_analysis/less/cli -- source cola --help` to see the full list of options.