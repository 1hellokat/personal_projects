# LESS CLI Register Command

The register command is currently only used to onboard a slicer onto LESS for DailyFlow labeling. This is one time step and only required if DailyFlow labels are chosen. If using only TPO labels, this command is not necessary.

You can run `bazel run //cruise/mpc_analysis/less/cli -- register scene_labelset --help` to see the full list of options.

This command will create a DailyFlow Task Queue that will be used to associate the developer created labels in webviz via the DailyFlow panel.

## What does this command do?

This command does a couple things:
1) Creates the DailyFlow task queue
2) Stores some info the LESS database to register/associate this DailyFlow task queue to this slicer

## What is DailyFlow?

DailyFlow is a platform for flexible labeling for a variety of use-cases. Check out [go/dailyflow](https://go.robot.car/dailyflow) or the `#dailyflow` slack channel for more info.
