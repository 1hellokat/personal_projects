# LESS CLI View Command

The view command is used to view labels or label requests in LESS. This is mostly used for LESS framework developers.

You can run `bazel run //cruise/mpc_analysis/less/cli -- view --help` to see the full list of options.

## Examples

`bazel run //cruise/mpc_analysis/less/cli -- view scene_labels --slicer_name av_in_speed_bump_scene`

```
[2025-05-29 14:05:10][INFO][client.py:214] Found 24 labels for task_queue_id 2462
[2025-05-29 14:05:10][INFO][view.py:56] Found 24 total labels
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ uuid                                 ┃ segment_id                              ┃ source    ┃ is_event_in_segment ┃ event_start_s ┃ event_end_s  ┃ road_event_id                           ┃ task_id  ┃ task_queue_id ┃ tpo_request_id ┃ slicer_name            ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━┩
│ e46118a4-9d79-4d62-aafb-52017e3b2185 │ 5G21A6P06L4100043:1698910006:1698910016 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P06L4100043:1698910006:1698910016 │ 261463.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ cc3c3ab5-674b-40cc-9758-454bbb51bde2 │ 5G21A6P00P4100075:1732892224:1732892234 │ DAILYFLOW │ True                │ 1732892227.0  │ 1732892229.0 │ 5G21A6P00P4100075:1732892224:1732892234 │ 261478.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ f21ceca8-46dd-45d2-bcb9-874a57973b11 │ 5G21A6P09P4130000:1693326032:1693326042 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P09P4130000:1693326032:1693326042 │ 261469.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ a11c609d-45f7-44ad-92a1-5bab5d3ab40a │ 5G21A6P08P4104679:1727113740:1727113750 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P08P4104679:1727113740:1727113750 │ 261467.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 01947746-da6b-48ee-8ccb-541fd8e7477c │ 5G21A6P06P4107936:1722018548:1722018558 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P06P4107936:1722018548:1722018558 │ 261483.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 2a6c6774-211f-41b9-96ab-895a9224983b │ 5G21A6P00L4100121:1698281380:1698281400 │ DAILYFLOW │ True                │ 1698281393.0  │ 1698281395.0 │ 5G21A6P00L4100121:1698281380:1698281400 │ 261482.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ c71da56c-a122-4ab2-9bf3-eda6f5c8566c │ 5G21A6P09L4100182:1698089146:1698089156 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P09L4100182:1698089146:1698089156 │ 261473.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ de8e9ae0-05d2-4ac8-9ac3-e90cf6c130e4 │ 5G21A6P08N4121625:1731896571:1731896591 │ DAILYFLOW │ True                │ 1731896580.0  │ 1731896581.0 │ 5G21A6P08N4121625:1731896571:1731896591 │ 265226.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 343e3568-9bfc-4bea-ad8a-cf919f6e4878 │ 5G21A6P08N4121625:1731896571:1731896591 │ DAILYFLOW │ True                │ 1731896585.0  │ 1731896587.0 │ 5G21A6P08N4121625:1731896571:1731896591 │ 265226.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ e53e47f1-699e-4129-bb8d-f4795dd2171e │ 5G21A6P03P4114536:1730729222:1730729232 │ DAILYFLOW │ True                │ 1730729228.0  │ 1730729232.0 │ 5G21A6P03P4114536:1730729222:1730729232 │ 261476.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ cc94e899-24aa-42c1-ad8d-7ab1da211387 │ 5G21A6P00P4100075:1732892234:1732892244 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P00P4100075:1732892234:1732892244 │ 261477.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 1d0cd5ce-3248-4044-afd4-e33456bde1ae │ 5G21A6P08L4100173:1698418344:1698418354 │ DAILYFLOW │ True                │ 1698418347.0  │ 1698418350.0 │ 5G21A6P08L4100173:1698418344:1698418354 │ 261462.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ d4e49ef2-d9e3-4bcb-a2e1-b8125100a3cc │ 5G21A6P06L4100043:1698325201:1698325221 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P06L4100043:1698325201:1698325221 │ 261481.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 0a1fa55c-674e-41c8-a1e1-44ca0e2d0cae │ 5G21A6P02P4112809:1698176937:1698176947 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P02P4112809:1698176937:1698176947 │ 261464.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 2d654758-6df6-490d-8870-62767f239962 │ 5G21A6P05P4100590:1731358530:1731358540 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P05P4100590:1731358530:1731358540 │ 261471.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 68eec3dc-0bab-4c2a-a61d-5aa71d255389 │ 5G21A6P05P4100590:1731358520:1731358530 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P05P4100590:1731358520:1731358530 │ 261472.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 42b5964f-96ce-4b70-96b8-d4a15251f741 │ 5G21A6P08P4104679:1727113750:1727113760 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P08P4104679:1727113750:1727113760 │ 261466.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 08af22ce-4691-4b89-b15f-27628d73f752 │ 5G21A6P0XL4100076:1698670678:1698670688 │ DAILYFLOW │ True                │ 1698670685.0  │ 1698670687.0 │ 5G21A6P0XL4100076:1698670678:1698670688 │ 261470.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 52d4ff57-9334-428c-8040-85a6c0443087 │ 5G21A6P07L4100164:1602181554:1602181564 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P07L4100164:1602181554:1602181564 │ 261475.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ c820b9d9-0ce8-413a-a82d-34902643e026 │ 5G21A6P07L4100164:1602181544:1602181554 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P07L4100164:1602181544:1602181554 │ 261474.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ df5664ab-f473-4b25-9279-15c0a054eb7d │ 5G21A6P02P4112809:1698176927:1698176937 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P02P4112809:1698176927:1698176937 │ 261465.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ 2225312d-e821-4113-8c6d-1809eee3b177 │ 5G21A6P06L4100043:1698743493:1698743503 │ DAILYFLOW │ True                │ 1698743497.0  │ 1698743499.0 │ 5G21A6P06L4100043:1698743493:1698743503 │ 261479.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ b3e4bcb3-3ffa-4d32-a062-adcb3c54cad9 │ 5G21A6P0XP4163930:1732231449:1732231459 │ DAILYFLOW │ True                │ 1732231455.0  │ 1732231459.0 │ 5G21A6P0XP4163930:1732231449:1732231459 │ 261480.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
│ ed176778-1467-4a70-a93c-a410075526c8 │ 5G21A6P09P4130000:1693326042:1693326051 │ DAILYFLOW │ False               │ nan           │ nan          │ 5G21A6P09P4130000:1693326042:1693326051 │ 261468.0 │ 2462.0        │ nan            │ av_in_speed_bump_scene │
└──────────────────────────────────────┴─────────────────────────────────────────┴───────────┴─────────────────────┴───────────────┴──────────────┴─────────────────────────────────────────┴──────────┴───────────────┴────────────────┴────────────────────────┘
```