# LESS CLI Evaluate Command

The evaluate command will run precision/recall for a slicer and print the results to the terminal. 

You can run `bazel run //cruise/mpc_analysis/less/cli -- evaluate scene_pr --help` to see the full list of options.

`--debug` just drops into a python terminal so users can debug or look into the results.

`--rerun_slicer` regenerates the slicer output using the local branch code (though currently only the slicer query is updated - upstream slicers and attributes are not regenerated). If this argument is omitted, it will query the existing slicer generated output in the slicer's `__latest_full_drive__` table.

## How to generate precision/recall results

All that is needed for the evaluate command is the name of the slicer

`//cruise/mpc_analysis/less/cli -- evaluate scene_pr --slicer_name=<slicer name>`

## Example

`bazel run //cruise/mpc_analysis/less/cli -- evaluate scene_pr --slicer_name=av_in_speed_bump_scene`

```
[2025-05-29 13:22:49][INFO][client.py:214] Found 24 labels for task_queue_id 2462
[2025-05-29 13:22:49][INFO][evaluate.py:124] Retrieved 24 labels for slicer av_in_speed_bump_scene
[2025-05-29 13:22:49][INFO][evaluate.py:60] av_in_speed_bump_scene output will be queried from existing BQ table data
Querying launch keys for segments:  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00 0:00:04 23/23
Retrieving existing slicer results:  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00 0:00:04 1/1
[2025-05-29 13:22:59][INFO][evaluate.py:71] Successfully processed 23/23 segments
[2025-05-29 13:22:59][INFO][evaluate.py:88] Slicer produced 4 events from 23 segments
                     Confusion Matrix - av_in_speed_bump_scene                      
┌────────────────────┬───────────────────────────┬────────────────────────────┬────┐
│      N  = 24       │ Slicer reported event: NO │ Slicer reported event: YES │    │
├────────────────────┼───────────────────────────┼────────────────────────────┼────┤
│ Labeled Event: NO  │          TN = 15          │           FP = 0           │ 15 │
├────────────────────┼───────────────────────────┼────────────────────────────┼────┤
│ Labeled Event: YES │          FN = 5           │           TP = 4           │ 9  │
├────────────────────┼───────────────────────────┼────────────────────────────┼────┤
│                    │            20             │             4              │    │
└────────────────────┴───────────────────────────┴────────────────────────────┴────┘
                                                 Precision/Recall Entries - av_in_speed_bump_scene                                                  
┏━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Precision ┃ Recall ┃ True Negatives                          ┃ False Negatives                         ┃ True Positives                          ┃
┡━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ 1.00      │ 0.44   │ 5G21A6P06L4100043:1698910006:1698910016 │ 5G21A6P00L4100121:1698281380:1698281400 │ 5G21A6P00P4100075:1732892227:1732892229 │
│           │        │ 5G21A6P09P4130000:1693326032:1693326042 │ 5G21A6P08L4100173:1698418344:1698418354 │ 5G21A6P08N4121625:1731896580:1731896582 │
│           │        │ 5G21A6P08P4104679:1727113740:1727113750 │ 5G21A6P0XL4100076:1698670678:1698670688 │ 5G21A6P08N4121625:1731896585:1731896588 │
│           │        │ 5G21A6P06P4107936:1722018548:1722018558 │ 5G21A6P06L4100043:1698743493:1698743503 │ 5G21A6P03P4114536:1730729228:1730729232 │
│           │        │ 5G21A6P09L4100182:1698089146:1698089156 │ 5G21A6P0XP4163930:1732231449:1732231459 │                                         │
│           │        │ 5G21A6P00P4100075:1732892234:1732892244 │                                         │                                         │
│           │        │ 5G21A6P06L4100043:1698325201:1698325221 │                                         │                                         │
│           │        │ 5G21A6P02P4112809:1698176937:1698176947 │                                         │                                         │
│           │        │ 5G21A6P05P4100590:1731358530:1731358540 │                                         │                                         │
│           │        │ 5G21A6P05P4100590:1731358520:1731358530 │                                         │                                         │
│           │        │ 5G21A6P08P4104679:1727113750:1727113760 │                                         │                                         │
│           │        │ 5G21A6P07L4100164:1602181554:1602181564 │                                         │                                         │
│           │        │ 5G21A6P07L4100164:1602181544:1602181554 │                                         │                                         │
│           │        │ 5G21A6P02P4112809:1698176927:1698176937 │                                         │                                         │
│           │        │ 5G21A6P09P4130000:1693326042:1693326051 │                                         │                                         │
└───────────┴────────┴─────────────────────────────────────────┴─────────────────────────────────────────┴─────────────────────────────────────────┘
                               False Negative Webviz Links                               
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ False Negatives                                                                       ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ https://webviz.robot.car/?vin=5G21A6P00L4100121&start=1698281380000&end=1698281400000 │
│ https://webviz.robot.car/?vin=5G21A6P08L4100173&start=1698418344000&end=1698418354000 │
│ https://webviz.robot.car/?vin=5G21A6P0XL4100076&start=1698670678000&end=1698670688000 │
│ https://webviz.robot.car/?vin=5G21A6P06L4100043&start=1698743493000&end=1698743503000 │
│ https://webviz.robot.car/?vin=5G21A6P0XP4163930&start=1732231449000&end=1732231459000 │
└───────────────────────────────────────────────────────────────────────────────────────┘

```