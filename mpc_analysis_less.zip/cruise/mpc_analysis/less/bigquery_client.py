"""Module for interacting with bigquery for the LESS project"""

# System imports
import json
import logging
from typing import Optional, Union

# Third-party imports
import pandas as pd
from google.api_core.exceptions import BadRequest, GoogleAPICallError
from google.cloud import bigquery
from google.cloud.bigquery.table import RowIterator
from google.oauth2 import service_account

# Cruise imports
from cruise.mlp.roboflow2.secrets import VaultSecretStore
from cruise.mpc_analysis.less.constants import LESS_GCP_PROJECT_ID, LESS_SVC_ACCT_VAULT_PATH

logger = logging.getLogger(__name__)


class LessBigQueryClient:
    """Singleton class for interacting with BigQuery using the LESS service account."""

    _instance: Optional["LessBigQueryClient"] = None
    _is_initialized: bool = False

    def __new__(cls, *args, **kwargs) -> "LessBigQueryClient":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(
        self, project_id: Optional[str] = None, credentials_json_str: Optional[str] = None
    ) -> None:
        if self._is_initialized:
            return
        self._set_initialized()
        if credentials_json_str is None and project_id is None:
            self.client = bigquery.Client()
        elif credentials_json_str is None:
            self.client = bigquery.Client(project_id)
        else:
            credentials_json = json.loads(credentials_json_str)
            credentials = service_account.Credentials.from_service_account_info(credentials_json)

            self.client = bigquery.Client(project_id, credentials)

    @classmethod
    def _reset_singleton(cls) -> None:
        """Reset helper mainly for unit testing."""
        cls._instance = None
        cls._is_initialized = False

    @classmethod
    def _set_initialized(cls) -> None:
        """Helper to set the initialized class variable."""
        cls._is_initialized = True

    def run_query(
        self, query: str, as_dataframe: bool = False
    ) -> Union[RowIterator, pd.DataFrame]:
        """Execute a query with optional return type."""
        try:
            query_job = self.client.query(query)
            if as_dataframe:
                return query_job.to_dataframe()
            return query_job.result()
        except BadRequest:
            logger.exception("Invalid BigQuery request")
            raise
        except GoogleAPICallError:
            logger.exception("Google API call error")
            raise
        except Exception:
            logger.exception("An unexpected error occurred while making BigQuery request")
            raise

    def run_query_and_get_dataframe(self, query: str) -> pd.DataFrame:
        """Execute a query and return as a dataframe."""
        out_frame = self.run_query(query=query, as_dataframe=True)
        if not isinstance(out_frame, pd.DataFrame):
            # Should never get here.
            logger.exception("Expected DataFrame from run_query(...), got %s", type(out_frame))
            raise TypeError
        return out_frame

    @classmethod
    def init_from_vault(cls) -> "LessBigQueryClient":
        """Initialize the client by reading the service account details from Vault."""
        if cls._instance is not None:
            return cls._instance
        vault_store = VaultSecretStore()
        credentials_json_str = vault_store.read_secret_from_path(LESS_SVC_ACCT_VAULT_PATH)
        if credentials_json_str is None:
            # Should never get here since read_secret_from_path(...) will likely raise.
            logger.exception("Error reading LESS service account details from Vault")
            raise ValueError
        return LessBigQueryClient(
            project_id=LESS_GCP_PROJECT_ID, credentials_json_str=credentials_json_str
        )

    @classmethod
    def init_from_default_creds(cls) -> "LessBigQueryClient":
        if cls._instance is not None:
            return cls._instance
        return LessBigQueryClient()
