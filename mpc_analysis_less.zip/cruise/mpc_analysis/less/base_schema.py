"""Library that defines a base schema class to be used in the LESS project.

The purpose of these schemas:
    - Explicitly define a format
    - Enforce type checking
"""

# System imports
import logging
from dataclasses import MISSING, Field, dataclass, fields
from typing import Any, Iterable

# Third-party imports
import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class FieldInfo:
    """Structure to store dataclass field info."""

    field_type: type
    has_default: bool


def extract_field_info(field_data: Iterable[Field]) -> dict[str, FieldInfo]:
    """Helper to create a dictionary of field infos."""
    return {
        field.name: FieldInfo(
            field_type=field.type,
            has_default=field.default is not MISSING or field.default_factory is not MISSING,
        )
        for field in field_data
    }


@dataclass
class BaseSchema:
    """Base schema class for the LESS project."""

    @classmethod
    def dtypes(cls) -> dict[str, type]:
        """Helper to return the class datatypes."""
        return {k: v.field_type for k, v in extract_field_info(fields(cls)).items()}

    @classmethod
    def from_dict(cls, input: dict[str, Any]) -> "BaseSchema":
        """Create an instance of the class from a dictionary with type checking."""
        cls_types = cls.dtypes()
        for key, val in input.items():
            if key in cls_types and not isinstance(val, cls_types[key]):
                logger.exception(
                    "Incorrect type for field: %s, expected %s, got %s",
                    key,
                    cls_types[key],
                    type(val),
                )
                raise TypeError
        return cls(**input)

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(
            [{attr_name: getattr(self, attr_name) for attr_name in self.dtypes()}]
        ).astype(
            self.dtypes()  # type: ignore[reportGeneralTypeIssues]
        )
