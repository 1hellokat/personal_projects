# Labeling & Evaluating Slicer Success (LESS)

This sub-directory is for tooling related to the LESS Project (project details can be found in [this doc](https://docs.google.com/document/d/1Nfb6Fe5T6J6PyMSQTHzCEa4T1JIOZGC9tM_GKXK2FQI)).

## What is LESS?

LESS is mainly a framework for evaluating slicer performance and label management tooling. 

More concretely, LESS computes precision/recall for scene slicers using ground truth data. This can be used for:
* Development (when first creating a slicer or when making a change to a slicer)
* Performance monitor (keep track of slicer performance over time)
* Regression/smoke testing (ensuring things are not broken or degraded on develop)

## Beyond Scene Slicer Precision Recall

LESS is intended to be generic and as such can be utilized for other use cases.
There would be some development work to enable a new use case such as defining schemas, writing adapter code for converting labels, writing code for running the unit under test (e.g. running a slicer).
Please reach out in [#evaluation-less-development](https://gm.enterprise.slack.com/archives/C08J5HQCFC4) if you have a use case in mind!

## How are scene slicer labels generated?

The first step is creating clear, objective labeling instructions (presumably in a google or office doc and add a version).

Labels can come from two sources: 
*DailyFlow* Segments are labeled in webviz using the DailyFlow panel. This is typically done by development engineers (i.e. engineers developing the slicer)
*TPO* Segments are labeled by the TPO labeling team (using the GULP tool). This is the preferred method as it is more automated, scales better and requires less developer time.

NOTE: Scene slicer labels should be thought of as a binary question - is there a relevant event in the *entire* road segment/sim scenario or not? Things like labeling multiple events within a single road segment/sim scenario is not currently possible. There is limited support for requesting additional information on a positive labeled event. This is done via the freeform question - for example, for a scene slicer that detects traffic light interactions (yes/no traffic light present), the freeform question can be used to determine the traffic light state (red/yellow/green).

## Limitations

### Slicer Types
Currently only scene slicers are supported in LESS. It's likely possible to expand to support LGTM slicers or CBA aggregators but that has not been added yet.

### Slicer Modalities
Currently only road segments can be labeled. So slicers that support Road + Sim or Road only can be onboarded to LESS.

### Slicer Execution Modes
LESS supports running scene slicers in two modes:
1) Query existing slicer output - this just queries the slicer output from the `__latest_full_drive__` table (i.e. slicer output from UMM)
2) Rerun the slicer - this regenerates the slicer SQL query and executes it (but not that this does not regenerate any upstream slicer output)

Regenerating the upstream slicer output or regenerating the attribute data is not currently supported directly in LESS.

## Regression Testing (Develop Scheduled Runs)

LESS provides slicer regression testing in the form of daily scheduled runs on develop and the results are stored in bigquery.
These runs involve computing precision/recall on develop for all slicers with labels for both slicer execution modes (rerunning the slicer and querying the existing output).
Alerts for failures and regressions are posted in `#evaluation-less-alerts` (in the cruise workspace)

A dashboard does not yet exist to view the results but should be deployed soon.

## How to use LESS

The LESS CLI is main way for users to interact with LESS. The bazel command entry point for the LESS CLI is `bazel run //cruise/mpc_analysis/less/cli`

The LESS CLI Supports the following subcommands:

| Subcommand | Description |
|------------|-------------|
| [Evaluate](docs/cli_evaluate.md) | Compute precision/recall for a slicer |
| [Run](docs/cli_run.md) | Run a slicer on a set of launches or segments (and optionally submit for TPO labeling)|
| [Register](docs/cli_register.md) | Onboard a slicer for DailyFlow labeling |
| [Source](docs/cli_source.md) | Search for road segments using COLA (and optionally submit for TPO labeling)|
| [Submit Labeling Request](docs/cli_submit_labeling_request.md) | Submit events for TPO labeling|
| [View](docs/cli_view.md) | Examine the labels or label requests (mostly used for LESS developers)|

## When submitting a TPO labeling request, which command should I use (run, source, submit labeling request)?

`run` is the most common way as you can run a slicer on a set of random recent drives and submit the results for TPO labeling

`submit_labeling_request` is a more advanced option if you already have a list of segment IDs or hydra run IDs and want them labeled

`source` is a less common way that uses a COLA search.
 

## How LESS Works

![LESS Scene Slicer Onboarding Workflow](docs/assets/less_scene_slicer_onboarding_workflow.png "LESS Scene Slicer Onboarding Workflow")

![LESS Scene Slicer Data Flow](docs/assets/less_scene_slicer_data_flow.png "LESS Scene Slicer Data Flow")

## How to onboard new scene slicers

See the [Onboarding Slicers](docs/onboarding_slicers.md) page.

## Troubleshooting

If you run into a permissions issue and have recently run `authcli refresh`, please post the full error in [#ask-evaluation-less](https://gm.enterprise.slack.com/archives/C08ULUZLC4U)

## Code Ownership

The code in this folder will be owned by the IOP group `evaluation-less`