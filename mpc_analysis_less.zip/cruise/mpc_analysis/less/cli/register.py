"""CLI Command for registering items into LESS."""

# System imports
import logging
from typing import Optional

# Third-party imports
import click

# Cruise imports
from cruise.mpc_analysis.less.labels.dailyflow import create_dailyflow_labelset

logger = logging.getLogger(__name__)


@click.group(name="register")
def register() -> None:
    """Register items into LESS (labelsets, etc.)."""
    pass


@register.command(name="scene_labelset")
@click.option("--slicer_name", type=str, required=True, help="(e.g. av_in_speed_bump_scene)")
@click.option("--labelset_name", type=str, help="Optional labelset name, defaults to slicer_name")
@click.option(
    "--existing_task_queue_id",
    type=int,
    help="Register using an existing dailyflow task queue ID (currently required)",
)
def register_scene_labelset(
    slicer_name: str,
    labelset_name: Optional[str],
    existing_task_queue_id: Optional[int],
) -> None:
    """Registers a Scene Slicer labelset with LESS for future use."""
    if labelset_name is None:
        labelset_name = slicer_name
    create_dailyflow_labelset(
        labelset_name=labelset_name,
        slicer_name=slicer_name,
        existing_task_queue_id=existing_task_queue_id,
    )
