"""CLI Command for viewing LESS artifacts."""

# System imports
import logging
from typing import Optional

# Third-party imports
import click
import IPython

# Cruise imports
from cruise.mpc_analysis.less.labels.client import LabelSetManager, LessLabelClient
from cruise.mpc_analysis.less.labels.label_schema import SceneSlicerLabel
from cruise.mpc_analysis.less.visualization import print_dataframe_in_terminal

logger = logging.getLogger(__name__)


@click.group(name="view")
def view() -> None:
    """View LESS artifacts (available labelsets, etc.)."""
    pass


@view.command(name="scene_labelsets")
@click.option("--debug", "-d", is_flag=True, help="Interactive terminal for debugging")
def view_scene_labelsets(debug: bool) -> None:
    """View all the scene slicer labelsets in the registry."""
    labelsets_df = LabelSetManager().get_labelset_info().drop(columns=["segment_ids"])
    logger.info(f"Found {len(labelsets_df)} total labelsets")
    print_dataframe_in_terminal(df=labelsets_df)
    if debug:
        IPython.embed()


@view.command(name="scene_labels")
@click.option("--labelset_name", type=str, help="Optional labelset name to filter on")
@click.option("--slicer_name", type=str, help="Optional slicer name to filter on")
@click.option("--debug", "-d", is_flag=True, help="Interactive terminal for debugging")
def view_scene_labels(
    labelset_name: Optional[str], slicer_name: Optional[str], debug: bool
) -> None:
    """View all the scene slicer labels."""
    if labelset_name is None and slicer_name is None:
        logger.error("Must provide --labelset_name OR --slicer_name args!!")
        return

    label_client = LessLabelClient(schema_type=SceneSlicerLabel)
    filter_args: dict[str, str] = {}
    labelsets_df = LabelSetManager().get_labelset_info().drop(columns=["segment_ids"])
    if labelset_name is not None:
        filter_args["labelset_name"] = labelset_name
        labelsets_df = labelsets_df[labelsets_df["labelset_name"] == labelset_name]
    if slicer_name is not None:
        filter_args["slicer_name"] = slicer_name
        labelsets_df = labelsets_df[labelsets_df["slicer_name"] == slicer_name]
    labels_df = label_client.resolve_labelsets(**filter_args).drop(columns=["metadata"])
    logger.info(f"Found {len(labelsets_df)} total labelsets")
    print_dataframe_in_terminal(df=labelsets_df.reset_index())
    logger.info(f"Found {len(labels_df)} total labeled events (only first 50 shown)")
    positive_labels = len(labels_df[labels_df["is_event_in_segment"] == True])
    positive_labels_percent = round(
        len(labels_df[labels_df["is_event_in_segment"] == True]) / len(labels_df) * 100.0, 1
    )
    negative_labels = len(labels_df[labels_df["is_event_in_segment"] == False])
    negative_labels_percent = round(
        len(labels_df[labels_df["is_event_in_segment"] == False]) / len(labels_df) * 100.0, 1
    )
    logger.info(
        f"{positive_labels} ({positive_labels_percent}%) are Positive Labels and {negative_labels} ({negative_labels_percent}%) are Negative Labels"
    )
    print_dataframe_in_terminal(df=labels_df.head(50))
    if debug:
        IPython.embed()
