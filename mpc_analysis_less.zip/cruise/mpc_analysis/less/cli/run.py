"""CLI Command for LESS for running things (e.g. slicers)."""

# System imports
import logging
from pathlib import Path
from typing import Optional

# Third-party imports
import click
import IPython
import pandas as pd
from pandas.api.types import is_integer_dtype

# Cruise imports
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.constants import (
    DEFAULT_MAX_NUM_TPO_SEGMENTS,
    DEFAULT_MIN_SEGMENT_LENGTH,
    DEFAULT_TRACK_ID,
)
from cruise.mpc_analysis.less.labels.tpo import (
    EventSource,
    TPOLabelingSegmentInfo,
    submit_segments_for_tpo_labeling,
)
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.slicer_utils import (
    SlicerExecutionResult,
    SlicerInputModality,
    SlicerInputType,
    run_slicer_on_road_data,
    run_slicer_on_sim_data,
    split_input_ids_by_modality,
)
from cruise.mpc_analysis.less.visualization import (
    print_dataframe_in_terminal,
    webviz_link_from_row,
)

logger = logging.getLogger(__name__)


def _print_slicer_results(
    result: SlicerExecutionResult,
    slicer_name: str,
    add_webviz_links: bool = False,
    max_rows: int = 50,
) -> None:
    """Helper to print out the slicer results to the terminal."""
    title = title = f"Slicer: {slicer_name} results for "
    if result.input_type == SlicerInputType.SEGMENT_ID:
        title += f"Segment: {result.input_id} "
    if result.launch_key is not None:
        title += f"Launch ID: {result.launch_key.launch_id}"
    if result.input_type == SlicerInputType.HYDRA_RUN_ID:
        title += f"Hydra Run ID: {result.input_id}"
    if not result.was_successfully_executed:
        logger.error(f"Error generating {title}\n{result.error_msg}")
        return
    if result.slicer_output.empty:
        title = title.replace("results", "produced NO results")
        empty_placeholder_df = pd.DataFrame([{"(no results)": " " * len(title)}])
        print_dataframe_in_terminal(df=empty_placeholder_df, title=title, max_rows=max_rows)
        return

    slicer_output_df: pd.DataFrame = result.slicer_output
    columns_to_drop = [
        "_launch_id",
        "attribute_git_hash",
        "attribute_git_branch",
        "_git_hash",
        "_git_branch",
        "_metadata",
        "major_version",
        "minor_version",
        "version_hash",
    ]
    for column in columns_to_drop:
        if column in slicer_output_df.columns:
            slicer_output_df = slicer_output_df.drop(column, axis=1)
    print_dataframe_in_terminal(df=slicer_output_df, title=title, max_rows=max_rows)
    if add_webviz_links:
        webviz_links = slicer_output_df.apply(webviz_link_from_row, axis=1)
        print_dataframe_in_terminal(
            df=pd.DataFrame({"Webviz Links": webviz_links}), title=title, max_rows=max_rows
        )


def get_random_recent_launches(fleet_allocation_name: str, num_launches: int) -> list[str]:
    query = f"""
        SELECT
            date_driven,
            _launch_id
        FROM (
            SELECT
                id as _launch_id,
                DATE(start_time) as date_driven,
                ROW_NUMBER() OVER (PARTITION BY DATE(start_time) ORDER BY RAND()) as rn
            FROM
            `ca-data-engineering-prd-3nxr.car_metrics.drives_merged`
            WHERE DATE(start_time) BETWEEN DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY) AND CURRENT_DATE() 
                AND fleet_allocation_name = '{fleet_allocation_name}' and total_miles > 0.1
        ) AS t
        WHERE
            t.rn = 1
        LIMIT {num_launches};
        """
    bq_client = LessBigQueryClient.init_from_default_creds()
    sampled_ids = bq_client.run_query_and_get_dataframe(query=query)["_launch_id"].tolist()
    return sampled_ids


def _parse_inputs(
    input_ids: Optional[list[str]],
    input_path: Optional[Path],
    random_launches: bool,
    slicer_name: str,
    num_launches: int,
) -> dict[SlicerInputModality, list[str]]:
    """Helper to parse the input IDs & path and output a list of IDs."""
    if input_ids is None and input_path is None and random_launches is False:
        raise ValueError("Must provide either --input_ids, --input_path or --random_launches !!")

    input_ids_to_process: list[str] = []

    if input_ids is not None:
        input_ids_to_process.extend(input_ids)

    if input_path is not None:
        with input_path.open() as f:
            ids_from_path = [id for id in f.read().splitlines() if id]
            logger.info(f"Read {len(ids_from_path)} IDs from {input_path}")
            input_ids_to_process.extend(ids_from_path)

    if random_launches:
        # Select either mapped or mapless launch_ids based on slicer name
        if "unlocalized" in slicer_name or "sc_3" in slicer_name:
            fleet_allocation_name = (
                "a110-manual-testing-mileage_accumulation-mapless"  # pull mapless launch_ids
            )
        elif "dcv" in slicer_name:
            logger.exception(
                "Can only use auto launch_ids for A110 data currently. Please add launch_ids manually"
            )
            raise NotImplementedError
        else:
            fleet_allocation_name = "manual-mileage-accumulation"  # pull mapped launch_ids
        sampled_ids = get_random_recent_launches(
            fleet_allocation_name=fleet_allocation_name, num_launches=num_launches
        )
        input_ids_to_process.extend(sampled_ids)

    return split_input_ids_by_modality(input_ids=input_ids_to_process)


def _slicer_output_to_tpo_segment_infos(
    slicer_results_df: pd.DataFrame,
) -> list[TPOLabelingSegmentInfo]:
    """Convert the slicer output into the TPO segment infos for the labeling request."""
    output: list[TPOLabelingSegmentInfo] = []
    is_track_id_in_results = "track_id" in slicer_results_df and is_integer_dtype(
        slicer_results_df["track_id"]
    )
    for _, row in slicer_results_df.iterrows():
        segment = Segment(
            vin=str(row["_vin"]),
            start_t_s=float(row["start_time"]),
            end_t_s=float(row["end_time"]),
        )
        critical_ros_time_s = segment.start_t_s
        # Expand the segment to the minimum duration.
        if segment.duration < DEFAULT_MIN_SEGMENT_LENGTH:
            delta_duration_s = DEFAULT_MIN_SEGMENT_LENGTH - segment.duration
            segment.start_t_s -= delta_duration_s / 2.0
            segment.end_t_s += delta_duration_s / 2.0
        # Check for a track ID.
        track_id: int = int(row["track_id"]) if is_track_id_in_results else DEFAULT_TRACK_ID
        output.append(
            TPOLabelingSegmentInfo(
                segment_id=str(segment),
                critical_ros_time=critical_ros_time_s,
                track_id=track_id,
            )
        )
    return output


@click.group(name="run")
def run() -> None:
    """Run slicers using LESS."""
    pass


@run.command(name="slicer")
@click.argument("slicer_name", type=str)
@click.option(
    "--input_ids",
    "-i",
    type=str,
    multiple=True,
    help="The segment IDs/launch IDs/Hydra Run IDs (multiple allowed) to run the slicer on",
)
@click.option(
    "--input_path",
    type=click.Path(exists=True, path_type=Path),
    help="Path to a file with input IDs (segment IDs or launch IDs, one per line)",
)
@click.option(
    "--random_launches",
    is_flag=True,
    default=False,
    help="Whether to use launch_ids randomly autosampled from last 3 months",
)
@click.option(
    "--num_random_launches",
    type=int,
    default=50,
    help="Number of launch_ids randomly autosampled from last 3 months (default 50)",
)
@click.option("--debug", "-d", is_flag=True, help="Interactive terminal for debugging")
@click.option(
    "--rerun_slicer",
    is_flag=True,
    default=False,
    help="Whether to rerun the slicer using the local branch code",
)
@click.option("--webviz", "-w", is_flag=True, help="Display webviz links where possible")
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    help="Optionally output results to file (csv or parquet)",
)
@click.option("--submit_for_tpo", is_flag=True, help="Submit the slicer results for TPO labeling")
@click.option(
    "--max_num_tpo_segments",
    type=int,
    default=DEFAULT_MAX_NUM_TPO_SEGMENTS,
    help="Maxinum number of TPO labels to submit.",
)
@click.option(
    "--max_rows",
    type=int,
    default=50,
    help="Maximum number of rows to print to the terminal (default 50)",
)
def run_slicer(
    slicer_name: str,
    input_ids: Optional[list[str]],
    input_path: Optional[Path],
    random_launches: bool,
    num_random_launches: int,
    debug: bool,
    rerun_slicer: bool,
    webviz: bool,
    output: Optional[Path],
    submit_for_tpo: bool,
    max_num_tpo_segments: int,
    max_rows: int,
) -> None:
    """CLI Command to run a slicer on segments or drives.

    Arguments:\n
    slicer_name
        The slicer to run (e.g. av_in_speed_bump_scene).
    """
    if all([input_ids is None, input_path is None, random_launches is False]):
        logger.exception("Must provide input_ids, input_path or use --random_launches")
        raise ValueError
    else:
        input_ids_by_modality = _parse_inputs(
            input_ids=input_ids,
            input_path=input_path,
            slicer_name=slicer_name,
            random_launches=random_launches,
            num_launches=num_random_launches,
        )

    # Check output path if provided before doing anything.
    if output is not None and output.suffix.lower() not in (".csv", ".parquet"):
        raise ValueError(f"Output path must be csv or parquet, got {output.suffix}")

    results: list[SlicerExecutionResult] = []

    if input_ids_by_modality[SlicerInputModality.ROAD]:
        road_results: list[SlicerExecutionResult] = run_slicer_on_road_data(
            slicer_name=slicer_name,
            input_ids=input_ids_by_modality[SlicerInputModality.ROAD],
            rerun_slicer=rerun_slicer,
            convert_datetimes=True,
        )
        num_successful_executions = sum([e.was_successfully_executed for e in road_results])
        logger.info(
            f"Slicer results generated for {num_successful_executions}/{len(road_results)} road input IDs."
        )
        results.extend(road_results)

    if input_ids_by_modality[SlicerInputModality.SIM]:
        if not rerun_slicer:
            raise NotImplementedError("Slicer must be rerun for sim results! Add --rerun_slicer")
        sim_results: list[SlicerExecutionResult] = run_slicer_on_sim_data(
            slicer_name=slicer_name,
            input_ids=input_ids_by_modality[SlicerInputModality.SIM],
            rerun_slicer=rerun_slicer,
            convert_datetimes=True,
        )
        num_successful_executions = sum([e.was_successfully_executed for e in sim_results])
        logger.info(
            f"Slicer results generated for {num_successful_executions}/{len(sim_results)} sim input IDs."
        )
        results.extend(sim_results)

    for result in results:
        _print_slicer_results(
            result=result, slicer_name=slicer_name, add_webviz_links=webviz, max_rows=max_rows
        )

    populated_result_frames = [e.slicer_output for e in results if not e.slicer_output.empty]
    if populated_result_frames:
        results_df = pd.concat(populated_result_frames)
        results_df["webviz_link"] = results_df.apply(webviz_link_from_row, axis=1)

        if output is not None:
            output_path = Path(output)
            if output_path.suffix.lower() == ".csv":
                results_df.to_csv(output)
            elif output.suffix.lower() == ".parquet":
                results_df.to_parquet(str(output))
            logger.info(f"Wrote output file to {output}")

        if submit_for_tpo:
            segment_infos = _slicer_output_to_tpo_segment_infos(slicer_results_df=results_df)
            if segment_infos:
                if len(segment_infos) > max_num_tpo_segments:
                    logger.info(
                        "Randomly sampling %d segments from %d total",
                        max_num_tpo_segments,
                        len(segment_infos),
                    )
                submit_segments_for_tpo_labeling(
                    segment_infos=segment_infos,
                    prompt_text=slicer_name,
                    event_source=EventSource.SLICER,
                    slicer_name=slicer_name,
                    max_num_segments=max_num_tpo_segments,
                )

    if debug:
        IPython.embed()
