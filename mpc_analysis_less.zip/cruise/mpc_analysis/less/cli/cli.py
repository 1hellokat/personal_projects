"""Command Line Interface for the LESS Project."""

# System imports
import logging

# Third-party imports
import click

# Cruise imports
from cruise.mpc_analysis.less.cli.evaluate import evaluate
from cruise.mpc_analysis.less.cli.register import register
from cruise.mpc_analysis.less.cli.run import run
from cruise.mpc_analysis.less.cli.source import source
from cruise.mpc_analysis.less.cli.submit_labeling_request import submit_labeling_request
from cruise.mpc_analysis.less.cli.view import view

logger = logging.getLogger(__name__)


@click.group(name="cli")
def cli() -> None:
    """LESS CLI entry point."""
    pass


cli.add_command(evaluate)
cli.add_command(register)
cli.add_command(run)
cli.add_command(source)
cli.add_command(submit_labeling_request)
cli.add_command(view)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s][%(levelname)s][%(filename)s:%(lineno)d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        force=True,
    )
    cli()
