"""CLI Command for sourcing events."""

# System imports
import logging
from pathlib import Path
from typing import Optional

# Third-party imports
import click
import IPython
import pandas as pd

# Cruise imports
from cruise.mpc_analysis.less.constants import DEFAULT_MIN_SEGMENT_LENGTH
from cruise.mpc_analysis.less.labels.tpo import (
    EventSource,
    TPOLabelingSegmentInfo,
    submit_segments_for_tpo_labeling,
)
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.sourcing_utils import cola_text_search, format_cola_results
from cruise.mpc_analysis.less.visualization import print_dataframe_in_terminal

logger = logging.getLogger(__name__)


def _cola_results_to_tpo_segment_infos(
    cola_results_df: pd.DataFrame,
) -> list[TPOLabelingSegmentInfo]:
    """Extract the COLA results into TPO segment info structures to submit for labeling."""
    output: list[TPOLabelingSegmentInfo] = []
    if not cola_results_df.empty and "segment_id" not in cola_results_df.columns:
        logger.exception("COLA results dataframe is misssing 'segment_id'!")
        raise ValueError
    if not cola_results_df.empty and "track_id" not in cola_results_df.columns:
        logger.exception("COLA results dataframe is misssing 'track_id'!")
        raise ValueError
    for _, row in cola_results_df.iterrows():
        segment = Segment.from_str(str(row["segment_id"]))
        output.append(
            TPOLabelingSegmentInfo(
                segment_id=str(row["segment_id"]),
                critical_ros_time=segment.start_t_s + (segment.duration / 2.0),
                track_id=int(row["track_id"]),
            )
        )
    return output


@click.group(name="source")
def source() -> None:
    """Source events for usage with LESS (e.g. find example events)."""
    pass


@source.command(name="cola")
@click.argument("prompt", type=str)
@click.option("--camera", "-c", type=str, help="Filter for camera keyword (front, rear, etc.)")
@click.option("--before_date", type=str, help="Filter results before date (YYYY-MM-DD)")
@click.option("--after_date", type=str, help="Filter results after date (YYYY-MM-DD)")
@click.option("--max_results", "-m", type=int, default=50, help="Max number of results to return")
@click.option("--output", "-o", type=str, help="Optional output file path (csv or parquet)")
@click.option("--submit_for_tpo", is_flag=True, help="Submit the results for TPO labeling")
@click.option("--debug", "-d", is_flag=True, help="Drop into terminal after done")
def source_from_cola(
    prompt: str,
    camera: Optional[str],
    before_date: Optional[str],
    after_date: Optional[str],
    max_results: int,
    output: Optional[str],
    submit_for_tpo: bool,
    debug: bool,
) -> None:
    """Source events from COLA using a text prompt.

    Args:
        prompt: the text prompt to search COLA
    """
    logger.info(f"Searching COLA for {prompt} - this may take several minutes.")
    results_df = cola_text_search(
        prompt=prompt,
        num_results=max_results,
        camera_keyword=camera,
        results_before_date=before_date,
        results_after_date=after_date,
    )
    if results_df.empty:
        logger.warning("NO RESULTS found for prompt: %s", prompt)
    else:
        results_df = format_cola_results(
            results_df=results_df, segment_duration_s=DEFAULT_MIN_SEGMENT_LENGTH
        )
        if len(results_df) > max_results:
            results_df = results_df.iloc[:max_results]
        print_dataframe_in_terminal(df=results_df, title=f"COLA Results for: {prompt}")  # type: ignore[reportGeneralTypeIssues]

        if output is not None:
            output_path = Path(output)
            if output_path.suffix.lower() == ".csv":
                results_df.to_csv(output)
            elif output_path.suffix.lower() == ".parquet":
                results_df.to_parquet(output)
            else:
                error_msg = f"Expected file extension csv or parquet, got {output_path.suffix}"
                raise ValueError(error_msg)
            logger.info(f"Wrote output file to {output}")

        if submit_for_tpo:
            segment_infos = _cola_results_to_tpo_segment_infos(cola_results_df=results_df)
            submit_segments_for_tpo_labeling(
                segment_infos=segment_infos,
                prompt_text=prompt,
                event_source=EventSource.COLA,
                max_num_segments=max_results,
            )

    if debug:
        IPython.embed()
