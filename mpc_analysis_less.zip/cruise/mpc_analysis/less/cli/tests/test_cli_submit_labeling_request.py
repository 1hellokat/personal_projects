"""Unit tests for the LESS CLI evaluate command."""

# System imports
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final
from unittest import mock

# Third-party imports
import pytest
from click.testing import CliRunner

# Cruise imports
from cruise.mpc_analysis.less.cli.submit_labeling_request import (
    _input_ids_to_tpo_segment_infos,
    scene_labels,
)
from cruise.mpc_analysis.less.constants import HYDRA_RETENTION_TAG
from cruise.mpc_analysis.less.labels.common_utils import Interval

_RANDOM_TIMESTAMP_SECS: Final[int] = 1735700000
_SAMPLE_VIN: Final[str] = "5G21A6P05P0111111"
_SAMPLE_INTERVAL: Final[Interval] = Interval(0.0, 10.0)
_SAMPLE_HYDRA_RUN_ID: Final[str] = "30402914-e047-40ac-9805-bb1cdf2478cc:1"
_SAMPLE_LAUNCH_ID: Final[str] = "21db4e87-b4a1-4c2c-a912-1b2a17d214af"
_SAMPLE_SEGMENT_ID: Final[str] = (
    f"{_SAMPLE_VIN}:{_RANDOM_TIMESTAMP_SECS}:{_RANDOM_TIMESTAMP_SECS + 10}"
)


@dataclass
class DummyResponse:
    ok: bool
    data: dict[str, Any]
    reason: str = ""

    def json(self) -> dict[str, Any]:
        return self.data


def test_input_ids_to_tpo_segment_infos_unprocessed_launches() -> None:
    """Test that constructing TPO segment infos doesn't crash for launches."""
    with pytest.raises(ValueError):
        _input_ids_to_tpo_segment_infos(input_ids=[_SAMPLE_LAUNCH_ID])


@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.get_sim_scenario_bounds_from_sim",
    return_value=_SAMPLE_INTERVAL,
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.publish_sim_scenario_bounds_to_less"
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.extend_retention_for_hydra_runs",
    return_value=DummyResponse(ok=True, data={"error_ids": []}),
)
def test_input_ids_to_tpo_segment_infos_hydra_run_id_success(
    extend_retention_mock: mock.Mock,
    publish_bounds_mock: mock.Mock,
    scenario_bounds_mock: mock.Mock,
) -> None:
    """Test constructing TPO segment infos from hydra run IDs."""
    result = _input_ids_to_tpo_segment_infos(input_ids=[_SAMPLE_HYDRA_RUN_ID])
    assert len(result) == 1
    assert result[0].segment_id == _SAMPLE_HYDRA_RUN_ID
    publish_bounds_mock.assert_called_once()
    scenario_bounds_mock.assert_called_once_with(hydra_run_id=_SAMPLE_HYDRA_RUN_ID)
    extend_retention_mock.assert_called_once_with(
        hydra_run_ids=[_SAMPLE_HYDRA_RUN_ID], retention_tag=HYDRA_RETENTION_TAG
    )


@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.get_sim_scenario_bounds_from_sim",
    return_value=_SAMPLE_INTERVAL,
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.publish_sim_scenario_bounds_to_less"
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.extend_retention_for_hydra_runs",
    return_value=DummyResponse(ok=False, data={}),
)
def test_input_ids_to_tpo_segment_infos_hydra_run_id_failed_retention(
    extend_retention_mock: mock.Mock,
    publish_bounds_mock: mock.Mock,
    scenario_bounds_mock: mock.Mock,
) -> None:
    """Test constructing TPO segment infos from hydra run IDs."""
    with pytest.raises(ValueError):
        result = _input_ids_to_tpo_segment_infos(input_ids=[_SAMPLE_HYDRA_RUN_ID])
    publish_bounds_mock.assert_called_once()
    scenario_bounds_mock.assert_called_once_with(hydra_run_id=_SAMPLE_HYDRA_RUN_ID)
    extend_retention_mock.assert_called_once_with(
        hydra_run_ids=[_SAMPLE_HYDRA_RUN_ID], retention_tag=HYDRA_RETENTION_TAG
    )


@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.get_sim_scenario_bounds_from_sim",
    return_value=_SAMPLE_INTERVAL,
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.publish_sim_scenario_bounds_to_less"
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.extend_retention_for_hydra_runs",
    return_value=DummyResponse(
        ok=True, data={"error_ids": [_SAMPLE_HYDRA_RUN_ID], "retention_errors": "blah"}
    ),
)
def test_input_ids_to_tpo_segment_infos_hydra_run_id_retention_error(
    extend_retention_mock: mock.Mock,
    publish_bounds_mock: mock.Mock,
    scenario_bounds_mock: mock.Mock,
) -> None:
    """Test constructing TPO segment infos from hydra run IDs."""
    with pytest.raises(ValueError):
        result = _input_ids_to_tpo_segment_infos(input_ids=[_SAMPLE_HYDRA_RUN_ID])
    publish_bounds_mock.assert_called_once()
    scenario_bounds_mock.assert_called_once_with(hydra_run_id=_SAMPLE_HYDRA_RUN_ID)
    extend_retention_mock.assert_called_once_with(
        hydra_run_ids=[_SAMPLE_HYDRA_RUN_ID], retention_tag=HYDRA_RETENTION_TAG
    )


def test_input_ids_to_tpo_segment_infos_segment_id() -> None:
    """Test constructing TPO segment infos from hydra run IDs."""
    result = _input_ids_to_tpo_segment_infos(input_ids=[_SAMPLE_SEGMENT_ID])
    assert len(result) == 1
    assert result[0].segment_id == _SAMPLE_SEGMENT_ID


@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.get_sim_scenario_bounds_from_sim",
    return_value=_SAMPLE_INTERVAL,
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.publish_sim_scenario_bounds_to_less"
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.extend_retention_for_hydra_runs",
    return_value=DummyResponse(ok=True, data={"error_ids": []}),
)
def test_input_ids_to_tpo_segment_infos_mixed_ids_success(
    extend_retention_mock: mock.Mock,
    publish_bounds_mock: mock.Mock,
    scenario_bounds_mock: mock.Mock,
) -> None:
    """Test constructing TPO segment infos from hydra run IDs."""
    result = _input_ids_to_tpo_segment_infos(input_ids=[_SAMPLE_SEGMENT_ID, _SAMPLE_HYDRA_RUN_ID])
    assert len(result) == 2
    assert set([e.segment_id for e in result]) == {_SAMPLE_SEGMENT_ID, _SAMPLE_HYDRA_RUN_ID}
    publish_bounds_mock.assert_called_once()
    scenario_bounds_mock.assert_called_once_with(hydra_run_id=_SAMPLE_HYDRA_RUN_ID)
    extend_retention_mock.assert_called_once_with(
        hydra_run_ids=[_SAMPLE_HYDRA_RUN_ID], retention_tag=HYDRA_RETENTION_TAG
    )


def test_submit_scene_labels_request_fake_slicer() -> None:
    """Test for the CLI command to submit a TPO labeling request for scene slicers."""
    runner = CliRunner()
    with tempfile.NamedTemporaryFile(mode="r", delete=True) as tmp_file:
        result = runner.invoke(
            scene_labels, ["--slicer_name", "av_in_unit_test_scene", "-i", tmp_file.name]
        )
        assert result.exit_code == 1
        assert isinstance(result.exception, ValueError)


@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.get_sim_scenario_bounds_from_sim",
    return_value=_SAMPLE_INTERVAL,
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.publish_sim_scenario_bounds_to_less"
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.submit_segments_for_tpo_labeling"
)
@mock.patch(
    "cruise.mpc_analysis.less.cli.submit_labeling_request.extend_retention_for_hydra_runs",
    return_value=DummyResponse(ok=True, data={"error_ids": []}),
)
def test_submit_scene_labels_request_real_slicer(
    extend_retention_mock: mock.Mock,
    submit_segments_mock: mock.Mock,
    publish_bounds_mock: mock.Mock,
    scenario_bounds_mock: mock.Mock,
) -> None:
    """Test for the CLI command to submit a TPO labeling request for scene slicers."""

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as tmp_file:
        tmp_file.write("\n".join([_SAMPLE_SEGMENT_ID, _SAMPLE_HYDRA_RUN_ID]))
        tmp_path = tmp_file.name

    runner = CliRunner()
    try:
        result = runner.invoke(
            scene_labels, ["--slicer_name", "sc_3_av_is_hard_braking_scene", "-i", tmp_path]
        )
    finally:
        Path(tmp_path).unlink()
    assert result.exit_code == 0
    publish_bounds_mock.assert_called_once()
    scenario_bounds_mock.assert_called_once_with(hydra_run_id=_SAMPLE_HYDRA_RUN_ID)
    submit_segments_mock.assert_called_once()
    extend_retention_mock.assert_called_once_with(
        hydra_run_ids=[_SAMPLE_HYDRA_RUN_ID], retention_tag=HYDRA_RETENTION_TAG
    )
