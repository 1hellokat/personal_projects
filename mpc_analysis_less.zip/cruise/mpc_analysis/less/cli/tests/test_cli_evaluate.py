"""Unit tests for the LESS CLI evaluate command."""

# System imports
import uuid
from math import nan
from typing import Final
from unittest import mock

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.lgtm.attribute_store.jupyter_notebooks.nbutils.bq_utils import LaunchKey
from cruise.mpc_analysis.less.cli.evaluate import (
    remove_unexecuted_labels,
    run_scene_precision_recall,
)
from cruise.mpc_analysis.less.labels.common_utils import Interval
from cruise.mpc_analysis.less.slicer_utils import SlicerExecutionResult

_RANDOM_TIMESTAMP_SECS: Final[int] = 1735700000

_SEGMENT_IDS: Final[list[str]] = [
    f"5G21A6P05P0111111:{_RANDOM_TIMESTAMP_SECS}:{_RANDOM_TIMESTAMP_SECS + 10}",
    f"5G21A6P05P0111111:{_RANDOM_TIMESTAMP_SECS + 10}:{_RANDOM_TIMESTAMP_SECS + 20}",
    f"5G21A6P05P0111111:{_RANDOM_TIMESTAMP_SECS + 20}:{_RANDOM_TIMESTAMP_SECS + 30}",
]

_HYDRA_RUN_IDS: Final[list[str]] = [
    "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:1",
    "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:2",
    "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:3",
    "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:4",
]

_LAUNCH_KEY: Final[LaunchKey] = LaunchKey(
    vin="5G21A6P05P0111111",
    launch_id="",
    start_date="2025-01-01",
    end_date="2025-01-02",
    is_commercial_logging=False,
    git_branch="",
)


def get_execution_results() -> list[SlicerExecutionResult]:
    return [
        SlicerExecutionResult(
            input_id=_SEGMENT_IDS[i],
            was_successfully_executed=True,
            slicer_output=pd.DataFrame(columns=["start_time", "end_time", "_vin"]),
            launch_key=_LAUNCH_KEY,
        )
        for i in range(len(_SEGMENT_IDS))
    ]


def get_negativel_labels() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "segment_id": segment_id,
                "is_event_in_segment": False,
                "event_start_s": nan,
                "event_end_s": nan,
                "uuid": str(uuid.uuid4()),
            }
            for segment_id in _SEGMENT_IDS
        ]
    )


## Make fixtures for the above but the pure functions allow them to be used in mock returns.
@pytest.fixture
def execution_results_successful_no_output() -> list[SlicerExecutionResult]:
    return get_execution_results()


@pytest.fixture
def labels_negative() -> pd.DataFrame:
    return get_negativel_labels()


@pytest.fixture
def labels_negative_sim() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "segment_id": hydra_run_id,
                "is_event_in_segment": False,
                "event_start_s": nan,
                "event_end_s": nan,
                "uuid": str(uuid.uuid4()),
            }
            for hydra_run_id in _HYDRA_RUN_IDS
        ]
    )


def test_remove_unexecuted_labels_empty_inputs() -> None:
    """Test case where no slicer executions were successful."""
    result = remove_unexecuted_labels(slicer_exec_results=[], labels_df=pd.DataFrame())
    assert result.empty


def test_remove_unexecuted_labels_all_successful(
    execution_results_successful_no_output: list[SlicerExecutionResult],
    labels_negative: pd.DataFrame,
) -> None:
    """Test case where all slicer executions were sucessful."""
    result = remove_unexecuted_labels(
        slicer_exec_results=execution_results_successful_no_output, labels_df=labels_negative
    )
    assert result.equals(labels_negative)


def test_remove_unexecuted_labels_some_not_executed(
    execution_results_successful_no_output: list[SlicerExecutionResult],
    labels_negative: pd.DataFrame,
) -> None:
    """Test case where one slicer execution was not sucessful."""
    exec_results = execution_results_successful_no_output
    exec_results[0].was_successfully_executed = False
    result = remove_unexecuted_labels(
        slicer_exec_results=execution_results_successful_no_output, labels_df=labels_negative
    )
    assert result.equals(labels_negative[1:])


def test_remove_unexecuted_labels_all_not_executed(
    execution_results_successful_no_output: list[SlicerExecutionResult],
    labels_negative: pd.DataFrame,
) -> None:
    """Test case where one slicer execution was not sucessful."""
    exec_results = execution_results_successful_no_output
    for exec_result in exec_results:
        exec_result.was_successfully_executed = False
    result = remove_unexecuted_labels(
        slicer_exec_results=execution_results_successful_no_output, labels_df=labels_negative
    )
    assert result.empty


@mock.patch(
    "cruise.mpc_analysis.less.cli.evaluate.run_slicer_on_road_data",
    return_value=get_execution_results(),
)
def test_run_scene_precision_recall_no_slicer_hits(
    run_slicers_mock: mock.Mock, labels_negative: pd.DataFrame
) -> None:
    """Test case with mocked slicer results and no hits."""
    result = run_scene_precision_recall(
        slicer_name="av_in_unit_test_scene", labels_df=labels_negative, rerun_slicer=True
    )
    assert run_slicers_mock.call_count == 1
    assert result.num_fp == 0
    assert result.num_tp == 0
    assert result.num_tn == len(labels_negative)
    assert result.num_fn == 0


@mock.patch("cruise.mpc_analysis.less.cli.evaluate.run_slicer_on_sim_data")
@mock.patch("cruise.mpc_analysis.less.precision_recall_utils.get_sim_scenario_bounds_from_less")
def test_run_scene_precision_recall_sim_true_negative(
    scenario_bounds_mock: mock.Mock, run_slicers_mock: mock.Mock, labels_negative: pd.DataFrame
) -> None:
    """Test case with 1 negative label and no slicer results (1 true negative)."""
    hydra_run_id = "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:1"
    # Adjust the label to have a hydra run ID.
    labels_negative.loc[0, "segment_id"] = hydra_run_id
    labels_df = labels_negative.iloc[:1]
    slicer_result = SlicerExecutionResult(
        input_id=hydra_run_id,
        was_successfully_executed=True,
        slicer_output=pd.DataFrame(),
    )
    run_slicers_mock.return_value = [slicer_result]
    scenario_bounds_mock.return_value = {hydra_run_id: Interval(0.0, 10.0)}
    result = run_scene_precision_recall(
        slicer_name="av_in_unit_test_scene", labels_df=labels_df, rerun_slicer=True
    )
    assert run_slicers_mock.call_count == 1
    assert scenario_bounds_mock.call_count == 1
    assert result.num_fp == 0
    assert result.num_tp == 0
    assert result.num_tn == 1
    assert result.num_fn == 0


@mock.patch("cruise.mpc_analysis.less.cli.evaluate.run_slicer_on_sim_data")
@mock.patch(
    "cruise.mpc_analysis.less.precision_recall_utils.get_sim_scenario_bounds_from_less",
    return_value={},
)
def test_run_scene_precision_recall_missing_scenario_bounds(
    scenario_bounds_mock: mock.Mock, run_slicers_mock: mock.Mock, labels_negative: pd.DataFrame
) -> None:
    """Test case with mocked slicer results and missing scenario bounds."""
    hydra_run_id = "57b06f51-3b2f-5d51-b2fc-6d1eecffb31c:1"
    # Adjust the label to have a hydra run ID.
    labels_negative.loc[0, "segment_id"] = hydra_run_id
    labels_df = labels_negative.iloc[:1]
    slicer_result = SlicerExecutionResult(
        input_id=hydra_run_id,
        was_successfully_executed=True,
        slicer_output=pd.DataFrame(),
    )
    run_slicers_mock.return_value = [slicer_result]
    # Ensure an error is raised if the scenario bounds are missing.
    with pytest.raises(ValueError):
        run_scene_precision_recall(
            slicer_name="av_in_unit_test_scene", labels_df=labels_df, rerun_slicer=True
        )
    assert run_slicers_mock.call_count == 1
    assert scenario_bounds_mock.call_count == 1


@mock.patch("cruise.mpc_analysis.less.cli.evaluate.run_slicer_on_sim_data")
@mock.patch("cruise.mpc_analysis.less.precision_recall_utils.get_sim_scenario_bounds_from_less")
def test_run_scene_precision_recall_sim_one_of_each(
    scenario_bounds_mock: mock.Mock, run_slicers_mock: mock.Mock, labels_negative_sim: pd.DataFrame
) -> None:
    """Test case with mocked slicer results and no hits."""
    # Make labels 1 & 2 positive labels.
    labels_negative_sim.loc[0, "is_event_in_segment"] = True
    labels_negative_sim.loc[0, "event_start_s"] = 0.0
    labels_negative_sim.loc[0, "event_end_s"] = 10.0
    labels_negative_sim.loc[1, "is_event_in_segment"] = True
    labels_negative_sim.loc[1, "event_start_s"] = 0.0
    labels_negative_sim.loc[1, "event_end_s"] = 10.0

    slicer_results = [
        SlicerExecutionResult(
            input_id=hydra_run_id,
            was_successfully_executed=True,
            slicer_output=pd.DataFrame(columns=["start_time", "end_time", "input_id"]),
        )
        for hydra_run_id in _HYDRA_RUN_IDS
    ]
    # Make the first result a true positive.
    slicer_results[0].slicer_output = pd.DataFrame(
        [{"start_time": 0.0, "end_time": 20.0, "input_id": _HYDRA_RUN_IDS[0]}]
    )
    # Make the third result a false positive.
    slicer_results[2].slicer_output = pd.DataFrame(
        [{"start_time": 0.0, "end_time": 20.0, "input_id": _HYDRA_RUN_IDS[2]}]
    )
    # index 1 should be false negative, index 3 should be a true negative.
    run_slicers_mock.return_value = slicer_results

    scenario_bounds_mock.return_value = {id: Interval(0.0, 10.0) for id in _HYDRA_RUN_IDS}

    # Ensure an error is raised if the scenario bounds are missing.
    pr_result = run_scene_precision_recall(
        slicer_name="av_in_unit_test_scene", labels_df=labels_negative_sim, rerun_slicer=True
    )
    assert run_slicers_mock.call_count == 1
    assert scenario_bounds_mock.call_count == 1
    assert pr_result.num_fp == 1
    assert pr_result.num_tp == 1
    assert pr_result.num_tn == 1
    assert pr_result.num_fn == 1
    assert pr_result.false_negatives == [_HYDRA_RUN_IDS[1]]
    assert pr_result.true_negatives == [_HYDRA_RUN_IDS[3]]
    assert _HYDRA_RUN_IDS[0] in pr_result.true_positives[0]
    assert _HYDRA_RUN_IDS[2] in pr_result.false_positives[0]
