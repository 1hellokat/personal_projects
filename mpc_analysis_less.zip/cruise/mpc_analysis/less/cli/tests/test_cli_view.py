"""Unit tests for the LESS CLI view command."""

# System imports
from unittest import mock

# Third-party imports
from click.testing import CliRunner

# Cruise imports
from cruise.mpc_analysis.less.cli.view import view_scene_labels, view_scene_labelsets


@mock.patch("cruise.mpc_analysis.less.cli.view.LabelSetManager")
def test_view_scene_labelsets(labelset_mgr_mock: mock.Mock) -> None:
    runner = CliRunner()
    runner.invoke(view_scene_labelsets)
    assert labelset_mgr_mock.call_count == 1


def test_view_scene_labels_missing_args() -> None:
    """Test early return."""
    runner = CliRunner()
    runner.invoke(view_scene_labels)


@mock.patch("cruise.mpc_analysis.less.cli.view.LessLabelClient")
@mock.patch("cruise.mpc_analysis.less.cli.view.LabelSetManager")
def test_view_scene_labels(labelset_manager_mock: mock.Mock, label_client_mock: mock.Mock) -> None:
    runner = CliRunner()
    runner.invoke(view_scene_labels, ["--slicer_name", "fake_slicer"])
    assert label_client_mock.call_count == 1
    assert labelset_manager_mock.call_count == 1
