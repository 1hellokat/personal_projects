"""CLI Command for LESS evaluations (scene slicer pr/re, etc.)"""

# System imports
import logging
from typing import Optional

# Third-party imports
import click
import IPython
import pandas as pd

# Cruise imports
from cruise.mpc_analysis.less.labels.client import LessLabelClient
from cruise.mpc_analysis.less.labels.label_schema import SceneSlicerLabel
from cruise.mpc_analysis.less.precision_recall_utils import (
    PrecisionRecallResult,
    compute_precision_recall,
)
from cruise.mpc_analysis.less.slicer_utils import (
    SlicerExecutionResult,
    SlicerInputModality,
    SlicerInputType,
    run_slicer_on_road_data,
    run_slicer_on_sim_data,
    split_input_ids_by_modality,
)
from cruise.mpc_analysis.less.visualization import print_prec_recall_results

logger = logging.getLogger(__name__)


@click.group(name="evaluate")
def evaluate() -> None:
    """Execute LESS evaluations (scene slicer prec/rec, etc.)."""
    pass


def _get_segment_ids(labels_df: pd.DataFrame, only_unique: bool = False) -> list[str]:
    """Helper to extract the segment IDs from labels."""
    if "segment_id" not in labels_df.columns:
        error_msg = f"'segment_id' not found in label DF columns: {','.join(labels_df.columns)}"
        logger.error(error_msg)
        return []
    segment_ids = labels_df["segment_id"]
    return segment_ids.unique().tolist() if only_unique else segment_ids.tolist()


def remove_unexecuted_labels(
    slicer_exec_results: list[SlicerExecutionResult], labels_df: pd.DataFrame
) -> pd.DataFrame:
    """Removes labels for segments that didn't have a successful slicer execution."""
    if labels_df.empty or not slicer_exec_results:
        logger.warning("No labels or slicer exec results to process")
        return pd.DataFrame()
    successful_segment_ids = [
        e.input_id for e in slicer_exec_results if e.was_successfully_executed
    ]
    return labels_df[labels_df["segment_id"].isin(successful_segment_ids)]


def run_scene_precision_recall(
    slicer_name: str, labels_df: pd.DataFrame, rerun_slicer: bool
) -> PrecisionRecallResult:
    """Runs scene slicer precision and recall."""
    all_input_ids = _get_segment_ids(labels_df=labels_df, only_unique=True)

    input_ids_by_modality = split_input_ids_by_modality(input_ids=all_input_ids)
    pr_result_by_modality: dict[SlicerInputModality, Optional[PrecisionRecallResult]] = {
        SlicerInputModality.SIM: None,
        SlicerInputModality.ROAD: None,
    }

    for slicer_input_modality, input_ids in input_ids_by_modality.items():
        if not input_ids:
            continue
        if slicer_input_modality == SlicerInputModality.SIM and not rerun_slicer:
            raise NotImplementedError("Only rerun slicer is supported for sim results!")
        slicer_exec_func = (
            run_slicer_on_road_data
            if slicer_input_modality == SlicerInputModality.ROAD
            else run_slicer_on_sim_data
        )
        slicer_results = slicer_exec_func(
            input_ids=input_ids,
            slicer_name=slicer_name,
            rerun_slicer=rerun_slicer,
            convert_datetimes=True,
        )

        num_inputs_executed = sum([e.was_successfully_executed for e in slicer_results])
        logger.info(
            "Successfully processed %d/%d inputs for mode: %s",
            num_inputs_executed,
            len(input_ids),
            slicer_input_modality.value,
        )

        for failed_result in [e for e in slicer_results if not e.was_successfully_executed]:
            logger.error(
                "Failed to generate slicer output for segment: %s Error message:\n\t%s",
                failed_result.input_id,
                str(failed_result.error_msg),
            )

        mode_labels_df = remove_unexecuted_labels(
            slicer_exec_results=slicer_results, labels_df=labels_df
        )
        slicer_output_frames = [
            e.slicer_output for e in slicer_results if e.was_successfully_executed
        ]
        slicer_output_df = (
            pd.concat(slicer_output_frames, ignore_index=True)
            if slicer_output_frames
            else pd.DataFrame()
        )
        info_msg = (
            f"Slicer produced {len(slicer_output_df)} events from {num_inputs_executed} segments"
        )
        if not slicer_output_df.empty:
            slicer_output_df.duration = slicer_output_df.end_time - slicer_output_df.start_time
            avg_duration = slicer_output_df.duration.mean()
            median_duration = slicer_output_df.duration.median()
            total_duration = slicer_output_df.duration.sum()
            info_msg += f" with avg/median/total duration: {avg_duration:.1f}s/{median_duration:.1f}s/{total_duration:.1f}s"
            logger.info(info_msg)

        slicer_input_type = (
            SlicerInputType.SEGMENT_ID
            if slicer_input_modality == SlicerInputModality.ROAD
            else SlicerInputType.HYDRA_RUN_ID
        )
        pr_result_by_modality[slicer_input_modality] = compute_precision_recall(
            labels_df=mode_labels_df,
            slicer_output_df=slicer_output_df,
            input_type=slicer_input_type,
        )
    maybe_road_result = pr_result_by_modality[SlicerInputModality.ROAD]
    maybe_sim_result = pr_result_by_modality[SlicerInputModality.SIM]
    if maybe_road_result is None and maybe_sim_result is None:
        raise ValueError("No precision/recall results computed!!")
    if maybe_sim_result is not None and maybe_road_result is not None:
        return maybe_sim_result + maybe_road_result
    return maybe_sim_result if maybe_sim_result is not None else maybe_road_result  # type: ignore[reportGeneralTypeIssues]


@evaluate.command(name="scene_pr")
@click.option("--slicer_name", "-s", type=str, required=True, help="(e.g. av_in_speed_bump_scene)")
@click.option(
    "--labelset",
    "-ls",
    type=str,
    multiple=True,
    help="The name of the labelset (this is equivalent to the DF task queue for now)",
)
@click.option(
    "--debug", "-d", is_flag=True, default=False, help="Interactive terminal for debugging"
)
@click.option(
    "--rerun_slicer",
    is_flag=True,
    default=False,
    help="Whether to rerun the slicer using the local branch code",
)
def scene_pr(slicer_name: str, labelset: list[str], debug: bool, rerun_slicer: bool) -> None:
    """CLI Command to run scene slicer precision/recall."""
    label_client = LessLabelClient(schema_type=SceneSlicerLabel)
    if not labelset:
        logger.info(f"No labelset specified, querying all labels for slicer {slicer_name}")
        labels_df = label_client.resolve_labelsets(slicer_name=slicer_name)
    else:
        labels_df = pd.concat(
            [label_client.resolve_labelsets(labelset_name=name) for name in labelset],
            ignore_index=True,
        )
    logger.info("Retrieved %d labels for slicer %s", len(labels_df), slicer_name)

    precision_recall_results = run_scene_precision_recall(
        slicer_name=slicer_name, labels_df=labels_df, rerun_slicer=rerun_slicer
    )

    print_prec_recall_results(pr_result=precision_recall_results, slicer_name=slicer_name)

    if debug:
        IPython.embed()
