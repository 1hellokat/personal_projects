"""CLI Command for LESS for submitting label reqeusts."""

# System imports
import logging
from pathlib import Path

# Third-party imports
import click

# Cruise imports
from cruise.mpc_analysis.less.constants import (
    ABSOLUTE_MAX_NUM_TPO_SEGMENTS,
    DEFAULT_MIN_SEGMENT_LENGTH,
    DEFAULT_TRACK_ID,
    HYDRA_RETENTION_TAG,
    MAX_TPO_SEGMENT_LENGTH_S,
)
from cruise.mpc_analysis.less.labels.common_utils import (
    Interval,
    get_sim_scenario_bounds_from_sim,
    publish_sim_scenario_bounds_to_less,
)
from cruise.mpc_analysis.less.labels.retention import extend_retention_for_hydra_runs
from cruise.mpc_analysis.less.labels.tpo import (
    EventSource,
    TPOLabelingSegmentInfo,
    submit_segments_for_tpo_labeling,
)
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.slicer_utils import (
    SlicerInputModality,
    SlicerInputType,
    determine_input_type,
    determine_slicer_framework,
    split_input_ids_by_modality,
)

logger = logging.getLogger(__name__)


@click.group(name="submit_labeling_request")
def submit_labeling_request() -> None:
    """Submit a TPO labeling request using LESS."""
    pass


def _input_ids_to_tpo_segment_infos(input_ids: list[str]) -> list[TPOLabelingSegmentInfo]:
    """Construct the TPO labeling segment infos."""
    ids_by_modality = split_input_ids_by_modality(input_ids=input_ids)

    tpo_segment_infos: list[TPOLabelingSegmentInfo] = []

    for modality, mode_input_ids in ids_by_modality.items():
        if modality == SlicerInputModality.ROAD:
            for input_id in mode_input_ids:
                if determine_input_type(input_id=input_id) != SlicerInputType.SEGMENT_ID:
                    logger.exception("Unexpected input type (not segment id) for %s", input_id)
                    raise ValueError
                segment = Segment.from_str(input_id)
                # Expand the segment to the minimum duration.
                if segment.duration < DEFAULT_MIN_SEGMENT_LENGTH:
                    delta_duration_s = DEFAULT_MIN_SEGMENT_LENGTH - segment.duration
                    segment.start_t_s -= delta_duration_s / 2.0
                    segment.end_t_s += delta_duration_s / 2.0
                critical_ros_time_s = segment.start_t_s
                tpo_segment_infos.append(
                    TPOLabelingSegmentInfo(
                        segment_id=str(segment),
                        critical_ros_time=critical_ros_time_s,
                        track_id=DEFAULT_TRACK_ID,
                    )
                )
        elif modality == SlicerInputModality.SIM:
            sim_scenario_bounds: dict[str, Interval] = {}
            for input_id in mode_input_ids:
                maybe_scenario_bounds = get_sim_scenario_bounds_from_sim(hydra_run_id=input_id)
                if maybe_scenario_bounds is None:
                    logger.warning(
                        "Could not get scenario bounds from sim (maybe run was TTL'd) for hydra run id %s - skipping...",
                        input_id,
                    )
                    continue
                scenario_length_s = (
                    maybe_scenario_bounds.end_time_s - maybe_scenario_bounds.start_time_s
                )
                if scenario_length_s > MAX_TPO_SEGMENT_LENGTH_S:
                    logger.warning(
                        "Sim scenario %s too long (%.1fs) for TPO labeling",
                        input_id,
                        scenario_length_s,
                    )
                    continue
                sim_scenario_bounds[input_id] = maybe_scenario_bounds
                tpo_segment_infos.append(
                    TPOLabelingSegmentInfo(
                        segment_id=input_id,
                        critical_ros_time=maybe_scenario_bounds.start_time_s,
                        track_id=DEFAULT_TRACK_ID,
                    )
                )
            if sim_scenario_bounds:
                # Record the sim scenario bounds in LESS for later access (when consuming the labels).
                publish_sim_scenario_bounds_to_less(sim_scenario_bounds=sim_scenario_bounds)

                # Update the retention for the hydra run IDs so the artifacts are retained.
                hydra_run_ids = list(sim_scenario_bounds.keys())
                retention_result = extend_retention_for_hydra_runs(
                    hydra_run_ids=hydra_run_ids, retention_tag=HYDRA_RETENTION_TAG
                )
                if not retention_result.ok:
                    raise ValueError(
                        f"Error submitting hydra retention request {retention_result.reason}"
                    )
                retention_result_data = retention_result.json()
                if retention_result_data is None:
                    raise ValueError(
                        f"Could not access retention request response data! {retention_result}"
                    )
                if retention_result_data["error_ids"]:  # type: ignore[reportGeneralTypeIssues]
                    logger.error(
                        "Error attempting to retain hydra run IDs: %s",
                        ", ".join(retention_result_data["error_ids"]),  # type: ignore[reportGeneralTypeIssues]
                    )
                    logger.error(
                        "The following errors were encountered:\n%s",
                        "\n".join(set(retention_result_data["retention_errors"])),  # type: ignore[reportGeneralTypeIssues]
                    )
                    raise ValueError("Error attempting to retain hydra runs")
                logger.info(
                    "Applied metrics-validation retention to %d hydra run IDs", len(hydra_run_ids)
                )

    return tpo_segment_infos


@submit_labeling_request.command(name="scene_labels")
@click.option("--slicer_name", "-s", type=str, required=True, help="The slicer name.")
@click.option(
    "--input_path",
    "-i",
    type=click.Path(exists=True, path_type=Path),
    required=True,
    help="Path to a file with input IDs (segment IDs or hydra run IDs, one per line)",
)
def scene_labels(slicer_name: str, input_path: Path) -> None:
    """Submit a TPO labeling request for a scene slicer."""

    # Ensure slicer name is valid.
    slicer_framework = determine_slicer_framework(slicer_name=slicer_name)
    logger.info("Found %s slicer %s", slicer_framework.value, slicer_name)

    # Read the input path file to get the input IDs.
    with input_path.open("r") as f:
        input_ids = f.read().splitlines()

    input_ids = [id for id in input_ids if id]
    logger.info("Read %d input IDs from %s", len(input_ids), input_path)
    segment_infos = _input_ids_to_tpo_segment_infos(input_ids=input_ids)
    if segment_infos:
        submit_segments_for_tpo_labeling(
            segment_infos=segment_infos,
            prompt_text=slicer_name,
            event_source=EventSource.MANUAL,
            slicer_name=slicer_name,
            max_num_segments=ABSOLUTE_MAX_NUM_TPO_SEGMENTS,
        )
