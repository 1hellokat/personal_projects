"""Visualization library for LESS."""

# System imports
import logging
import re
from typing import Optional, Union

# Third-party imports
import numpy as np
import pandas as pd
from rich.console import Console
from rich.table import Table as RichTable

# Cruise imports
from cruise.mpc_analysis.less.precision_recall_utils import PrecisionRecallResult
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.slicer_utils import (
    VALID_HYDRA_RUN_ID_REGEX,
    SlicerInputType,
    determine_input_type,
)

logger = logging.getLogger(__name__)


def print_dataframe_in_terminal(
    df: pd.DataFrame, title: Optional[str] = None, max_rows: int = 50
) -> None:
    """Print a generic dataframe in the terminal."""
    console = Console()

    table_title = "" if title is None else title
    table = RichTable(title=table_title, show_header=True, header_style="orange_red1")
    for column_name in df.columns:
        table.add_column(column_name)
    # include maximum of max_rows rows in the dataframe to print to the terminal
    df = df.head(max_rows)
    for _, row in df.iterrows():
        row_values = (str(val) for val in row.values)
        table.add_row(*row_values)
    console.print(table)


def print_prec_recall_confusion_matrix(
    pr_result: PrecisionRecallResult,
    slicer_name: str = "",
) -> None:
    """Print the precision/recall confusion matrix"""
    title: str = "Confusion Matrix"
    total = sum([pr_result.num_tn, pr_result.num_fp, pr_result.num_fn, pr_result.num_tp])
    if slicer_name:
        title += f" - {slicer_name}"
    table = RichTable(title=title, show_header=False, show_lines=True)
    table.add_column("", justify="center")
    table.add_column("", justify="center")
    table.add_column("", justify="center")
    table.add_column("", justify="center")
    table.add_row(
        f"N  = {total}",
        "[bold orange_red1]Slicer reported event: NO[/bold orange_red1]",
        "[bold orange_red1]Slicer reported event: YES[/bold orange_red1]",
        "",
    )
    table.add_row(
        "[bold orange_red1]Labeled Event: NO[/bold orange_red1]",
        f"TN = {pr_result.num_tn}",
        f"FP = {pr_result.num_fp}",
        f"{pr_result.num_tn + pr_result.num_fp}",
    )
    table.add_row(
        "[bold orange_red1]Labeled Event: YES[/bold orange_red1]",
        f"FN = {pr_result.num_fn}",
        f"TP = {pr_result.num_tp}",
        f"{pr_result.num_fn + pr_result.num_tp}",
    )
    table.add_row(
        "",
        f"{pr_result.num_tn + pr_result.num_fn}",
        f"{pr_result.num_fp + pr_result.num_tp}",
        "",
    )
    Console().print(table)


def print_prec_recall_detailed_results(
    pr_result: PrecisionRecallResult,
    slicer_name: str = "",
    max_rows: int = 50,
) -> None:
    """Print the precision/recall detailed results."""
    title: str = (
        f"Precision/Recall Entries (max {max_rows} rows)"
        if max_rows is not None
        else "Precision/Recall Entries"
    )
    if slicer_name:
        title += f" - {slicer_name}"
    pr_entries: dict[str, Union[str, list[str]]] = {
        "Precision": f"{pr_result.precision:.2f}",
        "Recall": f"{pr_result.recall:.2f}",
    }
    if pr_result.true_negatives:
        pr_entries["True Negatives"] = pr_result.true_negatives
    if pr_result.false_positives:
        pr_entries["False Positives"] = pr_result.false_positives
    if pr_result.false_negatives:
        pr_entries["False Negatives"] = pr_result.false_negatives
    if pr_result.true_positives:
        pr_entries["True Positives"] = pr_result.true_positives

    pr_entries_df = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in pr_entries.items()]))
    print_dataframe_in_terminal(df=pr_entries_df.replace(np.nan, ""), title=title)


def webviz_link_for_input_id(input_id: str) -> str:
    """Create a webviz link from input id."""
    input_type = determine_input_type(input_id=input_id)
    if input_type == SlicerInputType.HYDRA_RUN_ID:
        return f"https://webviz.robot.car/?hydra-run-id={input_id}"
    if input_type == SlicerInputType.SEGMENT_ID:
        return Segment.from_str(segment_id=input_id).webviz_link()
    if input_type == SlicerInputType.HYDRA_RUN_ID_WITH_TIMES:
        result = re.compile(VALID_HYDRA_RUN_ID_REGEX[:-1]).match(input_id)
        if result is None:
            # Should never get here.
            logger.exception("Error cannot find hydra run ID in input")
            raise ValueError
        hydra_run_id = input_id[result.start() : result.end()]
        return f"https://webviz.robot.car/?hydra-run-id={hydra_run_id}"
    logger.exception("Unexpected input type %s", input_id)
    raise ValueError


def print_prec_recall_false_results_webviz_links(
    pr_result: PrecisionRecallResult, max_rows: int = 50
) -> None:
    """Print webviz links for false positives and false negatives."""

    if pr_result.false_positives:
        fp_links = {
            "False Positives": list(map(webviz_link_for_input_id, pr_result.false_positives))
        }
        print_dataframe_in_terminal(
            df=pd.DataFrame(fp_links),
            title=f"False Positive Webviz Links (max {max_rows} rows)"
            if max_rows is not None
            else "False Positive Webviz Links",
        )

    if pr_result.false_negatives:
        fn_links = {
            "False Negatives": list(map(webviz_link_for_input_id, pr_result.false_negatives))
        }
        print_dataframe_in_terminal(
            df=pd.DataFrame(fn_links), title=f"False Negative Webviz Links (max {max_rows} rows)"
        )


def print_prec_recall_results(pr_result: PrecisionRecallResult, slicer_name: str = "") -> None:
    """Prints output in a nice table (for the terminal)."""
    print_prec_recall_confusion_matrix(pr_result=pr_result, slicer_name=slicer_name)
    print_prec_recall_detailed_results(pr_result=pr_result, slicer_name=slicer_name)
    print_prec_recall_false_results_webviz_links(pr_result=pr_result)


def webviz_link_from_row(row: pd.Series) -> str:
    """Create a webviz link from a dataframe row."""
    if "vin" in row or "_vin" in row:
        return Segment.from_pandas_row(row).webviz_link()
    if "input_id" in row:
        return webviz_link_for_input_id(input_id=row["input_id"])
    logger.exception("Missing segment_id or input_id in row")
    raise ValueError
