"""Library that the defines the ground truth schema used in LESS.

In addition to the base schema advantages (API defined, type checking), this will allow labels
from different sources to be used together.
"""

# System imports
import json
import logging
import uuid
from dataclasses import dataclass, fields
from enum import Enum, auto
from math import isnan, nan
from typing import Any

# Third-party imports
import pandas as pd

# Cruise imports
from cruise.mpc_analysis.less.base_schema import BaseSchema, extract_field_info
from cruise.mpc_analysis.less.segment import Segment

logger = logging.getLogger(__name__)


class LabelSource(Enum):
    """Stores the various label sources for LESS."""

    DAILYFLOW = auto()
    TPO = auto()


@dataclass
class LabelSchema(BaseSchema):
    """Base class for a labeling schema."""

    uuid: str

    # Label metadata in json format.
    metadata: str

    def is_valid(self) -> bool:
        """Sanity check on the label schema contents."""
        try:
            uuid.UUID(self.uuid)
        except ValueError as e:
            logger.error("Invalid guid %s %s", self.uuid, str(e))
            return False
        try:
            json.loads(self.metadata)
        except json.JSONDecodeError as e:
            logger.error("Invalid json metadata: %s %s", self.metadata, str(e))
            return False
        return True


@dataclass
class SceneSlicerLabel(LabelSchema):
    """Schema for labeling scene slicer output."""

    segment_id: str
    source: LabelSource

    # Whether there is a positive event in this segment.
    is_event_in_segment: bool

    event_start_s: float = nan
    event_end_s: float = nan

    # Optional free form question & response.
    free_form_question: str = ""
    free_form_response: str = ""

    def is_valid(self) -> bool:
        """Sanity check on the label contents."""
        if not super().is_valid():
            return False
        # Verify the segment ID is valid.
        segment = Segment.from_str(self.segment_id)
        if not segment.is_valid():
            logger.error("Invalid segment ID %s for label %s", self.segment_id, self.uuid)
            return False

        # Verify the label start and end times are populated for positive labels.
        if self.is_event_in_segment and (isnan(self.event_start_s) or isnan(self.event_end_s)):
            logger.error(
                "is_event_in_segment is true but start/end event times not set for label %s",
                self.uuid,
            )
            return False

        # Verify the event timestamps for positive labels are within the segment bounds.
        if self.is_event_in_segment and (
            self.event_start_s < segment.start_t_s or self.event_end_s > segment.end_t_s
        ):
            logger.error(
                "Event times (%.2f-%.2f) outside of segment bounds %s for label %s %s",
                self.event_start_s,
                self.event_end_s,
                segment,
                self.uuid,
                self.metadata,
            )
            return False
        return True

    @classmethod
    def from_dict(cls, input: dict[str, Any]) -> "SceneSlicerLabel":
        """
        Create a label entry from a dictionary. This function ensures all of the required fields
        are present in the dictionary and have the correct type. Any fields in the input
        dictionary that don't have a corresponding class attribute will be added in the metadata
        field.
        """
        # Check for all required fields and enforce types.
        missing_required_fields: list[str] = []
        type_error_msgs: list[str] = []
        cls_field_info = extract_field_info(fields(cls))
        for field_name, field_info in cls_field_info.items():
            if field_name == "metadata":
                # Metadata will be added regardless so unnecessary to raise for this.
                continue
            if field_name not in input and not field_info.has_default:
                missing_required_fields.append(field_name)
            elif field_name in input and not isinstance(input[field_name], field_info.field_type):
                type_error_msgs.append(
                    f"{field_name} expected {field_info.field_type}, got {type(input[field_name])}"
                )
        if missing_required_fields:
            logger.exception(
                "Missing required fields for SceneSlicerLabel: %s",
                ",".join(missing_required_fields),
            )
            raise ValueError()
        if type_error_msgs:
            logger.exception("Incorrect type for fields: %s", ", ".join(type_error_msgs))
            raise TypeError

        # Package up all the non-class attributes into the metadata.
        metadata: dict[str, Any] = {
            k: v for k, v in input.items() if k not in cls_field_info and isinstance(k, str)
        }
        if "metadata" in input:
            metadata.update(json.loads(input["metadata"]))

        # Package up all the class attributes.
        attributes = {k: v for k, v in input.items() if k in cls_field_info and k != "metadata"}
        return cls(**attributes, metadata=json.dumps(metadata))

    def to_dataframe(self) -> pd.DataFrame:
        """Overload needed to properly export LabelSource."""
        attr_data = {attr_name: getattr(self, attr_name) for attr_name in self.dtypes()}
        attr_data["source"] = attr_data["source"].name
        dtypes = self.dtypes()
        dtypes["source"] = str
        return pd.DataFrame([attr_data]).astype(dtypes)  # type: ignore[reportGeneralTypeIssues]
