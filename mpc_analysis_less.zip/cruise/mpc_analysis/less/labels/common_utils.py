"""Library for shared LESS label related code."""

# System imports
import logging
from dataclasses import dataclass
from functools import cache
from typing import Any, Mapping, Optional

# Third-party imports
import pandas as pd
from sim_analysis.sim_analysis_runner import SimAnalysisRunner
from sqlglot import expressions as exp

# Cruise imports
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.constants import (
    LESS_BQ_SIM_RESULT_METADATA_TABLE,
    SC3_ANALYZE_TEMPLATE,
)

logger = logging.getLogger(__name__)


@dataclass
class Interval:
    start_time_s: float
    end_time_s: float

    @property
    def duration(self) -> float:
        """Compute the interval duration."""
        return self.end_time_s - self.start_time_s


def get_labelset_registry_info(
    table_name: str, labelset_name: Optional[str] = None
) -> pd.DataFrame:
    """Helper to query the available labelsets from the registry, optionally filtering by name.

    Query is invoked using the LESS project (vs the default project config.)
    """
    query = exp.select("*").from_(exp.Table(this=exp.Identifier(this=table_name)))
    if labelset_name is not None:
        query = query.where(exp.column("labelset_name").eq(labelset_name))
    logger.debug(f"Running query: {query.sql(dialect='bigquery')}")
    bq_client = LessBigQueryClient.init_from_vault()
    return bq_client.run_query_and_get_dataframe(query=query.sql(dialect="bigquery"))


def create_insert_query(
    row_data: list[dict[str, Any]], table_name: str, dialect: str = "bigquery"
) -> str:
    """Helper to construct a SQL insert query from row data."""
    schema = exp.Schema(
        this=exp.Table(this=exp.Identifier(this=table_name, quoted=True)),
        expressions=[exp.Identifier(this=col) for col in row_data[0].keys()],
    )
    value_expressions = [
        exp.Tuple(expressions=[row[col] for col in row.keys()]) for row in row_data
    ]
    query = exp.Insert(
        this=schema,
        expression=exp.Values(expressions=value_expressions),
    )
    return query.sql(dialect=dialect)


def get_sim_scenario_bounds_from_sim(hydra_run_id: str) -> Optional[Interval]:
    """Get the start and end time from a sim scenario execution from the sim infra."""
    runner = SimAnalysisRunner(hydra_run_id=hydra_run_id, analyze_template=SC3_ANALYZE_TEMPLATE)
    metadata = runner.data_loader.analysis_metadata
    if metadata.evaluation_start_time is None or metadata.evaluation_end_time is None:
        return None
    return Interval(
        start_time_s=metadata.evaluation_start_time, end_time_s=metadata.evaluation_end_time
    )


@cache
def get_all_sim_scenario_bounds_from_less() -> dict[str, Interval]:
    query = exp.select("*").from_(
        exp.Table(this=exp.Identifier(this=LESS_BQ_SIM_RESULT_METADATA_TABLE, quoted=True))
    )
    bq_client = LessBigQueryClient.init_from_vault()
    result_df = bq_client.run_query_and_get_dataframe(query=query.sql(dialect="bigquery"))
    output: dict[str, Interval] = {}
    for _, row in result_df.iterrows():
        output[row["hydra_run_id"]] = Interval(
            row["scenario_start_time"], row["scenario_end_time"]
        )
    return output


def get_sim_scenario_bounds_from_less(
    hydra_run_ids: list[str],
) -> Mapping[str, Optional[Interval]]:
    """Get the start and end time from sim scenario executions from the LESS DB."""
    hydra_run_ids_exp = [exp.Literal.string(id) for id in hydra_run_ids]
    in_clause = exp.In(
        this=exp.column(exp.Identifier(this="hydra_run_id")), expressions=hydra_run_ids_exp
    )
    query = (
        exp.select("*")
        .from_(exp.Table(this=exp.Identifier(this=LESS_BQ_SIM_RESULT_METADATA_TABLE, quoted=True)))
        .where(in_clause)
    )
    logger.debug(f"Running query: {query.sql(dialect='bigquery')}")
    bq_client = LessBigQueryClient.init_from_vault()
    result_df = bq_client.run_query_and_get_dataframe(query=query.sql(dialect="bigquery"))
    output: dict[str, Optional[Interval]] = {}
    for hydra_run_id in hydra_run_ids:
        sim_entry = result_df.query(f"hydra_run_id == '{hydra_run_id}'")
        if sim_entry.empty:
            output[hydra_run_id] = None
        else:
            output[hydra_run_id] = Interval(
                start_time_s=sim_entry.iloc[0]["scenario_start_time"],
                end_time_s=sim_entry.iloc[0]["scenario_end_time"],
            )
    return output


def publish_sim_scenario_bounds_to_less(sim_scenario_bounds: dict[str, Interval]) -> None:
    """Helper to publish sim scenario bounds to the LESS database table."""
    if not sim_scenario_bounds:
        logger.warning("No scenario bounds populated to publish")
        return
    row_data = []
    for hydra_run_id, interval in sim_scenario_bounds.items():
        row_data.append(
            {
                "hydra_run_id": exp.Literal.string(hydra_run_id),
                "scenario_start_time": exp.Literal.number(interval.start_time_s),
                "scenario_end_time": exp.Literal.number(interval.end_time_s),
            }
        )
    insert_query = create_insert_query(
        row_data=row_data, table_name=LESS_BQ_SIM_RESULT_METADATA_TABLE
    )
    bq_client = LessBigQueryClient.init_from_vault()
    bq_client.run_query(insert_query)
    logger.info(
        "Published %d rows to the LESS Sim metadata table %s",
        len(sim_scenario_bounds),
        LESS_BQ_SIM_RESULT_METADATA_TABLE,
    )
