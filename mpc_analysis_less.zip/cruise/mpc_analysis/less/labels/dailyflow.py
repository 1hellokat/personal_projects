"""Library for dailyflow related functions. LESS sources labels generated from DailyFlow."""

# System imports
import datetime
import getpass
import json
import logging
from dataclasses import dataclass
from math import nan
from typing import Any, Final, Optional
from uuid import uuid4

# Third-party imports
import pandas as pd
from sqlglot import expressions as exp

# Cruise imports
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.labels.common_utils import (
    create_insert_query,
    get_labelset_registry_info,
)
from cruise.mpc_analysis.less.labels.label_schema import LabelSource, SceneSlicerLabel
from cruise.mpc_analysis.less.segment import Segment
from cruise.simulation.scenariokit.scenariokit.connectors.dailyflow import (
    DailyFlow,
    DFTaskQueueAccess,
)

logger = logging.getLogger(__name__)

_LESS_PROJECT_ID: Final[str] = "ca-mp-n-c-analysis-dev-rzqr"
_LESS_DAILYFLOW_REGISTRY_TABLE: Final[str] = f"{_LESS_PROJECT_ID}.less.labelset_dailyflow_registry"
_DAILYFLOW_PROJECT_ID: Final[str] = "ca-dailyflow-prd-s1ba"
_DAILYFLOW_LABELS_TABLE: Final[str] = f"{_DAILYFLOW_PROJECT_ID}.dailyflow.task_queue_data_v1"
# If you need to change these, new ones can be looked up using the query `taskQueue` in the
# DailyFlow graphQL API web interface.
_DAILYFLOW_SLICER_LABELING_PROJECT_ID: Final[int] = 316
_DAILYFLOW_SLICER_LABELING_SETTING_ID: Final[int] = 3028


@dataclass
class DFLabelsetRegistry:
    labelset_name: str
    slicer_name: str
    task_queue_id: int
    created_by_user: str
    created_timestamp: datetime.datetime

    def get_insert_query(self, table_name: str, dialect: str = "bigquery") -> str:
        """Constructs an insertion SQL query for the contents of this structure."""
        timestamp_utc = self.created_timestamp.astimezone(datetime.timezone.utc)
        row = {
            "labelset_name": exp.Literal.string(self.labelset_name),
            "slicer_name": exp.Literal.string(self.slicer_name),
            "task_queue_id": exp.Literal.number(self.task_queue_id),
            "created_by_user": exp.Literal.string(self.created_by_user),
            "created_timestamp": exp.func(
                "TIMESTAMP", exp.Literal.string(timestamp_utc.strftime("%Y-%m-%d %H:%M:%S"))
            ),
        }
        return create_insert_query(row_data=[row], table_name=table_name, dialect=dialect)


def _is_valid_raw_dailyflow_label(row: pd.Series, verbose: bool = True) -> bool:
    """Determines whether a dailyflow label is valid or not and optionally logs messages."""
    # Raise an exception if we have no labeled data column (should never happen).
    if "labeled_data" not in row.index:
        logger.exception(
            "Expected 'labeled_data' in labels dataframe. Available columns: %s",
            ",".join(row.index),
        )
        raise ValueError()

    # Verify all of these fields are present.
    required_fields = {
        "metadata",
        "task_id",
        "segment_id",
        "task_queue_id",
        "road_event_id",
    }
    missing_fields = required_fields.difference(set(row.index))
    task_id = str(row["task_id"]) if "task_id" in row.index else "<no task id>"
    if missing_fields:
        if verbose:
            logger.error(
                "Missing fields {%s} for label task id: {%s}", ", ".join(missing_fields), task_id
            )
        return False

    # Type checks for labeled_data and metadata (should always be strings).
    if not isinstance(row["labeled_data"], str) or not isinstance(row["metadata"], str):
        logger.exception(
            "Incorrect type from dailyflow 'labeled_data' or 'metadata' label task id: {%s}",
            task_id,
        )
        raise TypeError()

    # Ensure the segment ID is valid.
    if not Segment.from_str(str(row["segment_id"])).is_valid():
        if verbose:
            logger.error("Invalid segment %s for label task id {%s}", row["segment_id"], task_id)
        return False

    # Ensure the labeled data json blob has all the necessary fields.
    labeled_data_unpacked = json.loads(str(row["labeled_data"]))
    required_label_fields = {"eventInSegment", "additionalEvents"}
    missing_fields = required_label_fields.difference(set(labeled_data_unpacked.keys()))
    if missing_fields:
        if verbose:
            logger.error(
                "Missing labeled data fields %s with task id: {%s}",
                ", ".join(missing_fields),
                task_id,
            )
        return False

    # Ensure the DF entry uuid is present in the metadata json blob.
    if "uuid" not in json.loads(str(row["metadata"])):
        if verbose:
            logger.error("'uuid' not present in label metadata with task id: {%s}", task_id)
        return False
    return True


def _unpack_dailyflow_scene_quality_labels(raw_labels_df: pd.DataFrame) -> list[SceneSlicerLabel]:
    """Unpacks the raw dailyflow scene quality entries into usable labels."""
    output_labels: list[SceneSlicerLabel] = []
    for _i, row in raw_labels_df.iterrows():
        if not _is_valid_raw_dailyflow_label(row):
            continue
        # Labeled data is json encoded in a column in the dailyflow table.
        labeled_data_unpacked = json.loads(str(row["labeled_data"]))
        metadata_unpacked = json.loads(str(row["metadata"]))

        if labeled_data_unpacked["eventInSegment"].lower() not in ("yes", "no"):
            logger.warning("Discarding 'can't tell' label for segment %s.", row["segment_id"])
            continue

        # Exrtact the fields of interested from the dailyflow table to output.
        row_fields_to_copy = ["task_queue_id", "road_event_id", "segment_id", "task_id"]
        cur_output_row: dict[str, Any] = {key: row[key] for key in row_fields_to_copy}
        cur_output_row["source"] = LabelSource.DAILYFLOW
        cur_output_row["uuid"] = metadata_unpacked["uuid"]

        # Get the event start/end times.
        is_event_in_segment = labeled_data_unpacked["eventInSegment"].lower() == "yes"
        event_start_s = float(labeled_data_unpacked["startTime"]) if is_event_in_segment else nan
        event_end_s = float(labeled_data_unpacked["endTime"]) if is_event_in_segment else nan
        cur_output_row.update(
            {
                "is_event_in_segment": is_event_in_segment,
                "event_start_s": event_start_s,
                "event_end_s": event_end_s,
            }
        )
        label_entry = SceneSlicerLabel.from_dict(cur_output_row)
        if not label_entry.is_valid():
            continue

        output_labels.append(label_entry)
        if labeled_data_unpacked["additionalEvents"].lower() == "yes":
            for event_times in labeled_data_unpacked["additionalEventTimes"]:
                # Label has a second event that should be added as a separate row.
                additional_output_row = cur_output_row.copy()
                additional_output_row["event_start_s"] = float(event_times["startTimeAdditional"])
                additional_output_row["event_end_s"] = float(event_times["endTimeAdditional"])
                # TODO (ENG-126946): define a more rigid schema, this generates new guids each time.
                additional_output_row["uuid"] = str(uuid4())
                label_entry = SceneSlicerLabel.from_dict(additional_output_row)
                if not label_entry.is_valid():
                    continue
                output_labels.append(label_entry)

    return output_labels


def _get_dailyflow_raw_labels(task_queue_ids: list[int]) -> pd.DataFrame:
    """Query the raw dailyflow labels."""
    in_clause = f"({', '.join([str(id) for id in task_queue_ids])})"
    query = f"""
    SELECT 
      *
    FROM `{_DAILYFLOW_LABELS_TABLE}` 
    WHERE (task_queue_id IN {in_clause}) AND (status = 'DONE') 
    QUALIFY ROW_NUMBER() OVER (PARTITION BY task_queue_id, task_id ORDER BY ingested_at DESC) = 1
    """
    bq_client = LessBigQueryClient.init_from_vault()
    return bq_client.run_query_and_get_dataframe(query=query)


def create_dailyflow_labelset(
    labelset_name: str, slicer_name: str, existing_task_queue_id: Optional[int] = None
) -> None:
    """Creates a dailyflow-based labelset in the LESS registry."""
    if existing_task_queue_id is None:
        # Need to create the task queue.
        dailyflow_connector = DailyFlow()
        task_queue_id = dailyflow_connector.create_task_queue(
            task_queue_name=labelset_name,
            access=DFTaskQueueAccess.GLOBAL,
            project_id=_DAILYFLOW_SLICER_LABELING_PROJECT_ID,
            project_setting_id=_DAILYFLOW_SLICER_LABELING_SETTING_ID,
        )
        task_queue_link = f"https://dailyflow.robot.car/taskQueue/{task_queue_id}"
        logger.info(f"Created new task queue: {labelset_name} @ {task_queue_link}")
    else:
        task_queue_id = existing_task_queue_id
    entry = DFLabelsetRegistry(
        labelset_name=labelset_name,
        slicer_name=slicer_name,
        task_queue_id=task_queue_id,
        created_by_user=getpass.getuser(),
        created_timestamp=datetime.datetime.now(),
    )
    insert_query = entry.get_insert_query(table_name=_LESS_DAILYFLOW_REGISTRY_TABLE)
    logger.debug(f"Insert query: {insert_query}")
    # This query doesn't actually generate any output but this function is used for convenience.
    bq_client = LessBigQueryClient.init_from_vault()
    bq_client.run_query(query=insert_query)
    logger.info(f"Successfully registered labelset {labelset_name} for slicer {slicer_name}")


def get_dailyflow_labelset_registry_info(labelset_name: Optional[str] = None) -> pd.DataFrame:
    """Query the dailyflow-based labelsets in the LESS registry, optionally filtering by name."""
    return get_labelset_registry_info(
        table_name=_LESS_DAILYFLOW_REGISTRY_TABLE, labelset_name=labelset_name
    )


def get_dailyflow_labels(
    schema_type: type, task_queue_ids: Optional[list[int]] = None
) -> pd.DataFrame:
    """Primary function to query DailyFlow labels. This function will:
        1. Query for all LESS registered datasets (task queue IDs)
        2. Query all of the raw labels for these datasets
        3. Process all of the raw labels into the specified Label Schema.

    Parameters
    ----------
    schema_type
        The LabelSchema type that specifies the schema type.
    task_queue_ids
        Optionally filter on some specified task queue ids.

    Returns
    -------
    pd.DataFrame
        A dataframe of the unpacked labels
    """
    if schema_type != SceneSlicerLabel:
        logger.exception("Only SceneSlicerLabel schema is currently supported!")
        raise NotImplementedError()

    # Get all LESS registered task queue IDs if not provided.
    if task_queue_ids is None:
        registry_info = get_dailyflow_labelset_registry_info()
        if registry_info.empty:
            logger.warning("No DailyFlow labels found for schema type {%s} !!", str(type))
            return pd.DataFrame(columns=list(schema_type.__annotations__.keys()))
        task_queue_ids = registry_info["task_queue_id"].to_list()

    # Query raw labels.
    raw_labels_df = _get_dailyflow_raw_labels(task_queue_ids=task_queue_ids)

    # Push raw labels through schema structure (does type checking and validation).
    label_entries = _unpack_dailyflow_scene_quality_labels(raw_labels_df=raw_labels_df)
    if not label_entries:
        return pd.DataFrame(columns=list(schema_type.__annotations__.keys()))

    return pd.concat([entry.to_dataframe() for entry in label_entries])
