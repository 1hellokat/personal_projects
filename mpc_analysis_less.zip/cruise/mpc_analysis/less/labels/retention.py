"""
Library for managing artifact retention for LESS (i.e. sim bags in hydra, etc.).
"""

# System imports
import logging
import subprocess

# Third-party imports
import requests

# Cruise imports
from cruise.mlp.behaviors.common import username_utils
from cruise.mlp.behaviors.common.hydra import HydraAPIError, requests_post_retriable
from cruise.mpc_analysis.less.constants import HYDRA_RETENTION_TAG

logger = logging.getLogger(__name__)


def extend_retention_for_hydra_runs(
    hydra_run_ids: list[str],
    retention_tag: str = HYDRA_RETENTION_TAG,
) -> requests.Response:
    """Extends retention of hydra artifacts for a set of subtask IDs by applying a tag.

    Parameters
    ----------
    hydra_run_ids
        the hydra run IDs with subtask to extend retention on
    retention_tag
        the retention tag to apply.

    Returns
    -------
    requests.Response
        The response from the HydraAPI.
    """

    auth_token_cmd = ["authcli", "app", "get", "hydra-prod", "-out", "stdout"]
    auth_token_result = subprocess.run(auth_token_cmd, capture_output=True, text=True)
    auth_token = auth_token_result.stdout.strip()

    # Check if the token is empty or malformed
    if not auth_token:
        logger.error("Error: Auth token is empty.")
        raise ValueError()

    headers = {
        "Accept-Encoding": "gzip, deflate",
        "Cache-Control": "no-cache",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_token}",
    }

    user_email = username_utils.get_username()

    try:
        return requests_post_retriable(
            "https://hydra.robot.car/api/retain",
            json={
                "retention_ids": hydra_run_ids,
                "retention_type": "subtask",
                "retention_tag": retention_tag,
                "subject": user_email,
            },
            headers=headers,
        )
    except requests.exceptions.HTTPError as e:
        response_text = e.response.text if e.response else None
        raise HydraAPIError(f"Exception:{str(e)} Error Response: '{response_text}'") from e
