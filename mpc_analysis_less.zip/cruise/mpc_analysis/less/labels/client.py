"""Library for interacting with Ground Truth Labels for the LESS Project."""

# System imports
import json
import logging
from dataclasses import dataclass
from enum import Enum
from functools import partial
from typing import Any, Callable

# Third-party imports
import pandas as pd

# Cruise imports
from cruise.mpc_analysis.less.labels.dailyflow import (
    get_dailyflow_labels,
    get_dailyflow_labelset_registry_info,
)
from cruise.mpc_analysis.less.labels.label_schema import BaseSchema, LabelSource, SceneSlicerLabel
from cruise.mpc_analysis.less.labels.tpo import get_tpo_labels, get_tpo_labelset_registry_info

logger = logging.getLogger(__name__)


class ColNames(Enum):
    METADATA = "metadata"
    NUM_SEGMENTS = "num_segments"
    SOURCE = "source"
    TASK_QUEUE_ID = "task_queue_id"
    TPO_REQUEST_ID = "tpo_request_id"
    UUID = "uuid"


@dataclass
class LabelLoader:
    """Contains the recipe for loading labels for a particular LabelSource & Schema"""

    schema_type: type
    source: LabelSource
    loader_func: Callable[[], pd.DataFrame]


_LABEL_LOADERS: list[LabelLoader] = [
    LabelLoader(
        schema_type=SceneSlicerLabel,
        source=LabelSource.DAILYFLOW,
        loader_func=partial(get_dailyflow_labels, schema_type=SceneSlicerLabel),
    ),
    LabelLoader(
        schema_type=SceneSlicerLabel,
        source=LabelSource.TPO,
        loader_func=partial(get_tpo_labels, schema_type=SceneSlicerLabel),
    ),
]


def _add_filter_item(key: str, val: Any) -> str:
    """Helper to construct a filter query item for filtering dataframe contents."""
    out = f"({key}"
    if isinstance(val, str):
        return out + f" == '{val}')"
    elif isinstance(val, int):
        return out + f" == {val})"
    logger.exception("Unsupported query val type: %s for key: %s", type(val), key)
    raise TypeError


class LabelSetManager:
    """Abstraction for dealing with labelsets.

    TODO (ENG-127508): The concept of labelsets is important for LESS but due to various label
    sources and the way they treat labels and collections of labels, a crisp definition of a
    labelset and its life cycle does not currently exist. This will likely need to change at some
    point. In preparation for that, this class can serve as an abstsraction for dealing with
    labelsets and hopefully ease that transition once it takes place.
    """

    def __init__(self) -> None:
        """Constructor - query the labelset information and store it."""
        self._labelset_registry_info = pd.DataFrame()

    def _load_labelset_info(self) -> None:
        """Helper to load and cache the labelset info."""
        labelset_info_frames: list[pd.DataFrame] = []
        tpo_labelset_frame = get_tpo_labelset_registry_info()
        if tpo_labelset_frame.empty:
            logger.error("No TPO labelset registry info data found!")
        else:
            tpo_labelset_frame[ColNames.SOURCE.value] = LabelSource.TPO.name
            labelset_info_frames.append(
                tpo_labelset_frame.astype({ColNames.NUM_SEGMENTS.value: "Int64"})
            )

        dailyflow_labelset_frame = get_dailyflow_labelset_registry_info()
        if dailyflow_labelset_frame.empty:
            logger.error("No DailyFlow labelset registry info data found!")
        else:
            dailyflow_labelset_frame[ColNames.SOURCE.value] = LabelSource.DAILYFLOW.name
            labelset_info_frames.append(
                dailyflow_labelset_frame.astype({ColNames.TASK_QUEUE_ID.value: "Int64"})
            )

        if not labelset_info_frames:
            logger.exception("No labelset info was loaded!!")
            raise ValueError

        # Cache the labelset registry information.
        self._labelset_registry_info: pd.DataFrame = pd.concat(
            labelset_info_frames, ignore_index=True
        )

    def get_labelset_info(self, **kwargs) -> pd.DataFrame:
        """Accessor function for labelset registry info, optionally filtering."""
        if self._labelset_registry_info.empty:
            self._load_labelset_info()
        output = self._labelset_registry_info.copy()
        query: str = " & ".join(
            [_add_filter_item(k, v) for k, v in kwargs.items() if k in output.columns]
        )
        return output.query(query).reset_index(drop=True) if query else output


class LessLabelClient:
    """Pseudo-singleton class to load, cache and serve LESS labels."""

    _instances = {}

    def __new__(cls, *args, **kwargs) -> "LessLabelClient":
        schema_type = kwargs["schema_type"]
        if schema_type not in cls._instances:
            cls._instances[schema_type] = super().__new__(cls)
        return cls._instances[schema_type]

    def __init__(self, *, schema_type: type) -> None:
        """Constructor."""
        if not issubclass(schema_type, BaseSchema):
            logger.exception(
                "schema_type must be a subclass of label_schema.BaseSchema, got %s",
                str(schema_type),
            )
            raise TypeError
        self.schema_type: type = schema_type
        self._labels_df: pd.DataFrame = pd.DataFrame()
        self._label_metadata_df: pd.DataFrame = pd.DataFrame()
        self._labelset_mgr = LabelSetManager()

    def _load_labels(self) -> None:
        """Load the labels into the client and cache them."""
        label_frames = []
        for loader in _LABEL_LOADERS:
            if loader.schema_type != self.schema_type:
                continue
            labels_df = loader.loader_func()
            labels_df[ColNames.SOURCE.value] = loader.source.name
            label_frames.append(labels_df)
        self._labels_df = pd.concat(label_frames, ignore_index=True)

        # Unpack metadata into a separate dataframe.
        def extract_metadata(row: pd.Series) -> pd.Series:
            return pd.Series(
                json.loads(row[ColNames.METADATA.value])
                | {ColNames.UUID.value: row[ColNames.UUID.value]}
            )

        self._label_metadata_df = self._labels_df.apply(extract_metadata, axis=1)

    def resolve_labelsets(self, **kwargs) -> pd.DataFrame:
        """Public function for providing labels associated with labelsets.

        This function contains some logic labelset specific logic that really should be
        agnostic to the label client. Again, this is related to the TBD schema and life cycle
        for labelsets. This function will likely be removed or modified as part of ENG-127508.
        """
        if "labelset_name" in kwargs:
            labelsets_info_df = self._labelset_mgr.get_labelset_info(
                labelset_name=kwargs["labelset_name"]
            )
        elif "slicer_name" in kwargs:
            labelsets_info_df = self._labelset_mgr.get_labelset_info(
                slicer_name=kwargs["slicer_name"]
            )
        elif not kwargs:
            labelsets_info_df = self._labelset_mgr.get_labelset_info()
        else:
            logger.exception(
                "Only 'labelset_name' and 'slicer_name' are currently supported arguments, got %s",
                kwargs,
            )
            raise NotImplementedError
        label_frames: list[pd.DataFrame] = []
        if len(labelsets_info_df) > 1:
            info_msg = f"Processing {len(labelsets_info_df)} labelsets"
            if kwargs:
                info_msg += f" for {kwargs}"
            logger.info(info_msg)
        for _, row in labelsets_info_df.iterrows():
            if row[ColNames.SOURCE.value] == LabelSource.TPO.name:
                label_frames.append(
                    self.get_labels(
                        unpack_metadata=True, tpo_request_id=row[ColNames.TPO_REQUEST_ID.value]
                    ).assign(
                        slicer_name=row["slicer_name"],
                        labelset_name=row["labelset_name"],
                        labelset_purpose=row["labelset_purpose"],
                        labelset_timestamp=row["created_timestamp"],
                    )
                )
                logger.info(
                    "Found %d labels for tpo_request_id %s",
                    len(label_frames[-1]),
                    row[ColNames.TPO_REQUEST_ID.value],
                )
            elif row[ColNames.SOURCE.value] == LabelSource.DAILYFLOW.name:
                label_frames.append(
                    self.get_labels(
                        unpack_metadata=True, task_queue_id=row[ColNames.TASK_QUEUE_ID.value]
                    ).assign(
                        slicer_name=row["slicer_name"],
                        labelset_name=row["labelset_name"],
                        labelset_purpose=row["labelset_purpose"],
                        labelset_timestamp=row["created_timestamp"],
                    )
                )
                logger.info(
                    "Found %d labels for task_queue_id %d",
                    len(label_frames[-1]),
                    row[ColNames.TASK_QUEUE_ID.value],
                )
            else:
                logger.exception("Unknown labelset source %s", row[ColNames.SOURCE.value])
                raise NotImplementedError
        return pd.concat(label_frames, ignore_index=True)

    def get_labels(self, unpack_metadata: bool = False, **kwargs) -> pd.DataFrame:
        """Main accessor for providing labeled data, optionally filtering."""
        if self._labels_df.empty:
            self._load_labels()

        if unpack_metadata:
            output = self._labels_df.merge(
                self._label_metadata_df, how="inner", on=ColNames.UUID.value
            )
        else:
            output = self._labels_df.copy()

        query: str = " & ".join(
            [_add_filter_item(k, v) for k, v in kwargs.items() if k in output.columns]
        )
        return output.query(query).reset_index(drop=True) if query else output
