# System imports
from dataclasses import field

"""Library for TPO related functions. TPO is one of the sources of labels for LESS."""

# System imports
import datetime
import getpass
import logging
import math
import random
from dataclasses import dataclass
from enum import Enum
from typing import Any, Final, Optional
from uuid import uuid4

# Third-party imports
import pandas as pd
from rich.console import Console
from rich.prompt import Prompt
from sqlglot import expressions as exp

# Cruise imports
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.constants import (
    ABSOLUTE_MAX_NUM_TPO_SEGMENTS,
    DEFAULT_MAX_NUM_TPO_SEGMENTS,
    DEFAULT_TRACK_ID,
    MAX_TPO_SEGMENT_LENGTH_S,
)
from cruise.mpc_analysis.less.labels.common_utils import (
    create_insert_query,
    get_all_sim_scenario_bounds_from_less,
    get_labelset_registry_info,
)
from cruise.mpc_analysis.less.labels.label_schema import LabelSource, SceneSlicerLabel
from cruise.mpc_analysis.less.segment import Segment, filter_overlapping_segments
from cruise.mpc_analysis.less.slicer_utils import (
    SlicerInputModality,
    SlicerInputType,
    determine_input_type,
    split_input_ids_by_modality,
)

# TODO(ENG-127493): Move all of these to a separate constants library.
_LESS_PROJECT_ID: Final[str] = "ca-eval-less-dev-mua9"
_GROUND_TRUTH_PROJECT_ID: Final[str] = "cruise-gnd-truth-prod-69fa"
_LESS_TPO_REGISTRY_TABLE: Final[str] = f"{_LESS_PROJECT_ID}.less.labelset_tpo_registry"
## Labeling Request Table [output]
_TPO_LABELING_REQUEST_TABLE: Final[str] = (
    f"{_GROUND_TRUTH_PROJECT_ID}.analytics.search_validation_autoingest_less"
)

## Tables with label data [input]
_TPO_LABELS_TABLE: Final[str] = (
    f"{_GROUND_TRUTH_PROJECT_ID}.analytics.avp_transposed_results_ai_search_imported_unified_miner"
)


logger = logging.getLogger(__name__)


def _get_webviz_link(input_id: str) -> str:
    """Helper to construct a webviz link."""
    input_type = determine_input_type(input_id=input_id)
    if input_type == SlicerInputType.SEGMENT_ID:
        return Segment.from_str(input_id).webviz_link()
    if input_type == SlicerInputType.HYDRA_RUN_ID:
        return f"https://webviz.robot.car/?hydra-run-id={input_id}"
    logger.exception("Unsupported input type %s for id %s", input_type, input_id)
    raise ValueError


def _get_vin(input_id: str) -> str:
    """Helper to get the vin for this input id."""
    input_type = determine_input_type(input_id=input_id)
    if input_type == SlicerInputType.SEGMENT_ID:
        return Segment.from_str(input_id).vin
    if input_type == SlicerInputType.HYDRA_RUN_ID:
        return "sim"
    logger.exception("Unsupported input type %s for id %s", input_type, input_id)
    raise ValueError


class EventSource(Enum):
    """Represents the source of events - this will be stored in the LESS registry."""

    # Events that come directly from a raw COLA text or image prompt.
    COLA = "COLA"

    # Events sourced by running the slicer on drives/segments. Note that there are COLA only
    # slicers that produce events from COLA prompts. Even though the events from these slicers are
    # ultimately from COLA, if they are coming from the slicer, they should have this SLICER event
    # source.
    SLICER = "SLICER"

    # Reserved for users manually providing a list of inputs.
    MANUAL = "MANUAL"


class LabelsetPurpose(Enum):
    """Represents the purpose of the labelset - whether it tests precision, recall, or both. Other is for custom purposes (aka not precision or recall)"""

    PRECISION = "PRECISION"
    RECALL = "RECALL"
    BOTH = "BOTH"
    OTHER = "OTHER"


@dataclass
class TPOLabelsetRegistry:
    """Structure for registering a TPO labelset in LESS."""

    labelset_name: str
    slicer_name: str
    tpo_request_id: str
    segment_ids: list[str]
    labeling_instructions: str
    free_form_question: str
    event_source: EventSource
    labelset_purpose: LabelsetPurpose
    created_by_user: str
    created_timestamp: datetime.datetime

    def get_insert_query(self, table_name: str, dialect: str = "bigquery") -> str:
        """Constructs an insertion SQL query for the contents of this structure."""
        timestamp_utc = self.created_timestamp.astimezone(datetime.timezone.utc)
        row = {
            "labelset_name": exp.Literal.string(self.labelset_name),
            "slicer_name": exp.Literal.string(self.slicer_name),
            "tpo_request_id": exp.Literal.string(self.tpo_request_id),
            "created_by_user": exp.Literal.string(self.created_by_user),
            "created_timestamp": exp.func(
                "TIMESTAMP", exp.Literal.string(timestamp_utc.strftime("%Y-%m-%d %H:%M:%S"))
            ),
            "num_segments": exp.Literal.number(len(self.segment_ids)),
            "segment_ids": exp.Array(
                expressions=[exp.Literal.string(s) for s in self.segment_ids]
            ),
            "labeling_instructions": exp.Literal.string(self.labeling_instructions),
            "free_form_question": exp.Literal.string(self.free_form_question),
            "event_source": exp.Literal.string(self.event_source.value),
            "labelset_purpose": exp.Literal.string(self.labelset_purpose.value),
        }
        return create_insert_query(row_data=[row], table_name=table_name, dialect=dialect)


@dataclass
class TPOLabelingSegmentInfo:
    """Structure representing a single event to be labeled by TPO."""

    segment_id: str
    critical_ros_time: float
    track_id: int = DEFAULT_TRACK_ID


@dataclass
class TPOLabelingRequest:
    """Structure for a TPO Labeling Request for a batch of segments."""

    # For COLA sourced segments, this is the prompt used. For slicer sourced segments, this is
    # the slicer name.
    prompt_text: str
    labeling_instructions: str
    segment_infos: list[TPOLabelingSegmentInfo]
    free_form_question: str = ""
    request_id: str = str(uuid4())
    requested_at: datetime.datetime = field(default_factory=datetime.datetime.now)
    requestor: str = getpass.getuser()

    def get_insert_query(self, table_name: str, dialect: str = "bigquery") -> str:
        """Constructs an insertion SQL query for the contents of this structure.

        The schema for this query is based on the TPO autoingest table.
        """
        row_data: list[dict[str, Any]] = []
        requested_at_utc_str = self.requested_at.astimezone(datetime.timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        for segment_info in self.segment_infos:
            webviz_link = _get_webviz_link(segment_info.segment_id)
            vin = _get_vin(segment_info.segment_id)
            row_data.append(
                {
                    "link_id": exp.Literal.string(segment_info.segment_id),
                    "link": exp.Literal.string(webviz_link),
                    "request_id": exp.Literal.string(self.request_id),
                    "requestor": exp.Literal.string(self.requestor),
                    "requested_at": exp.func(
                        "TIMESTAMP", exp.Literal.string(requested_at_utc_str)
                    ),
                    "result_id": exp.Literal.string(str(uuid4())),
                    "vin": exp.Literal.string(vin),
                    "critical_ros_time": exp.Literal.number(segment_info.critical_ros_time),
                    "track_id": exp.Literal.number(segment_info.track_id),
                    "prompt_text": exp.Literal.string(self.prompt_text),
                    "labeling_instructions": exp.Literal.string(self.labeling_instructions),
                    "free_form_question": exp.Literal.string(self.free_form_question),
                }
            )
        return create_insert_query(row_data=row_data, table_name=table_name, dialect=dialect)


def create_tpo_labelset(
    *,
    labelset_name: str,
    slicer_name: str,
    tpo_request_id: str,
    segment_ids: list[str],
    labeling_instructions: str,
    event_source: EventSource,
    labelset_purpose: LabelsetPurpose,
    free_form_question: str,
) -> None:
    """Creates a TPO-based labelset entry in the LESS registry."""
    entry = TPOLabelsetRegistry(
        labelset_name=labelset_name,
        slicer_name=slicer_name,
        tpo_request_id=tpo_request_id,
        segment_ids=segment_ids,
        labeling_instructions=labeling_instructions,
        free_form_question=free_form_question,
        event_source=event_source,
        labelset_purpose=labelset_purpose,
        created_by_user=getpass.getuser(),
        created_timestamp=datetime.datetime.now(),
    )
    insert_query = entry.get_insert_query(table_name=_LESS_TPO_REGISTRY_TABLE)
    logger.debug(f"Insert query: {insert_query}")
    bq_client = LessBigQueryClient.init_from_vault()
    bq_client.run_query(query=insert_query)
    logger.info(f"Successfully registered labelset {labelset_name} for slicer {slicer_name}")


def submit_tpo_labeling_request(tpo_request: TPOLabelingRequest) -> None:
    """Submits a TPO Labeling Request by appending to a table."""
    insert_query = tpo_request.get_insert_query(table_name=_TPO_LABELING_REQUEST_TABLE)
    logger.debug(f"Insert query:\n{insert_query}")
    bq_client = LessBigQueryClient.init_from_vault()
    bq_client.run_query(query=insert_query)
    logger.info(
        "Successfully submitted TPO Labeling Request id: %s with %d segments",
        tpo_request.request_id,
        len(tpo_request.segment_infos),
    )


def get_tpo_labelset_registry_info(labelset_name: Optional[str] = None) -> pd.DataFrame:
    """Query the TPO-based labelsets in the LESS registry, optionally filtering by name."""
    return get_labelset_registry_info(
        table_name=_LESS_TPO_REGISTRY_TABLE, labelset_name=labelset_name
    )


def _is_valid_raw_tpo_label(row: pd.Series, verbose: bool = True) -> bool:
    """Determines whether a raw TPO label is valid or not and optionally logs messages."""
    # Check for missing fields that are required.
    required_fields = {
        "link_id",
        "a_scene_validation",
        "md_result_id",
        "md_request_id",
    }
    missing_fields = required_fields.difference(set(row.index))
    label_id = str(row["md_result_id"]) if "md_result_id" in row.index else "<no label id>"
    if missing_fields:
        if verbose:
            logger.error(
                "Missing fields {%s} for label task id: {%s}", ", ".join(missing_fields), label_id
            )
        return False
    # Check for answers that are not yes or no to the scene validation.
    return row["a_scene_validation"].lower() in ("yes", "no")


def _unpack_tpo_scene_quality_row(row: pd.Series) -> SceneSlicerLabel:
    """Convert a single row into a labeled entry."""
    is_event_in_segment = row["a_scene_validation"].lower() == "yes"
    input_id = str(row["link_id"])
    input_type = determine_input_type(input_id)
    if not is_event_in_segment:
        event_start_s = math.nan
        event_end_s = math.nan
    elif input_type == SlicerInputType.SEGMENT_ID:
        # TODO(jpilarczyk): get the precise corrected event times if present.
        segment = Segment.from_str(input_id)
        event_start_s = segment.start_t_s
        event_end_s = segment.end_t_s
    elif input_type == SlicerInputType.HYDRA_RUN_ID:
        scenario_bounds = get_all_sim_scenario_bounds_from_less()
        if input_id not in scenario_bounds:
            logger.exception("Scenario bounds not found for positive sim label %s", input_id)
            raise ValueError
        event_start_s = scenario_bounds[input_id].start_time_s
        event_end_s = scenario_bounds[input_id].end_time_s
    else:
        logger.exception("Unsupported slicer input type for label %s", input_type)
        raise ValueError
    label_dict = {
        "is_event_in_segment": is_event_in_segment,
        "event_start_s": event_start_s,
        "event_end_s": event_end_s,
        "source": LabelSource.TPO,
        "uuid": row["md_result_id"],
        "segment_id": input_id,
        "tpo_request_id": row["md_request_id"],
        "free_form_question": (
            row["md_free_form_question"] if row["md_free_form_question"] is not None else ""
        ),
        "free_form_response": (
            row["a_free_form_question"] if row["a_free_form_question"] is not None else ""
        ),
    }
    return SceneSlicerLabel.from_dict(label_dict)


def _unpack_tpo_scene_quality_labels(raw_labels_df: pd.DataFrame) -> list[SceneSlicerLabel]:
    """Convert the raw scene quality TPO labels into the expected labeling schema."""
    output_labels: list[SceneSlicerLabel] = []
    for _, row in raw_labels_df.iterrows():
        if not _is_valid_raw_tpo_label(row):
            continue
        output_labels.append(_unpack_tpo_scene_quality_row(row=row))
    return output_labels


def _get_tpo_raw_labels(tpo_request_ids: list[str]) -> pd.DataFrame:
    """Query the raw TPO labels."""
    request_ids_exp = [exp.Literal.string(id) for id in tpo_request_ids]
    in_clause = exp.In(
        this=exp.column(exp.Identifier(this="md_request_id")), expressions=request_ids_exp
    )
    query = (
        exp.select("*")
        .from_(exp.Table(this=exp.Identifier(this=_TPO_LABELS_TABLE, quoted=True)))
        .where(in_clause)
    )
    bq_client = LessBigQueryClient.init_from_vault()
    return bq_client.run_query_and_get_dataframe(query=query.sql(dialect="bigquery"))


def get_tpo_labels(schema_type: type, tpo_request_ids: Optional[list[str]] = None) -> pd.DataFrame:
    """Primary function to query TPO labels. This function will:
        1. Query for all LESS registered datasets (TPO request IDs)
        2. Query all of the raw labels for these datasets
        3. Process all of the raw labels into the specified Label Schema.

    Parameters
    ----------
    schema_type
        The LabelSchema type that specifies the schema type.
    tpo_request_ids
        Optionally filter on some specified tpo request ids.

    Returns
    -------
    pd.DataFrame
        A dataframe of the unpacked labels
    """
    if schema_type != SceneSlicerLabel:
        logger.exception("Only SceneSlicerLabel schema is currently supported!")
        raise NotImplementedError()

    # Get all LESS registered labelset request IDs if not provided.
    if tpo_request_ids is None:
        registry_info = get_tpo_labelset_registry_info()
        if registry_info.empty:
            logger.warning("No TPO labels found for schema type {%s} !!", str(type))
            return pd.DataFrame(columns=list(schema_type.__annotations__.keys()))
        tpo_request_ids = registry_info["tpo_request_id"].to_list()

    # Query raw labels.
    raw_labels_df = _get_tpo_raw_labels(tpo_request_ids=tpo_request_ids)
    # Push raw labels through schema structure (does type checking and validation).
    label_entries = _unpack_tpo_scene_quality_labels(raw_labels_df=raw_labels_df)
    if not label_entries:
        return pd.DataFrame(columns=list(schema_type.__annotations__.keys()))

    return pd.concat([entry.to_dataframe() for entry in label_entries])


def submit_segments_for_tpo_labeling(
    segment_infos: list[TPOLabelingSegmentInfo],
    prompt_text: str,
    event_source: EventSource,
    slicer_name: Optional[str] = None,
    max_num_segments: int = DEFAULT_MAX_NUM_TPO_SEGMENTS,
) -> None:
    """Submits segments for TPO Labeling."""
    logger.warning("Starting process to submit event for TPO labeling")

    if max_num_segments > ABSOLUTE_MAX_NUM_TPO_SEGMENTS:
        logger.warning("Cannot submit > than %d events, capping.", ABSOLUTE_MAX_NUM_TPO_SEGMENTS)
        max_num_segments = ABSOLUTE_MAX_NUM_TPO_SEGMENTS

    input_ids = [e.segment_id for e in segment_infos]

    input_ids_by_modality = split_input_ids_by_modality(input_ids=input_ids)

    filtered_seg_infos: list[TPOLabelingSegmentInfo] = []

    if input_ids_by_modality[SlicerInputModality.ROAD]:
        # Remove any segments that are too long.
        all_road_segment_ids = input_ids_by_modality[SlicerInputModality.ROAD]
        # if duration is greater the MAX_TPO_SEGMENT_LENGTH_S, sample a random max duration from the segment.
        sampled_segment_ids = []
        for id in all_road_segment_ids:
            segment = Segment.from_str(id)
            if segment.duration < MAX_TPO_SEGMENT_LENGTH_S:
                sampled_segment_ids.append(id)
            else:
                sample_start_s = random.uniform(
                    segment.start_t_s, segment.end_t_s - MAX_TPO_SEGMENT_LENGTH_S
                )
                sample_end_s = sample_start_s + MAX_TPO_SEGMENT_LENGTH_S
                sampled_segment_ids.append(
                    str(Segment(vin=segment.vin, start_t_s=sample_start_s, end_t_s=sample_end_s))
                )
        delta_num_segments = len(all_road_segment_ids) - len(sampled_segment_ids)
        if delta_num_segments > 0:
            logger.info("Removed %d events for duration over limit.", delta_num_segments)

        # Ensure events are not overlapping. Note that this will discard segments that come later in
        # the list if they overlap with segments that appear earlier. Depending on the application,
        # this may result in discarding important segments. Though, for COLA results, they are sorted
        # by prompt/image similarity, so the more relevant matches appear earlier. Regardless, this is
        # a somewhat crude culling so https://jira.robot.car/browse/ENG-127655 was created to track it.
        filtered_segment_ids = set(filter_overlapping_segments(sampled_segment_ids))
        if len(sampled_segment_ids) > len(filtered_segment_ids):
            logger.warning(
                "Discarded %d segments since they overlapped with another segment",
                len(sampled_segment_ids) - len(filtered_segment_ids),
            )
        filtered_seg_infos.extend(
            [e for e in segment_infos if e.segment_id in filtered_segment_ids]
        )

    if input_ids_by_modality[SlicerInputModality.SIM]:
        hydra_run_ids = input_ids_by_modality[SlicerInputModality.SIM]
        # No filtering of sim scenarios needed.
        filtered_seg_infos.extend([e for e in segment_infos if e.segment_id in hydra_run_ids])

    # Query user for label details.
    if slicer_name is None:
        slicer_name = input("Enter the slicer name (e.g. av_in_speed_bump_scene) > ")
    labelset_name = input("Enter a name for this labelset > ")
    labeling_instructions = input("Enter the labeling instructions > ")
    free_form_question = input(
        "[Optional] Enter a free form question for the labelers (enter for none) > "
    )

    # Ask user for labelset purpose
    console = Console()
    labelset_purpose_input = Prompt.ask(
        "What's the labelset purpose? (default: BOTH)",
        choices=[e.value for e in LabelsetPurpose],
        default=LabelsetPurpose.BOTH,
    )
    logger.info("You selected %s", labelset_purpose_input)
    labelset_purpose = LabelsetPurpose(labelset_purpose_input)

    # Submit up to the maximum number of segments.
    if len(filtered_seg_infos) > max_num_segments:
        logger.info(
            f"Selected the first {max_num_segments} segments from {len(filtered_seg_infos)} total"
        )
    seg_infos_to_submit = filtered_seg_infos[:max_num_segments]

    # Confirm with user.
    confirm_result = input(
        f"This will submit {len(seg_infos_to_submit)} segments for TPO Labeling. Do you want to continue(y/n) > "
    )
    if confirm_result.lower() not in ("yes", "y"):
        logger.warning("Aborting TPO labeling request per user: %s", confirm_result)
        return

    # Convert events into TPO labeling requests.
    tpo_request = TPOLabelingRequest(
        prompt_text=prompt_text,
        labeling_instructions=labeling_instructions,
        segment_infos=seg_infos_to_submit,
        free_form_question=free_form_question,
    )
    create_tpo_labelset(
        labelset_name=labelset_name,
        slicer_name=slicer_name,
        tpo_request_id=tpo_request.request_id,
        segment_ids=[e.segment_id for e in tpo_request.segment_infos],
        labeling_instructions=labeling_instructions,
        free_form_question=free_form_question,
        event_source=event_source,
        labelset_purpose=labelset_purpose,
    )
    submit_tpo_labeling_request(tpo_request=tpo_request)
