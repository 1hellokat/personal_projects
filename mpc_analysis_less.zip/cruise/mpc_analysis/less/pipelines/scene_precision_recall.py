"""Roboflow pipeline for computing Scene Slicer Precision/Recall."""

# System imports
import datetime
import logging
import uuid
from typing import Final

# Third-party imports
import click
import pandas as pd

# Cruise imports
from cruise.lgtm2.production_metrics import SIM_REGISTRY
from cruise.lgtm.attribute_store.production_metrics import get_valid_slicer_def_names
from cruise.mlp.projects.roboflow_utils.make import make_list
from cruise.mlp.roboflow2.api import transformer
from cruise.mlp.roboflow2.api_client_external import PipelineSpec
from cruise.mlp.roboflow2.notifications.slack import _send_message as send_slack_message
from cruise.mlp.roboflow2.resource_settings import ResourceSettings
from cruise.mlp.roboflow2.run_context import get_run_id
from cruise.mlp.roboflow2.semantic_pipeline_config import (
    BusinessAttribution,
    RunType,
    SemanticPipelineConfig,
)
from cruise.mlp.roboflow2.try_except import ExceptionHandler, try_except
from cruise.mlp.robotypes.base import List
from cruise.mlp.robotypes.types.boolean import Boolean
from cruise.mlp.robotypes.types.dataframe import DataFrame
from cruise.mlp.robotypes.types.float import Float
from cruise.mlp.robotypes.types.nullable import Nullable
from cruise.mlp.robotypes.types.struct import Struct
from cruise.mlp.robotypes.types.text import Text
from cruise.mlp.robotypes.types.timestamp import Timestamp
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.cli.evaluate import run_scene_precision_recall
from cruise.mpc_analysis.less.constants import (
    LESS_ALERT_SLACK_CHANNEL,
    SCENE_PR_PIPELINE_RESULTS_TABLE,
)
from cruise.mpc_analysis.less.labels.client import LessLabelClient
from cruise.mpc_analysis.less.labels.label_schema import SceneSlicerLabel
from cruise.mpc_analysis.less.labels.tpo import LabelsetPurpose
from cruise.mpc_analysis.less.pipelines.results import (
    PipelineExecutionInfo,
    PipelineMode,
    ScenePrecRecallPipelineResult,
)
from cruise.mpc_analysis.less.pipelines.scene_precision_recall_utils import (
    check_for_regression_and_alert,
    get_centra_link,
    get_slicer_dri_slack_handle,
)
from cruise.mpc_analysis.less.slicer_utils import (
    SlicerExecutionMode,
    SlicerInputModality,
    split_input_ids_by_modality,
)

logger = logging.getLogger(__name__)

# TODO(jpilarczyk): Consider moving to label_schema module
_LABEL_SCHEMA_RF_DATAFRAME_TYPE = DataFrame(
    schema=Struct(
        uuid=Text,
        metadata=Nullable[Text],
        segment_id=Text,
        source=Text,
        is_event_in_segment=Boolean,
        event_start_s=Nullable[Float],
        event_end_s=Nullable[Float],
    ),
    index_schema=(None),
)

_LABEL_SCHEMA_COLUMNS: Final[list[str]] = list(SceneSlicerLabel.dtypes().keys())

_SEMANTIC_PIPELINE_CONFIG = SemanticPipelineConfig(
    workspace="RoboFlow",
    project="LESS",
    run_type=RunType.DEVELOPMENT,
    business_attribution=BusinessAttribution.EVAL_LESS,
    pipeline_name="less_scene_prec_recall",
    pipeline_owner="joseph.pilarczyk@getcruise.com",
)
_PREC_RECALL_MEM_SIZE_GB: Final[float] = 30.0
_PREC_RECALL_STORAGE_SIZE_GB: Final[float] = 50.0


@transformer
def handle_scene_prec_exception(
    slicer_name: Text,
    labelset_name: Text,
    slicer_execution_mode: Text,
    evaluation_uuid: Text,
    pipeline_mode: Text,
) -> Boolean:
    """Handler for an exception during the scene/precision recall transformer."""
    if PipelineMode(pipeline_mode) == PipelineMode.DEVELOP_SCHEDULED:
        # Send a slack message for the scheduled pipeline executions on develop.
        message = f":redalert: Slicer `{slicer_name}` labelset: `{labelset_name}` FAILED during prec/recall evaluation - mode: *{slicer_execution_mode}* :redalert:"
        message += f"\n{get_centra_link(roboflow_run_id=evaluation_uuid)}"
        slicer_dri = get_slicer_dri_slack_handle(slicer_name=slicer_name)
        if slicer_dri is not None:
            message += f" {slicer_dri}"
        send_slack_message(channel=LESS_ALERT_SLACK_CHANNEL, text=message)
    return False


@transformer(
    resource_settings=ResourceSettings(
        memory_in_gb=_PREC_RECALL_MEM_SIZE_GB, disk_in_gb=_PREC_RECALL_STORAGE_SIZE_GB
    )
)
def scene_prec_recall(
    slicer_name: Text,
    labels_df: _LABEL_SCHEMA_RF_DATAFRAME_TYPE,  # type: ignore[reportGeneralTypeIssues]
    labelset_name: str,
    labelset_purpose: LabelsetPurpose,
    labelset_timestamp: Timestamp,
    slicer_execution_mode: str,
    evaluation_uuid: Text,
    evaluation_timestamp: Timestamp,
    pipeline_mode: Text,
    slicer_input_modality: SlicerInputModality,
) -> Boolean:
    """Transformer for computing precision recall on a single scene slicer.

    Parameters
    ----------
    slicer_name
        The name of the slicer to run (e.g. 'av_in_driveable_area_scene')
    labels_df
        The labels for this scene slicer
    labelset_name
        The labelset used for this Re/Pr run
    labelset_purpose
        The purpose of the labelset (PRECISION, RECALL, BOTH)
    labelset_timestamp
        The timestamp of the labelset
    slicer_execution_mode
        The mode of execution for this slicer (RERUN_SLICER, QUERY_EXISTING, etc.)
    evaluation_uuid
        The pipeline uuid (same as the roboflow run ID)
    evaluation_timestamp
        Timestamp this evaluation started
    pipeline_mode
        The mode in which this pipeline was triggered (manual_dev, develop_scheduled, etc.)
    slicer_input_modality
        The modality of the slicer input (ROAD, SIM)
    Returns
    -------
    True or throws an exception (the try_except transformer handler will return False if so).
    """
    logger.info(
        "Scene slicer precision recall transformer for slicer %s and labelset %s with %d labels",
        slicer_name,
        labelset_name,
        len(labels_df),
    )

    # Initialize singleton with local creds when running in roboflow.
    bq_client = LessBigQueryClient.init_from_default_creds()

    if SlicerExecutionMode(slicer_execution_mode) not in (
        SlicerExecutionMode.QUERY_EXISTING,
        SlicerExecutionMode.RERUN_SLICER,
    ):
        logger.exception("Unsupported slicer execution mode: %s", slicer_execution_mode)
        raise NotImplementedError

    rerun_slicer = SlicerExecutionMode(slicer_execution_mode) == SlicerExecutionMode.RERUN_SLICER
    pr_result = run_scene_precision_recall(
        slicer_name=slicer_name, labels_df=labels_df, rerun_slicer=rerun_slicer
    )
    logger.info(
        "Slicer: %s Labelset: %s Precision: %.2f Recall: %.2f",
        slicer_name,
        labelset_name,
        pr_result.precision,
        pr_result.recall,
    )

    if PipelineMode(pipeline_mode) == PipelineMode.DEVELOP_SCHEDULED:
        logger.info("Checking for regressions from previous results")
        check_for_regression_and_alert(
            cur_pr_result=pr_result,
            slicer_name=str(slicer_name),
            labelset_name=labelset_name,
            slicer_execution_mode=SlicerExecutionMode(slicer_execution_mode),
            evaluation_uuid=str(evaluation_uuid),
        )

    logger.info("Writing results to bigquery")
    pipeline_exec_info = PipelineExecutionInfo(
        uuid=evaluation_uuid,
        timestamp=pd.Timestamp(evaluation_timestamp.timestamp(), unit="s", tz="utc"),
        pipeline_mode=pipeline_mode,
    )
    result_struct = ScenePrecRecallPipelineResult(
        slicer_name=slicer_name,
        slicer_execution_mode=SlicerExecutionMode(slicer_execution_mode),
        num_labels=len(labels_df),
        labelset_name=labelset_name,
        labelset_purpose=labelset_purpose,
        labelset_timestamp=pd.Timestamp(labelset_timestamp.timestamp(), unit="s", tz="utc"),
        pipeline_exec_info=pipeline_exec_info,
        prec_recall_results=pr_result,
        slicer_input_modality=slicer_input_modality,
    )
    bq_client.run_query(result_struct.get_insert_query(table_name=SCENE_PR_PIPELINE_RESULTS_TABLE))
    logger.info("Wrote results to BQ for slicer %s and eval id: %s", slicer_name, evaluation_uuid)
    return True


@transformer
def less_all_scenes_prec_recall(pipeline_mode: Text, slicer_execution_mode: Text) -> List[Boolean]:
    """Pipeline for computing precision recall on all scene slicers with labels."""
    roboflow_run_id = get_run_id()
    evaluation_uuid = (
        roboflow_run_id if roboflow_run_id is not None else str(uuid.uuid4()).replace("-", "")
    )
    # utcnow(...) is deprecated but alternate functions are not supported by roboflow.
    evaluation_timestamp = Timestamp(datetime.datetime.utcnow())
    logger.info(
        "Calculating P/R for all slicers with labels. Evaluation UUID: %s @ %s",
        evaluation_uuid,
        evaluation_timestamp,
    )

    # Initialize singleton with local creds when running in roboflow.
    LessBigQueryClient.init_from_default_creds()

    # Query all the existing labels amd slicers with labels.
    label_client = LessLabelClient(schema_type=SceneSlicerLabel)
    all_labels_df = label_client.resolve_labelsets()
    slicer_names = all_labels_df["slicer_name"].unique().tolist()
    logger.info("Found %d slicers to evaluate", len(slicer_names))

    valid_slicer_names = get_valid_slicer_def_names(slicer_def_names=None) + [
        e.name for e in SIM_REGISTRY.slicers
    ]
    # Reserve prec/recall computation for each slicer.
    futures = []
    for slicer_name in slicer_names:
        if (
            "cola_unlocalized" in slicer_name
            and slicer_execution_mode == SlicerExecutionMode.QUERY_EXISTING.value
        ):
            # This can be removed once the COLA only slicers are populating the __latest_full_drive__ view.
            logger.warning(
                "Skipping COLA only slicer %s as it is not yet supported for the QUERY_EXISTING slicer mode.",
                slicer_name,
            )
            continue
        labels_df_total = all_labels_df.query(f"slicer_name == '{slicer_name}'")
        if labels_df_total.empty:
            # Should never get here since the slicers were queried from the labels.
            logger.error("No labels found for slicer name: %s !", slicer_name)
            continue
        # If there is no labelset purpose, set it to BOTH as a default and June 1, 2025 as the timestamp default
        labels_df_total["labelset_purpose"] = labels_df_total["labelset_purpose"].fillna(
            LabelsetPurpose.BOTH.value
        )
        labels_df_total["labelset_timestamp"] = labels_df_total["labelset_timestamp"].fillna(
            pd.Timestamp("2025-06-01 00:00:00")
        )
        for labelset_name in labels_df_total.labelset_name.unique():
            labels_df = labels_df_total.query(f"labelset_name == '{labelset_name}'")
            # Extract labelset_purpose
            labelset_purpose = LabelsetPurpose(labels_df.labelset_purpose.iloc[0].upper())
            labelset_purpose = LabelsetPurpose(labelset_purpose)
            # Convert to epoch timestamp (float) since roboflow's Timestamp handles this reliably
            labelset_timestamp_val = pd.Timestamp(labels_df.labelset_timestamp.iloc[0])
            labelset_timestamp = Timestamp(labelset_timestamp_val.timestamp())
            if labels_df.empty:
                continue
            input_ids_by_modality = split_input_ids_by_modality(
                input_ids=labels_df["segment_id"].tolist()
            )
            if (
                slicer_execution_mode == SlicerExecutionMode.QUERY_EXISTING.value
            ) and not input_ids_by_modality[SlicerInputModality.ROAD]:
                # Query existing mode is not compatible with sim results.
                logger.warning(
                    "Skipping QUERY_EXISTING prec/recall for %s, %s since only sim labels are present",
                    slicer_name,
                    labelset_name,
                )
                continue
            if not any(labels_df["is_event_in_segment"]):
                logger.warning(
                    "No positive labels found for slicer %s, %s so skipping prec/recall computation",
                    slicer_name,
                    labelset_name,
                )
                continue
            # Ensure the slicer is valid (labels may be added before the slicer has landed).
            if slicer_name not in valid_slicer_names:
                logger.warning(
                    "Skipping prec/recall for slicer %s, %s which may not have landed on develop",
                    slicer_name,
                    labelset_name,
                )
                continue
            labels_df = labels_df[_LABEL_SCHEMA_COLUMNS]
            logger.info("Reserving transformer for prec/recall on slicer %s", slicer_name)
            futures.append(
                try_except(
                    scene_prec_recall(
                        slicer_name=slicer_name,
                        labels_df=labels_df,
                        labelset_name=labelset_name,
                        labelset_purpose=labelset_purpose,
                        labelset_timestamp=labelset_timestamp,
                        slicer_execution_mode=slicer_execution_mode,
                        evaluation_uuid=evaluation_uuid,
                        evaluation_timestamp=evaluation_timestamp,
                        pipeline_mode=pipeline_mode,
                        slicer_input_modality=SlicerInputModality.ROAD
                        if input_ids_by_modality[SlicerInputModality.ROAD]
                        else SlicerInputModality.SIM,
                    ),
                    ExceptionHandler(
                        catch=Exception,
                        handler=handle_scene_prec_exception(
                            slicer_name=slicer_name,
                            labelset_name=labelset_name,
                            slicer_execution_mode=slicer_execution_mode,
                            evaluation_uuid=evaluation_uuid,
                            pipeline_mode=pipeline_mode,
                        ),
                    ),
                )
            )
    return make_list(List[Boolean], futures)


@click.command()
@click.option(
    "--wait_for_result",
    "-w",
    is_flag=True,
    help="Wait for the pipeline to complete and print the result",
)
@click.option(
    "--slicer_execution_mode",
    type=click.Choice([m.value for m in SlicerExecutionMode]),
    default=SlicerExecutionMode.QUERY_EXISTING.value,
    help="The slicer execution mode to run (rerun or query existing output)",
)
@click.option(
    "--pipeline_mode",
    type=click.Choice([m.value for m in PipelineMode]),
    default=PipelineMode.MANUAL_DEV.value,
    help="Pipeline mode to run - if unsure, please use the default.",
)
def main(wait_for_result: bool, slicer_execution_mode: str, pipeline_mode: str) -> None:
    logging.basicConfig(
        level=logging.INFO, format="%(levelname)s %(asctime)s - %(name)s - %(message)s"
    )

    pipeline_spec = PipelineSpec(
        root_future=less_all_scenes_prec_recall(
            pipeline_mode=pipeline_mode,
            slicer_execution_mode=slicer_execution_mode,
        ),
        semantic_pipeline_config=_SEMANTIC_PIPELINE_CONFIG,
    )

    # Get the handle to the pipeline.
    pipeline_run = pipeline_spec.submit()

    # Optionally wait for the actual return value of the pipeline
    # (an Exception will be raised here if the pipeline failed)
    if wait_for_result:
        res = pipeline_run.wait_for_result()
        logger.info(f"Pipeline result: {res}")


if __name__ == "__main__":
    main()
