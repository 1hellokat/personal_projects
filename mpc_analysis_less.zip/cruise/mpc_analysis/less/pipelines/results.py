"""Library for storing pipeline results structures."""

# System imports
import getpass
import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

# Third-party imports
import pandas as pd
from sqlglot import expressions as exp

# Cruise imports
from cruise.mlp.roboflow2.api_client import get_run
from cruise.mlp.roboflow2.git import generate_git_info
from cruise.mpc_analysis.less.base_schema import BaseSchema
from cruise.mpc_analysis.less.labels.common_utils import create_insert_query
from cruise.mpc_analysis.less.labels.tpo import LabelsetPurpose
from cruise.mpc_analysis.less.precision_recall_utils import PrecisionRecallResult
from cruise.mpc_analysis.less.slicer_utils import SlicerExecutionMode, SlicerInputModality

logger = logging.getLogger(__name__)


class PipelineMode(Enum):
    """Various modes of the triggering thae pipeline."""

    # User manually kicks off a pipeline (e.g. via bazel command)
    MANUAL_DEV = "manual_dev"

    # Scheduled run from the develop branch.
    DEVELOP_SCHEDULED = "develop_scheduled"


@dataclass
class PipelineExecutionInfo(BaseSchema):
    """Standard metadata for a pipeline execution."""

    # Identifier for this evaluation/pipeline instance.
    uuid: str
    timestamp: pd.Timestamp
    pipeline_mode: str
    user: str = getpass.getuser()


@dataclass
class ScenePrecRecallPipelineResult(BaseSchema):
    """Structure for a precision/recall evaluation for a single scene slicer."""

    slicer_name: str
    labelset_name: str
    labelset_purpose: LabelsetPurpose
    labelset_timestamp: pd.Timestamp
    slicer_execution_mode: SlicerExecutionMode
    num_labels: int
    slicer_input_modality: SlicerInputModality
    pipeline_exec_info: PipelineExecutionInfo
    prec_recall_results: PrecisionRecallResult

    def get_insert_query(self, table_name: str, dialect: str = "bigquery") -> str:
        """Constructs an insertion SQL query for the contents of this structure."""

        timestamp_str = self.pipeline_exec_info.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        labelset_timestamp_str = self.labelset_timestamp.strftime("%Y-%m-%d %H:%M:%S")
        row: dict[str, Any] = {
            "triggered_by": exp.Literal.string(self.pipeline_exec_info.user),
            "uuid": exp.Literal.string(self.pipeline_exec_info.uuid),
            "timestamp": exp.func("TIMESTAMP", exp.Literal.string(timestamp_str)),
            "pipeline_mode": exp.Literal.string(self.pipeline_exec_info.pipeline_mode),
            "slicer_name": exp.Literal.string(self.slicer_name),
            "labelset_name": exp.Literal.string(self.labelset_name),
            "labelset_purpose": exp.Literal.string(self.labelset_purpose.value),
            "labelset_timestamp": exp.func(
                "TIMESTAMP", exp.Literal.string(labelset_timestamp_str)
            ),
            "slicer_execution_mode": exp.Literal.string(self.slicer_execution_mode.value),
            "slicer_input_modality": exp.Literal.string(self.slicer_input_modality.value),
            "num_labels": exp.Literal.number(self.num_labels),
            "precision": exp.Literal.number(self.prec_recall_results.precision),
            "recall": exp.Literal.number(self.prec_recall_results.recall),
            "num_tp": exp.Literal.number(self.prec_recall_results.num_tp),
            "num_fp": exp.Literal.number(self.prec_recall_results.num_fp),
            "num_tn": exp.Literal.number(self.prec_recall_results.num_tn),
            "num_fn": exp.Literal.number(self.prec_recall_results.num_fn),
            "true_positives": exp.Array(
                expressions=[
                    exp.Literal.string(s) for s in self.prec_recall_results.true_positives
                ]
            ),
            "true_negatives": exp.Array(
                expressions=[
                    exp.Literal.string(s) for s in self.prec_recall_results.true_negatives
                ]
            ),
            "false_positives": exp.Array(
                expressions=[
                    exp.Literal.string(s) for s in self.prec_recall_results.false_positives
                ]
            ),
            "false_negatives": exp.Array(
                expressions=[
                    exp.Literal.string(s) for s in self.prec_recall_results.false_negatives
                ]
            ),
        }

        git_info = generate_git_info()
        if git_info is None:
            roboflow_run = get_run(run_id=self.pipeline_exec_info.uuid)
            git_info = roboflow_run.git_info

        row["git_base_commit"] = exp.Literal.string(git_info["git_base_commit"])
        row["git_branch"] = exp.Literal.string(git_info["git_branch"])
        row["git_diff_file"] = exp.Literal.string(git_info["git_diff_file"])
        row["git_merge_base"] = exp.Literal.string(git_info["git_merge_base"])
        row["git_base_branch_status"] = exp.Literal.string(str(git_info["base_branch_status"]))

        return create_insert_query(row_data=[row], table_name=table_name, dialect=dialect)
