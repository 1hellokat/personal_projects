"""Utilities for the scene precision recall pipeline."""

# System imports
import logging
from dataclasses import dataclass
from typing import Optional

# Third-party imports
import pandas as pd

# Cruise imports
from cruise.lgtm2.core.metadata import Dri as Lgtm2Dri
from cruise.lgtm2.production_metrics import SIM_REGISTRY
from cruise.lgtm.attribute_store.common_attribute_metadata import Dri as Lgtm1Dri
from cruise.mlp.roboflow2.notifications.slack import (
    _send_message as send_slack_message,
    get_user_id_by_email,
)
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.constants import (
    LESS_ALERT_SLACK_CHANNEL,
    SCENE_PR_DELTA_ALERT_THRESH_PCT,
    SCENE_PR_PIPELINE_RESULTS_TABLE,
)
from cruise.mpc_analysis.less.pipelines.results import PipelineMode
from cruise.mpc_analysis.less.precision_recall_utils import (
    PrecisionRecallResult,
    PrecisionRecallResultDelta,
)
from cruise.mpc_analysis.less.slicer_utils import (
    SlicerExecutionMode,
    SlicerFramework,
    check_and_instantiate_slicer,
    determine_slicer_framework,
)

logger = logging.getLogger(__name__)


@dataclass
class ScenePrecRecallResultsFilter:
    """Structure for filtering scene slicer precision recall pipeline results."""

    # These must match the schema in the BQ table for this to work.
    slicer_name: Optional[str] = None
    labelset_name: Optional[str] = None
    pipeline_mode: Optional[PipelineMode] = None
    slicer_execution_mode: Optional[SlicerExecutionMode] = None
    git_branch: Optional[str] = None
    git_diff_file: Optional[str] = None
    triggered_by: Optional[str] = None

    def get_where_clause(self) -> Optional[str]:
        """Main function for this class - generates the SQL WHERE clause."""
        components: list[str] = []
        for field_name, field_type in self.__annotations__.items():
            val = getattr(self, field_name)
            if val is None:
                continue
            val_str = val if field_type == Optional[str] else val.value
            components.append(f"{field_name} = '{val_str}'")
        if components:
            return f"WHERE {' AND '.join(components)}"
        return None


def get_historical_results(where_clause: str, newest_first: bool = True) -> pd.DataFrame:
    """Query the historical precision/recall evaluation results for this slicer/mode."""
    order_param = "DESC" if newest_first else "ASC"
    query = f"""
        SELECT
          *
        FROM
          `{SCENE_PR_PIPELINE_RESULTS_TABLE}`
        {where_clause}
        ORDER BY timestamp {order_param}
    """
    bq_client = LessBigQueryClient.init_from_default_creds()
    return bq_client.run_query_and_get_dataframe(query=query)


def get_historical_develop_results(
    slicer_name: str,
    labelset_name: str,
    slicer_execution_mode: SlicerExecutionMode,
    newest_first: bool = True,
) -> pd.DataFrame:
    """Get the historical prec/recall results for a slicer/mode from the develop pipeline."""
    filter_params = ScenePrecRecallResultsFilter(
        slicer_name=slicer_name,
        labelset_name=labelset_name,
        pipeline_mode=PipelineMode.DEVELOP_SCHEDULED,
        slicer_execution_mode=slicer_execution_mode,
        git_branch="develop",
        git_diff_file="None",
        triggered_by="root",
    )
    where_clause = filter_params.get_where_clause()
    if where_clause is None:
        # Should never get here.
        logger.exception("Unable to construct where clause!")
        raise ValueError
    return get_historical_results(where_clause=where_clause, newest_first=newest_first)


def get_centra_link(roboflow_run_id: str) -> str:
    """Helper to generate a centra link."""
    return f"https://centra.robot.car/roboflow/runs/{roboflow_run_id}/"


def _get_slack_handle_from_email(email: str) -> Optional[str]:
    """Helper to get a slack handle from an email address"""
    maybe_slack_id = get_user_id_by_email(email)
    if maybe_slack_id is not None:
        return f"<@{maybe_slack_id}>"
    return "@" + email.replace("@getcruise.com", "").replace("@gm.com", "")


def get_slicer_dri_slack_handle(slicer_name: str) -> Optional[str]:
    """Returns a slicer DRI if populated."""
    slicer_framework = determine_slicer_framework(slicer_name=slicer_name)
    if slicer_framework == SlicerFramework.LGTM1:
        slicer = check_and_instantiate_slicer(slicer_name=slicer_name)
        for entry in slicer.metadata:
            if isinstance(entry, Lgtm1Dri):
                return _get_slack_handle_from_email(email=entry.email)
    elif slicer_framework == SlicerFramework.LGTM2:
        registry = SIM_REGISTRY.get_registry_for_node_subset(nodes=[slicer_name])
        for slicer in registry.slicers:
            if slicer.name == slicer_name and isinstance(slicer.dri, Lgtm2Dri):
                return _get_slack_handle_from_email(email=slicer.dri.email)
    return None


def check_for_regression_and_alert(
    slicer_name: str,
    labelset_name: str,
    slicer_execution_mode: SlicerExecutionMode,
    evaluation_uuid: str,
    cur_pr_result: PrecisionRecallResult,
) -> None:
    """Check for precision/recall regressions and if so send an alert via slack."""
    historical_results = get_historical_develop_results(
        slicer_name=slicer_name,
        labelset_name=labelset_name,
        slicer_execution_mode=slicer_execution_mode,
        newest_first=True,
    )
    if historical_results.empty:
        logger.warning(
            "No previous results found for slicer %s and exec mode: %s",
            slicer_name,
            slicer_execution_mode.value,
        )
        return None
    prev_pr_result = PrecisionRecallResult(
        true_positives=historical_results.iloc[0]["true_positives"],
        false_positives=historical_results.iloc[0]["false_positives"],
        true_negatives=historical_results.iloc[0]["true_negatives"],
        false_negatives=historical_results.iloc[0]["false_negatives"],
    )
    delta_results = PrecisionRecallResultDelta(result_a=prev_pr_result, result_b=cur_pr_result)
    slicer_mode_str = f"(Slicer exec mode: {slicer_execution_mode.value}"
    labelset_name_str = f"and labelset_name: `{labelset_name}`)"
    info_str = f"{slicer_mode_str} {labelset_name_str}"
    alert_msg = ""
    if delta_results.precision_delta < 0 and (
        abs(delta_results.precision_delta_pct) > SCENE_PR_DELTA_ALERT_THRESH_PCT
    ):
        # Precision regression beyond the threshold detected.
        alert_msg += f" `{slicer_name}` *Precision REGRESSED {info_str} by {abs(delta_results.precision_delta_pct):.0f}%*"
        alert_msg += f" prev precision: {prev_pr_result.precision:.2f} current precision: {cur_pr_result.precision:.2f}\n"
    if delta_results.recall_delta < 0 and (
        abs(delta_results.recall_delta_pct) > SCENE_PR_DELTA_ALERT_THRESH_PCT
    ):
        # Recall regression beyond the theshold detected.
        alert_msg += f" `{slicer_name}` *Recall REGRESSED {info_str} by {abs(delta_results.recall_delta_pct):.0f}%*"
        alert_msg += f" prev recall: {prev_pr_result.recall:.2f} current recall: {cur_pr_result.recall:.2f}\n"
    if alert_msg:
        # Add the Slicer DRI to the alert message if populated.
        maybe_dri = get_slicer_dri_slack_handle(slicer_name=slicer_name)
        alert_msg += f" {maybe_dri} " if maybe_dri is not None else ""
        # Add a link to the roboflow pipeline execution + emoji for effect.
        alert_msg += "\n :redalert:" + get_centra_link(roboflow_run_id=evaluation_uuid)
        send_slack_message(channel=LESS_ALERT_SLACK_CHANNEL, text=alert_msg)
