"""Unit tests for the pipeline results library."""

# System imports
from typing import Final

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.mpc_analysis.less.labels.tpo import LabelsetPurpose
from cruise.mpc_analysis.less.pipelines.results import (
    PipelineExecutionInfo,
    PipelineMode,
    ScenePrecRecallPipelineResult,
)
from cruise.mpc_analysis.less.precision_recall_utils import PrecisionRecallResult
from cruise.mpc_analysis.less.slicer_utils import SlicerExecutionMode, SlicerInputModality

_UUID: Final[str] = "28f3e60f-a0a0-4afa-afb1-95f016187fda"
_SAMPLE_SLICER_NAME: Final[str] = "av_in_unit_test_scene"
_SAMPLE_TABLE_NAME: Final[str] = "fake_table"
_SAMPLE_LABELSET_NAME: Final[str] = "av_in_unit_test_scene_validate"
_LABELSET_PURPOSE: Final[LabelsetPurpose] = LabelsetPurpose.PRECISION
_LABELSET_TIMESTAMP: Final[pd.Timestamp] = pd.Timestamp("2025-01-01 00:00:00")


@pytest.fixture
def sample_pipeline_exec_info() -> PipelineExecutionInfo:
    return PipelineExecutionInfo(
        uuid=_UUID,
        timestamp=pd.Timestamp.now(),
        pipeline_mode=PipelineMode.MANUAL_DEV.value,
    )


@pytest.fixture
def sample_prec_recall_result() -> PrecisionRecallResult:
    return PrecisionRecallResult(
        true_positives=["a", "b", "c"],
        false_positives=["d", "e"],
        true_negatives=["f", "g"],
        false_negatives=[],
    )


def test_pipeline_execution_info_init(
    sample_pipeline_exec_info: PipelineExecutionInfo,
    sample_prec_recall_result: PrecisionRecallResult,
) -> None:
    """Tests that the results structure can be instantiated and generate an insert query."""
    result = ScenePrecRecallPipelineResult(
        slicer_name=_SAMPLE_SLICER_NAME,
        labelset_name=_SAMPLE_LABELSET_NAME,
        slicer_execution_mode=SlicerExecutionMode.RERUN_SLICER,
        num_labels=10,
        pipeline_exec_info=sample_pipeline_exec_info,
        prec_recall_results=sample_prec_recall_result,
        labelset_purpose=_LABELSET_PURPOSE,
        labelset_timestamp=_LABELSET_TIMESTAMP,
        slicer_input_modality=SlicerInputModality.ROAD,
    )
    query = result.get_insert_query(table_name=_SAMPLE_TABLE_NAME, dialect="bigquery")
    assert f"INSERT INTO `{_SAMPLE_TABLE_NAME}`" in query
