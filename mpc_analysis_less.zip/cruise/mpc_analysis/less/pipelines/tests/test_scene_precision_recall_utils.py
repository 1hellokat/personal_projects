"""Unit tests for the scene precision recall pipeline utils library."""

# System imports
from typing import Final
from unittest import mock

# Third-party imports
import pandas as pd
import pytest

# Cruise imports
from cruise.lgtm2.core import ExecutorNode
from cruise.lgtm2.core.metadata import Dri as Lgtm2Dri
from cruise.lgtm.attribute_store.common_attribute_metadata import Dri as Lgtm1Dri
from cruise.mpc_analysis.less.pipelines.scene_precision_recall_utils import (
    ScenePrecRecallResultsFilter,
    check_for_regression_and_alert,
    get_centra_link,
    get_historical_develop_results,
    get_historical_results,
    get_slicer_dri_slack_handle,
)
from cruise.mpc_analysis.less.precision_recall_utils import PrecisionRecallResult
from cruise.mpc_analysis.less.slicer_utils import SlicerExecutionMode, SlicerFramework
from cruise.mpc_analysis.less.tests.fixtures import FakeBigQueryClient

_SAMPLE_UUID = "28f3e60fa0a04afaafb195f016187fda"
_SLICER_NAME: Final[str] = "av_in_unit_test_scene"
_LABELSET_NAME: Final[str] = "av_in_unit_test_scene_validate"
_UNIT_UNDER_TEST: Final[str] = "cruise.mpc_analysis.less.pipelines.scene_precision_recall_utils"
_SAMPLE_SLACK_HANDLE: Final[str] = "@jane.doe"


class FakeSlicer:
    metadata = []


@pytest.fixture
def sample_prec_recall_results() -> PrecisionRecallResult:
    return PrecisionRecallResult(
        true_positives=["a"],
        false_positives=["b"],
        true_negatives=["c"],
        false_negatives=["d"],
    )


def test_scene_prec_recall_results_filter_empty() -> None:
    filter = ScenePrecRecallResultsFilter()
    assert filter.get_where_clause() is None


def test_scene_prec_recall_results_filter_slicer_name() -> None:
    filter = ScenePrecRecallResultsFilter(slicer_name=_SLICER_NAME)
    where_clause = filter.get_where_clause()
    assert where_clause is not None
    assert f"slicer_name = '{_SLICER_NAME}'" in where_clause


@mock.patch(
    f"{_UNIT_UNDER_TEST}.LessBigQueryClient.init_from_default_creds",
    return_value=FakeBigQueryClient(),
)
def test_get_historical_results(bq_client_mock: mock.Mock) -> None:
    where_clause = ScenePrecRecallResultsFilter(slicer_name=_SLICER_NAME).get_where_clause()
    assert where_clause is not None
    get_historical_results(where_clause=where_clause, newest_first=True)
    get_historical_results(where_clause=where_clause, newest_first=False)
    assert bq_client_mock.call_count == 2


@mock.patch(
    f"{_UNIT_UNDER_TEST}.LessBigQueryClient.init_from_default_creds",
    return_value=FakeBigQueryClient(),
)
def test_get_historical_develop_results(bq_client_mock: mock.Mock) -> None:
    get_historical_develop_results(
        slicer_name=_SLICER_NAME,
        labelset_name=_LABELSET_NAME,
        slicer_execution_mode=SlicerExecutionMode.QUERY_EXISTING,
        newest_first=True,
    )
    get_historical_develop_results(
        slicer_name=_SLICER_NAME,
        labelset_name=_LABELSET_NAME,
        slicer_execution_mode=SlicerExecutionMode.QUERY_EXISTING,
        newest_first=False,
    )
    assert bq_client_mock.call_count == 2


def test_get_centra_link() -> None:
    link = get_centra_link(roboflow_run_id=_SAMPLE_UUID)
    assert _SAMPLE_UUID in link
    assert "https://centra.robot.car/" in link


@mock.patch(f"{_UNIT_UNDER_TEST}.determine_slicer_framework", return_value=SlicerFramework.LGTM1)
@mock.patch(f"{_UNIT_UNDER_TEST}.check_and_instantiate_slicer", return_value=FakeSlicer())
def test_get_slicer_dri_slack_handle_no_metadata_lgtm1(
    instantiate_slicer_mock: mock.Mock, determine_slicer_framework: mock.Mock
) -> None:
    assert get_slicer_dri_slack_handle(slicer_name=_SLICER_NAME) is None
    assert instantiate_slicer_mock.call_count == 1
    assert determine_slicer_framework.call_count == 1


@mock.patch(f"{_UNIT_UNDER_TEST}.determine_slicer_framework", return_value=SlicerFramework.LGTM1)
@mock.patch(f"{_UNIT_UNDER_TEST}.check_and_instantiate_slicer")
def test_get_slicer_dri_slack_handle_metadata_no_dri_lgtm1(
    instantiate_slicer_mock: mock.Mock, determine_slicer_framework: mock.Mock
) -> None:
    fake_slicer = FakeSlicer()
    fake_slicer.metadata.append("blah")
    instantiate_slicer_mock.return_value = fake_slicer
    assert get_slicer_dri_slack_handle(slicer_name=_SLICER_NAME) is None
    assert instantiate_slicer_mock.call_count == 1
    assert determine_slicer_framework.call_count == 1


@mock.patch(f"{_UNIT_UNDER_TEST}.determine_slicer_framework", return_value=SlicerFramework.LGTM1)
@mock.patch(f"{_UNIT_UNDER_TEST}.check_and_instantiate_slicer")
@mock.patch(f"{_UNIT_UNDER_TEST}.get_user_id_by_email", return_value=None)
def test_get_slicer_dri_slack_handle_metadata_with_dri_lgtm1(
    get_user_id_mock: mock.Mock,
    instantiate_slicer_mock: mock.Mock,
    determine_slicer_framework: mock.Mock,
) -> None:
    fake_slicer = FakeSlicer()
    fake_dri = Lgtm1Dri(name="Jane Doe", email="jane.doe@getcruise.com")
    fake_slicer.metadata.append(fake_dri)
    instantiate_slicer_mock.return_value = fake_slicer
    assert get_slicer_dri_slack_handle(slicer_name=_SLICER_NAME) == _SAMPLE_SLACK_HANDLE
    assert instantiate_slicer_mock.call_count == 1
    assert get_user_id_mock.call_count == 1
    assert determine_slicer_framework.call_count == 1


@mock.patch(f"{_UNIT_UNDER_TEST}.determine_slicer_framework", return_value=SlicerFramework.LGTM2)
@mock.patch(f"{_UNIT_UNDER_TEST}.get_user_id_by_email", return_value=None)
def test_get_slicer_dri_slack_handle_dri_lgtm2(
    get_user_id_mock: mock.Mock, determine_slicer_framework: mock.Mock
) -> None:
    class FakeLgtm2Slicer(ExecutorNode):
        def __init__(self) -> None:
            self.name = _SLICER_NAME
            self.dri = Lgtm2Dri(name="Jane Doe", email="jane.doe@getcruise.com")

    class FakeSlicerRegistry:
        def __init__(self) -> None:
            self.slicers = [FakeLgtm2Slicer()]

        def get_registry_for_node_subset(self, nodes: list[str]) -> "FakeSlicerRegistry":
            return self

    with mock.patch(
        f"{_UNIT_UNDER_TEST}.SIM_REGISTRY",
        FakeSlicerRegistry(),
    ):
        assert get_slicer_dri_slack_handle(slicer_name=_SLICER_NAME) == _SAMPLE_SLACK_HANDLE
        assert get_user_id_mock.call_count == 1
        assert determine_slicer_framework.call_count == 1


@mock.patch(f"{_UNIT_UNDER_TEST}.determine_slicer_framework", return_value=SlicerFramework.LGTM1)
@mock.patch(f"{_UNIT_UNDER_TEST}.check_and_instantiate_slicer")
@mock.patch(f"{_UNIT_UNDER_TEST}.get_user_id_by_email")
def test_get_slicer_dri_slack_handle_metadata_with_dri_user_id_lgtm1(
    get_user_id_mock: mock.Mock,
    instantiate_slicer_mock: mock.Mock,
    determine_slicer_framework: mock.Mock,
) -> None:
    fake_slicer = FakeSlicer()
    fake_dri = Lgtm1Dri(name="Jane Doe", email="jane.doe@getcruise.com")
    fake_slicer.metadata.append(fake_dri)
    instantiate_slicer_mock.return_value = fake_slicer
    fake_user_id = "janes_user_id"
    get_user_id_mock.return_value = fake_user_id
    assert get_slicer_dri_slack_handle(slicer_name=_SLICER_NAME) == f"<@{fake_user_id}>"
    assert instantiate_slicer_mock.call_count == 1
    assert get_user_id_mock.call_count == 1
    assert determine_slicer_framework.call_count == 1


@mock.patch(f"{_UNIT_UNDER_TEST}.get_historical_develop_results")
@mock.patch(f"{_UNIT_UNDER_TEST}.send_slack_message")
def test_check_for_regression_and_alert_no_change(
    send_slack_mock: mock.Mock,
    get_historical_results_mock: mock.Mock,
    sample_prec_recall_results: PrecisionRecallResult,
) -> None:
    """Checks that providing the same consecutive results does not alert."""
    historical_results_df = pd.DataFrame(
        [
            {
                "true_positives": sample_prec_recall_results.true_positives,
                "false_positives": sample_prec_recall_results.false_positives,
                "true_negatives": sample_prec_recall_results.true_negatives,
                "false_negatives": sample_prec_recall_results.false_negatives,
            }
        ]
    )
    get_historical_results_mock.return_value = historical_results_df
    check_for_regression_and_alert(
        slicer_name=_SLICER_NAME,
        labelset_name=_LABELSET_NAME,
        slicer_execution_mode=SlicerExecutionMode.QUERY_EXISTING,
        evaluation_uuid=_SAMPLE_UUID,
        cur_pr_result=sample_prec_recall_results,
    )
    assert get_historical_results_mock.call_count == 1
    assert send_slack_mock.call_count == 0


@mock.patch(f"{_UNIT_UNDER_TEST}.get_slicer_dri_slack_handle", return_value=_SAMPLE_SLACK_HANDLE)
@mock.patch(f"{_UNIT_UNDER_TEST}.get_historical_develop_results")
@mock.patch(f"{_UNIT_UNDER_TEST}.send_slack_message")
def test_check_for_regression_and_alert_recall_regression(
    send_slack_mock: mock.Mock,
    get_historical_results_mock: mock.Mock,
    get_slack_handle_mock: mock.Mock,
    sample_prec_recall_results: PrecisionRecallResult,
) -> None:
    """Checks that a regression in recall results in a slack alert."""

    # The sample results have a recall of 0.5.
    historical_results_df = pd.DataFrame(
        [
            {
                "true_positives": sample_prec_recall_results.true_positives,
                "false_positives": sample_prec_recall_results.false_positives,
                "true_negatives": sample_prec_recall_results.true_negatives,
                "false_negatives": sample_prec_recall_results.false_negatives,
            }
        ]
    )

    # Adjust the current results to have a lower recall than the historical results.
    cur_pr_result = PrecisionRecallResult(
        true_positives=sample_prec_recall_results.true_positives,
        false_positives=sample_prec_recall_results.false_positives,
        true_negatives=sample_prec_recall_results.true_negatives,
        false_negatives=sample_prec_recall_results.false_negatives + ["e"],
    )
    get_historical_results_mock.return_value = historical_results_df
    check_for_regression_and_alert(
        slicer_name=_SLICER_NAME,
        labelset_name=_LABELSET_NAME,
        slicer_execution_mode=SlicerExecutionMode.QUERY_EXISTING,
        evaluation_uuid=_SAMPLE_UUID,
        cur_pr_result=cur_pr_result,
    )
    assert get_historical_results_mock.call_count == 1
    # Check that a slack alert was initiated.
    assert send_slack_mock.call_count == 1
    assert get_slack_handle_mock.call_count == 1


@mock.patch(f"{_UNIT_UNDER_TEST}.get_slicer_dri_slack_handle", return_value=_SAMPLE_SLACK_HANDLE)
@mock.patch(f"{_UNIT_UNDER_TEST}.get_historical_develop_results")
@mock.patch(f"{_UNIT_UNDER_TEST}.send_slack_message")
def test_check_for_regression_and_alert_precision_regression(
    send_slack_mock: mock.Mock,
    get_historical_results_mock: mock.Mock,
    get_slack_handle_mock: mock.Mock,
    sample_prec_recall_results: PrecisionRecallResult,
) -> None:
    """Checks that a regression in recall results in a slack alert."""

    # The sample results have a precision of 0.5.
    historical_results_df = pd.DataFrame(
        [
            {
                "true_positives": sample_prec_recall_results.true_positives,
                "false_positives": sample_prec_recall_results.false_positives,
                "true_negatives": sample_prec_recall_results.true_negatives,
                "false_negatives": sample_prec_recall_results.false_negatives,
            }
        ]
    )

    # Adjust the current results to have a lower precision than the historical results.
    cur_pr_result = PrecisionRecallResult(
        true_positives=sample_prec_recall_results.true_positives,
        false_positives=sample_prec_recall_results.false_positives + ["e"],
        true_negatives=sample_prec_recall_results.true_negatives,
        false_negatives=sample_prec_recall_results.false_negatives,
    )
    get_historical_results_mock.return_value = historical_results_df
    check_for_regression_and_alert(
        slicer_name=_SLICER_NAME,
        labelset_name=_LABELSET_NAME,
        slicer_execution_mode=SlicerExecutionMode.QUERY_EXISTING,
        evaluation_uuid=_SAMPLE_UUID,
        cur_pr_result=cur_pr_result,
    )
    assert get_historical_results_mock.call_count == 1
    # Check that a slack alert was initiated.
    assert send_slack_mock.call_count == 1
    assert get_slack_handle_mock.call_count == 1
