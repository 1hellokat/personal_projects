"""Library for sourcing events for LESS."""

# System imports
from tempfile import TemporaryDirectory
from typing import Optional

# Third-party imports
import open_clip
import pandas as pd

# Cruise imports
from cruise.mpc_analysis.less.bigquery_client import LessBigQueryClient
from cruise.mpc_analysis.less.segment import Segment
from cruise.mpc_analysis.less.visualization import webviz_link_from_row
from cruise.runfiles import get_runfile_path

MODEL_NAME = "ViT-H-14-quickgelu"
_default_dfn5b_model_path = str(get_runfile_path("external/DFN5B-CLIP-ViT-H-14/file/downloaded"))

_QUERY_TEMPLATE = """
        SELECT
            vin,
            timestamp_secs,
            track_id,
            camera_bbox,
            ML.DISTANCE(embeddings.value, {search_vector}, "COSINE") as dist
        FROM
            `ca-ai-search-stg-y8ck.vespa.vespa_feed`,
            UNNEST(dfn5b_embeddings__1) as embeddings,
            UNNEST(camera_bbox) as camera
        WHERE
            {where_clause}
        ORDER BY dist ASC
        LIMIT {num_results}
"""


def cola_text_search(
    prompt: str,
    num_results: int,
    camera_keyword: Optional[str] = None,
    results_before_date: Optional[str] = None,
    results_after_date: Optional[str] = None,
) -> pd.DataFrame:
    """Perform a COLA search using a text prompt."""
    with TemporaryDirectory() as tmp_dir:
        model, _ = open_clip.create_model_from_pretrained(
            model_name=MODEL_NAME,
            pretrained=_default_dfn5b_model_path,
            jit=True,
            return_transform=True,
            cache_dir=tmp_dir,
        )  # type: ignore[reportGeneralTypeIssues]
        tokenizer = open_clip.get_tokenizer(MODEL_NAME)
        text = tokenizer([prompt])
        text_features = model.encode_text(text)

    conditions = ["ARRAY_LENGTH(dfn5b_embeddings__1) > 0"]

    # Add conditions dynamically
    if camera_keyword is not None:
        conditions.append(f"camera like '%{camera_keyword}%'")

    if results_before_date is not None:
        conditions.append(f"timestamp_secs < UNIX_SECONDS('{results_before_date}')")

    if results_after_date is not None:
        conditions.append(f"timestamp_secs > UNIX_SECONDS('{results_after_date}')")

    # Join all conditions with AND
    where_clause = " AND ".join(conditions)

    search_vector = text_features[0].detach().numpy().tolist()

    query = _QUERY_TEMPLATE.format(
        search_vector=search_vector,
        num_results=num_results,
        where_clause=where_clause,
    )
    bq_client = LessBigQueryClient.init_from_vault()
    return bq_client.run_query_and_get_dataframe(query)


def get_camera_names(camera_bbox: list[str]) -> str:
    """Return a comma delimited list from the COLA raw camera BBOX results."""
    return ", ".join([e[: e.find(":")] for e in camera_bbox])


def format_cola_results(results_df: pd.DataFrame, segment_duration_s: float) -> pd.DataFrame:
    """Format COLA results for consumption."""
    half_duration_s = segment_duration_s / 2.0
    results_df["start_time_s"] = results_df["timestamp_secs"] - half_duration_s
    results_df["end_time_s"] = results_df["timestamp_secs"] + half_duration_s
    results_df["webviz_link"] = results_df.apply(webviz_link_from_row, axis=1)
    results_df["camera_names"] = results_df["camera_bbox"].apply(get_camera_names)
    results_df["segment_id"] = results_df.apply(lambda x: str(Segment.from_pandas_row(x)), axis=1)
    return results_df[["segment_id", "webviz_link", "camera_names", "track_id"]]
